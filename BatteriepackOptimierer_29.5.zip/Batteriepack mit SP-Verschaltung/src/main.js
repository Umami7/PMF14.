import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import './style.css';
void setupTaskbarLegacy;
function setupTaskbar() {
    const sidebarInner = document.querySelector('.sidebar-inner');
    const cards = Array.from(document.querySelectorAll('.sidebar-inner > .card'));
    const [shapeCard, cellCard, spacingCard] = cards;
    const runButton = document.getElementById('runBtn');
    if (!sidebarInner || !shapeCard || !cellCard || !spacingCard || !runButton)
        return;
    shapeCard.classList.add('shape-card');
    cellCard.classList.add('task-card');
    spacingCard.classList.add('task-card');
    const intro = document.createElement('section');
    intro.className = 'config-intro';
    intro.innerHTML = `
    <div class="config-kicker">Gefuehrte Konfiguration</div>
    <h2>Batteriepack auslegen</h2>
    <p>Geben Sie die Daten der Reihe nach ein. Danach berechnet die Optimierung den maximalen Bauraum und den gewuenschten Ziel-Pack.</p>
  `;
    sidebarInner.prepend(intro);
    const modeBox = document.createElement('div');
    modeBox.className = 'layout-box definition-box';
    modeBox.innerHTML = `
    <div class="subsection-title">Auslegungsart</div>
    <div class="choice-grid">
      <button type="button" class="choice-card active" id="modeSpaceBtn">
        <strong>Masse des Bauraums vorgeben</strong>
        <span>Form und Masse sind bekannt.</span>
      </button>
      <button type="button" class="choice-card" id="modeGridBtn">
        <strong>Zellraster vorgeben</strong>
        <span>Anzahl der Batteriezellen in Laenge, Breite und Ebenen.</span>
      </button>
    </div>
    <div class="workflow-copy" id="modeHint">Moeglichkeit 1: Optimiert die Batteriestacks innerhalb des angegebenen Bauraums.</div>
  `;
    shapeCard.prepend(modeBox);
    decorateWorkflowCard(shapeCard, '1', 'Auslegung starten', 'Waehlen Sie zuerst, ob der Bauraum vorgegeben ist oder aus einem Zellraster berechnet werden soll.');
    decorateWorkflowCard(cellCard, '2', 'Zelltyp waehlen', 'Zellformat, Zellmasse und Raster fuer die Packung.');
    decorateWorkflowCard(spacingCard, '3', 'Abstaende definieren', 'Sicherheitsrand, Zellabstand und Ebenen-Gap.');
    const capacityCard = createCapacityVoltagePanel();
    const gridLayoutBox = capacityCard.querySelector('#layoutBox');
    const shapeDetailsAnchor = document.getElementById('extra_trap') ?? document.getElementById('shapeHint');
    if (gridLayoutBox && shapeDetailsAnchor)
        shapeDetailsAnchor.insertAdjacentElement('afterend', gridLayoutBox);
    const lShapeLayerBox = document.createElement('div');
    lShapeLayerBox.className = 'layout-box';
    lShapeLayerBox.id = 'lShapeLayerBox';
    lShapeLayerBox.style.display = 'none';
    lShapeLayerBox.innerHTML = `
    <div class="subsection-title">Ebenen</div>
    <div class="workflow-copy">Anzahl der uebereinanderliegenden L-Form-Lagen.</div>
    <div id="lShapeLayerSlot"></div>
  `;
    if (gridLayoutBox)
        gridLayoutBox.insertAdjacentElement('beforebegin', lShapeLayerBox);
    decorateWorkflowCard(capacityCard, '4', 'Elektrische Zielwerte', 'Spannung, Kapazitaet sowie Serien- und Parallelzellen.');
    const exportCard = createExportPanel();
    decorateWorkflowCard(exportCard, '5', 'Ergebnis ausgeben', 'Kundendatenblatt fuer die aktuelle Auslegung exportieren.');
    const actionWrap = document.createElement('div');
    actionWrap.className = 'workflow-actions';
    actionWrap.innerHTML = `
    <div>
      <strong>Berechnung starten</strong>
      <span>Prueft Zellrichtung, Raster und Bauraumausnutzung.</span>
    </div>
  `;
    actionWrap.appendChild(runButton);
    const offsetCard = document.getElementById('offsetCard');
    sidebarInner.append(capacityCard, exportCard);
    if (offsetCard)
        sidebarInner.appendChild(offsetCard);
    setupSidebarTabs(sidebarInner, [
        { label: 'Bauraum', nodes: [intro, shapeCard] },
        { label: 'Zellen', nodes: [cellCard, spacingCard] },
        { label: 'Elektrik', nodes: [capacityCard] },
        { label: 'Ausgabe', nodes: offsetCard ? [exportCard, offsetCard] : [exportCard] },
    ]);
    const sidebar = document.querySelector('.sidebar');
    sidebar?.appendChild(actionWrap);
    const viewer = document.querySelector('.viewer');
    const resultsPanel = document.getElementById('resultsPanel');
    if (viewer && resultsPanel) {
        resultsPanel.classList.add('viewer-results');
        viewer.appendChild(resultsPanel);
    }
    if (viewer && !document.getElementById('componentInfoPanel')) {
        const info = document.createElement('div');
        info.id = 'componentInfoPanel';
        info.className = 'component-info';
        info.innerHTML = `
      <div class="component-info-title">Modell-Information</div>
      <div class="component-info-line">Klicken Sie eine Zellebene, Busbar oder Baugruppe an.</div>
    `;
        viewer.appendChild(info);
    }
}
function setupSidebarTabs(sidebarInner, tabs, stickyAction) {
    const nav = document.createElement('div');
    nav.className = 'sidebar-tabs';
    const panels = [];
    tabs.forEach((tab, idx) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'sidebar-tab-btn';
        btn.textContent = tab.label;
        btn.dataset.tabIdx = String(idx);
        nav.appendChild(btn);
        const panel = document.createElement('section');
        panel.className = 'sidebar-tab-panel';
        panel.dataset.tabIdx = String(idx);
        tab.nodes.forEach(node => panel.appendChild(node));
        panels.push(panel);
    });
    const anchor = stickyAction?.parentElement === sidebarInner ? stickyAction : null;
    sidebarInner.insertBefore(nav, anchor);
    panels.forEach(panel => sidebarInner.insertBefore(panel, anchor));
    function activate(idx) {
        nav.querySelectorAll('.sidebar-tab-btn').forEach((btn, buttonIdx) => {
            btn.classList.toggle('active', buttonIdx === idx);
        });
        panels.forEach((panel, panelIdx) => {
            panel.classList.toggle('active', panelIdx === idx);
            panel.style.display = panelIdx === idx ? '' : 'none';
        });
    }
    nav.querySelectorAll('.sidebar-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => activate(parseInt(btn.dataset.tabIdx ?? '0')));
    });
    activate(0);
}
// ─────────────────────────────────────────────────────────────────────────────
// PACKING PARAMETERS  (user-adjustable, read from inputs at runtime)
// ─────────────────────────────────────────────────────────────────────────────
// These are mutable — read via getPackingParams() at calculation time
let BOUNDARY_MARGIN = 5; // mm clearance from shape boundary
let CELL_GAP_ROUND = 5; // mm gap between round cell walls
let CELL_GAP_PRISM = 1; // mm gap between prismatic cell walls
let LAYER_GAP = 2; // mm gap between layers (stack direction)
function getPackingParams() {
    BOUNDARY_MARGIN = parseFloat(document.getElementById('paramMargin')?.value ?? '5') || 0;
    CELL_GAP_ROUND = parseFloat(document.getElementById('paramGapRound')?.value ?? '5') || 0;
    CELL_GAP_PRISM = parseFloat(document.getElementById('paramGapPrism')?.value ?? '1') || 0;
    LAYER_GAP = parseFloat(document.getElementById('paramLayerGap')?.value ?? '2') || 0;
}
const CELL_PRESETS = {
    '18650': { type: 'round', diam: 18, height: 65 },
    '21700': { type: 'round', diam: 21, height: 70 },
    'BYD50': { type: 'prismatic', width: 148, depth: 27, height: 91 },
    'EVE50': { type: 'prismatic', width: 135, depth: 30, height: 185 },
};
const DIR_LABELS = {
    z: 'von oben (Z)',
    x: 'von links (X)',
    y: 'von vorne (Y)',
};
const DIR_LABELS_SHORT = {
    z: 'Z-Achse',
    x: 'X-Achse',
    y: 'Y-Achse',
};
const GS_LABELS = {
    grid: 'Grid',
    honeycomb: '⬡ HComb',
};
// ─────────────────────────────────────────────────────────────────────────────
// GEOMETRY – 2D POLYGON
// ─────────────────────────────────────────────────────────────────────────────
const ROT_LABELS = {
    0: '0\u00b0',
    90: '90\u00b0',
};
function getCrossDimensions(cell, cellRotation = 0) {
    if (cell.type === 'round')
        return { width: cell.diam, depth: cell.diam };
    return cellRotation === 90
        ? { width: cell.depth, depth: cell.width }
        : { width: cell.width, depth: cell.depth };
}
function getWorldStepSizes(cell, extDir, cellRotation = 0, gridStyle = 'grid') {
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    const cross = getCrossDimensions(cell, cellRotation);
    const stepWidth = cross.width + gap;
    const stepDepth = cross.depth + gap;
    const stepLong = cell.height + LAYER_GAP;
    if (extDir === 'z') {
        return {
            stepX: stepWidth,
            stepY: stepLong,
            stepZ: gridStyle === 'honeycomb' ? stepWidth * (Math.sqrt(3) / 2) : stepDepth,
        };
    }
    if (extDir === 'x') {
        return {
            stepX: stepLong,
            stepY: gridStyle === 'honeycomb' ? stepDepth * (Math.sqrt(3) / 2) : stepWidth,
            stepZ: stepDepth,
        };
    }
    return {
        stepX: stepWidth,
        stepY: gridStyle === 'honeycomb' ? stepWidth * (Math.sqrt(3) / 2) : stepDepth,
        stepZ: stepLong,
    };
}
function orientationText(result) {
    const rotation = result.cell.type === 'prismatic'
        ? ` | Rotation ${ROT_LABELS[result.cellRotation]}`
        : '';
    return `${DIR_LABELS_SHORT[result.extrusionDir]} | ${GS_LABELS[result.gridStyle]}${rotation}`;
}
function clamp(n, min, max) {
    if (!Number.isFinite(n))
        return min;
    return Math.min(max, Math.max(min, n));
}
function normalizeShapeParams(raw) {
    const l = Math.max(10, raw.l || 10);
    const w = Math.max(10, raw.w || 10);
    const h = Math.max(10, raw.h || 10);
    const minFeature = 1;
    const maxCutL = raw.type === 'l_shape' ? Math.max(minFeature, l - minFeature) : Math.max(minFeature, l * 0.48);
    const maxCutW = raw.type === 'l_shape' ? Math.max(minFeature, w - minFeature) : Math.max(minFeature, w * 0.85);
    return {
        type: raw.type,
        l,
        w,
        h,
        cut_l: clamp(raw.cut_l || Math.min(l * 0.35, 150), minFeature, maxCutL),
        cut_w: clamp(raw.cut_w || Math.min(w * 0.35, 120), minFeature, maxCutW),
        stem_w: clamp(raw.stem_w || Math.min(l * 0.25, 80), minFeature, l),
        bar_h: clamp(raw.bar_h || Math.min(w * 0.25, 60), minFeature, w),
        top_mm: clamp(raw.top_mm || Math.min(l * 0.6, 200), minFeature, l),
    };
}
function syncShapeInputs(sp) {
    if (sp.type === 'l_shape') {
        ;
        el('dim_l').value = String(Math.round(sp.w * 10) / 10);
        el('dim_w').value = String(Math.round((sp.l - sp.cut_l) * 10) / 10);
        el('dim_h').value = String(sp.h);
        el('dim_cut_l').value = String(Math.round(sp.l * 10) / 10);
        el('dim_cut_w').value = String(Math.round((sp.w - sp.cut_w) * 10) / 10);
        el('dim_stem_w').value = String(Math.round(sp.stem_w * 10) / 10);
        el('dim_bar_h').value = String(Math.round(sp.bar_h * 10) / 10);
        el('dim_top_mm').value = String(Math.round(sp.top_mm * 10) / 10);
        return;
    }
    if (sp.type === 'u_shape') {
        ;
        el('dim_l').value = String(Math.round(sp.w * 10) / 10);
        el('dim_w').value = String(Math.round(sp.cut_l * 10) / 10);
        el('dim_h').value = String(sp.h);
        el('dim_cut_l').value = String(Math.round(sp.l * 10) / 10);
        el('dim_cut_w').value = String(Math.round(sp.cut_w * 10) / 10);
        el('dim_stem_w').value = String(Math.round(sp.stem_w * 10) / 10);
        el('dim_bar_h').value = String(Math.round(sp.bar_h * 10) / 10);
        el('dim_top_mm').value = String(Math.round(sp.top_mm * 10) / 10);
        return;
    }
    if (sp.type === 't_shape') {
        ;
        el('dim_l').value = String(Math.round((sp.w - sp.bar_h) * 10) / 10);
        el('dim_w').value = String(Math.round(sp.stem_w * 10) / 10);
        el('dim_h').value = String(sp.h);
        el('dim_cut_l').value = String(Math.round(sp.cut_l * 10) / 10);
        el('dim_cut_w').value = String(Math.round(sp.cut_w * 10) / 10);
        el('dim_stem_w').value = String(Math.round(sp.l * 10) / 10);
        el('dim_bar_h').value = String(Math.round(sp.bar_h * 10) / 10);
        el('dim_top_mm').value = String(Math.round(sp.top_mm * 10) / 10);
        return;
    }
    ;
    el('dim_l').value = String(sp.l);
    el('dim_w').value = String(sp.w);
    el('dim_h').value = String(sp.h);
    el('dim_cut_l').value = String(Math.round(sp.cut_l * 10) / 10);
    el('dim_cut_w').value = String(Math.round(sp.cut_w * 10) / 10);
    el('dim_stem_w').value = String(Math.round(sp.stem_w * 10) / 10);
    el('dim_bar_h').value = String(Math.round(sp.bar_h * 10) / 10);
    el('dim_top_mm').value = String(Math.round(sp.top_mm * 10) / 10);
}
function getShapePolygon(input) {
    const { type, l, w, cut_l, cut_w, stem_w, bar_h, top_mm } = normalizeShapeParams(input);
    switch (type) {
        case 'rectangle':
            return [{ x: 0, y: 0 }, { x: l, y: 0 }, { x: l, y: w }, { x: 0, y: w }];
        case 'l_shape':
            if (document.getElementById('shapeMirrorSelect')?.value === 'left') {
                return [
                    { x: 0, y: 0 }, { x: l, y: 0 }, { x: l, y: w },
                    { x: cut_l, y: w }, { x: cut_l, y: w - cut_w },
                    { x: 0, y: w - cut_w },
                ];
            }
            return [
                { x: 0, y: 0 }, { x: l, y: 0 }, { x: l, y: w - cut_w },
                { x: l - cut_l, y: w - cut_w }, { x: l - cut_l, y: w }, { x: 0, y: w },
            ];
        case 'u_shape':
            return [
                { x: 0, y: 0 }, { x: l, y: 0 }, { x: l, y: w },
                { x: l - cut_l, y: w }, { x: l - cut_l, y: cut_w },
                { x: cut_l, y: cut_w }, { x: cut_l, y: w }, { x: 0, y: w },
            ];
        case 't_shape': {
            const cx = (l - stem_w) / 2;
            return [
                { x: 0, y: 0 }, { x: l, y: 0 }, { x: l, y: bar_h },
                { x: cx + stem_w, y: bar_h }, { x: cx + stem_w, y: w },
                { x: cx, y: w }, { x: cx, y: bar_h }, { x: 0, y: bar_h },
            ];
        }
        case 'triangle':
            return [{ x: 0, y: 0 }, { x: l, y: 0 }, { x: 0, y: w }];
        case 'trapeze': {
            const off = (l - top_mm) / 2;
            return [{ x: 0, y: 0 }, { x: l, y: 0 }, { x: l - off, y: w }, { x: off, y: w }];
        }
    }
}
function pointOnSegment(px, py, a, b, eps = 1e-7) {
    const cross = (px - a.x) * (b.y - a.y) - (py - a.y) * (b.x - a.x);
    if (Math.abs(cross) > eps)
        return false;
    const dot = (px - a.x) * (b.x - a.x) + (py - a.y) * (b.y - a.y);
    if (dot < -eps)
        return false;
    const lenSq = (b.x - a.x) ** 2 + (b.y - a.y) ** 2;
    return dot <= lenSq + eps;
}
function pointInPolygon(px, py, poly) {
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
        if (pointOnSegment(px, py, poly[j], poly[i]))
            return true;
    }
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
        const xi = poly[i].x, yi = poly[i].y;
        const xj = poly[j].x, yj = poly[j].y;
        if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) {
            inside = !inside;
        }
    }
    return inside;
}
function polygonBounds(poly) {
    return poly.reduce((acc, p) => ({
        minX: Math.min(acc.minX, p.x),
        maxX: Math.max(acc.maxX, p.x),
        minY: Math.min(acc.minY, p.y),
        maxY: Math.max(acc.maxY, p.y),
    }), { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
}
function sampleAabbInsidePolygon(cx2d, cz2d, hw, hd, poly) {
    const minX = cx2d - hw - BOUNDARY_MARGIN;
    const maxX = cx2d + hw + BOUNDARY_MARGIN;
    const minY = cz2d - hd - BOUNDARY_MARGIN;
    const maxY = cz2d + hd + BOUNDARY_MARGIN;
    const bounds = polygonBounds(poly);
    if (minX < bounds.minX || maxX > bounds.maxX || minY < bounds.minY || maxY > bounds.maxY)
        return false;
    const samplesX = Math.max(2, Math.ceil((maxX - minX) / Math.max(4, Math.min(hw * 0.5, 12))));
    const samplesY = Math.max(2, Math.ceil((maxY - minY) / Math.max(4, Math.min(hd * 0.5, 12))));
    for (let ix = 0; ix <= samplesX; ix++) {
        const x = minX + ((maxX - minX) * ix) / samplesX;
        if (!pointInPolygon(x, minY, poly) || !pointInPolygon(x, maxY, poly))
            return false;
    }
    for (let iy = 1; iy < samplesY; iy++) {
        const y = minY + ((maxY - minY) * iy) / samplesY;
        if (!pointInPolygon(minX, y, poly) || !pointInPolygon(maxX, y, poly))
            return false;
    }
    return true;
}
// ─────────────────────────────────────────────────────────────────────────────
// PACKING  —  3D Oversample + Clip
//
// World coordinate system (fixed, matches housing mesh):
//   X ∈ [0 .. sp.l],  Y ∈ [0 .. sp.h],  Z ∈ [0 .. sp.w]
//
// The housing is an extruded prism: footprint polygon (l×w in X-Z plane)
// extruded along Y to height h.
//
// A cell fits if:
//   • its X-Z centre passes the footprint polygon test (with margin)
//   • its full X-Z footprint is inside (circle / AABB)
//   • its Y extent [cy - halfH, cy + halfH] is inside [0, sp.h]
//
// extrusionDir controls which world axis is the cell's long axis:
//   z  →  cell stands upright  (long axis = Y)
//   x  →  cell lies along X    (long axis = X)
//   y  →  cell lies along Z    (long axis = Z)
// ─────────────────────────────────────────────────────────────────────────────
// Check if a 2D circle is fully inside poly+margin (footprint test)
function circleFootprintOk(cx2d, cz2d, r, poly) {
    const steps = 24;
    for (let i = 0; i < steps; i++) {
        const a = (i / steps) * Math.PI * 2;
        if (!pointInPolygon(cx2d + (r + BOUNDARY_MARGIN) * Math.cos(a), cz2d + (r + BOUNDARY_MARGIN) * Math.sin(a), poly))
            return false;
    }
    return pointInPolygon(cx2d, cz2d, poly);
}
// Check if a 2D AABB is fully inside poly+margin (footprint test)
function rectFootprintOk(cx2d, cz2d, hw, hd, poly) {
    return sampleAabbInsidePolygon(cx2d, cz2d, hw, hd, poly);
}
function pack3D(sp, cell, extDir, gridStyle, offset, cellRotation = 0) {
    const { l, h, w } = sp;
    const poly = getShapePolygon(sp); // always original l×w polygon, never swapped
    // Cell half-dimensions in world axes depending on extrusion direction
    // extDir='z': cell is a cylinder/box standing along Y → footprint in X-Z
    // extDir='x': cell lies along X                       → footprint in Y-Z (rotated: long=X)
    // extDir='y': cell lies along Z                       → footprint in X-Y (rotated: long=Z)
    // Footprint half-sizes (the two axes perpendicular to the cell's long axis)
    let fpA, fpB; // half-size in the two "cross" directions
    let longH; // half-size along the cell's long axis
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    if (cell.type === 'round') {
        fpA = fpB = cell.diam / 2;
        longH = cell.height / 2;
    }
    else {
        const cross = getCrossDimensions(cell, cellRotation);
        fpA = cross.width / 2;
        fpB = cross.depth / 2;
        longH = cell.height / 2;
    }
    const stepFpA = fpA * 2 + gap;
    const stepFpB = fpB * 2 + gap;
    const stepLong = longH * 2 + LAYER_GAP;
    // ── Per-direction: which world axes carry (footprintA, footprintB, long)?
    // The housing footprint polygon is always in X-Z (coords: x=worldX, y=worldZ).
    // For every direction we must test the cell's X-Z projection against poly,
    // AND check that the cell's Y extent fits within [0..h].
    //
    // extDir='z': long axis=Y,  cross-section in X-Z  → stepX=stepFpA, stepZ=stepFpB, stepY=stepLong
    // extDir='x': long axis=X,  cross-section in Y-Z  → stepX=stepLong, stepZ=fpA(~radius), stepY=stepFpB
    //   but the Z footprint of each cell still matters for the polygon test:
    //   the cell occupies X=[cx-longH..cx+longH], Y=[cy-fpB..cy+fpB], Z=[cz-fpA..cz+fpA]
    //   → polygon test: (cx, cz) with half-sizes (0=ignored for long axis, fpA for Z)
    //   Actually we project the cell onto X-Z: occupies X=[cx-longH..cx+longH], Z=[cz-fpA..cz+fpA]
    //   → use rectFootprintOk(cx, cz, longH, fpA) against poly, plus Y range check
    //
    // extDir='y': long axis=Z,  cross-section in X-Y
    //   cell occupies X=[cx-fpA..cx+fpA], Y=[cy-fpB..cy+fpB], Z=[cz-longH..cz+longH]
    //   → polygon test: (cx, cz) with half-sizes (fpA for X, longH for Z)
    //   → use rectFootprintOk(cx, cz, fpA, longH) / circleFootprintOk(cx, cz, fpA) with Z extent,
    //      plus Y range check
    // Helper: does the cell's full X-Z footprint fit inside poly?
    function xzOk(cx, cz, hx, hz) {
        if (cell.type === 'round') {
            // For round cells the cross-section is always circular with radius = diam/2
            // regardless of direction. hx == hz == fpA always for round cells.
            return circleFootprintOk(cx, cz, hx, poly);
        }
        return rectFootprintOk(cx, cz, hx, hz, poly);
    }
    const positions = [];
    if (extDir === 'z') {
        // long=Y, cross in X-Z: hx=fpA, hz=fpB
        // stepX=stepFpA, stepZ=stepFpB, stepY=stepLong
        const stepX = stepFpA, stepZ = stepFpB, stepY = stepLong;
        // For honeycomb: row pitch in Z = stepX * √3/2 so diagonal gap equals the cell gap
        const hcStepZ = stepX * (Math.sqrt(3) / 2);
        const oX = ((offset.ox % stepX) + stepX) % stepX;
        const oZ = gridStyle === 'honeycomb'
            ? ((offset.oz % hcStepZ) + hcStepZ) % hcStepZ
            : ((offset.oz % stepZ) + stepZ) % stepZ;
        const oY = ((offset.oy % stepY) + stepY) % stepY;
        for (let cy = longH + oY - stepY; cy <= h + stepY; cy += stepY) {
            if (cy - longH < 0 || cy + longH > h)
                continue;
            if (gridStyle === 'honeycomb') {
                let row = 0;
                for (let cz = fpB + oZ - hcStepZ; cz <= w + hcStepZ; cz += hcStepZ, row++) {
                    const hcOff = row % 2 === 0 ? 0 : stepX / 2;
                    for (let cx = fpA + oX - stepX + hcOff; cx <= l + stepX; cx += stepX) {
                        if (xzOk(cx, cz, fpA, fpB))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
            else {
                for (let cx = fpA + oX - stepX; cx <= l + stepX; cx += stepX) {
                    for (let cz = fpB + oZ - stepZ; cz <= w + stepZ; cz += stepZ) {
                        if (xzOk(cx, cz, fpA, fpB))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
        }
    }
    else if (extDir === 'x') {
        // long=X. Cross-section is a circle (radius fpA) in the Y-Z plane.
        // Honeycomb in Y-Z: rows along Z, offset every other row in Z by stepZ/2,
        // row pitch in Y = stepZ * √3/2  (so diagonal wall-to-wall gap = cell gap).
        const hzXZ = fpB;
        const hxXZ = longH;
        const stepX = stepLong;
        const stepZ = stepFpB; // Z centre-to-centre
        const hcStepY = stepZ * (Math.sqrt(3) / 2); // honeycomb row pitch in Y
        const stepY = stepFpA; // grid row pitch in Y
        const oX = ((offset.ox % stepX) + stepX) % stepX;
        const oZ = ((offset.oz % stepZ) + stepZ) % stepZ;
        const oY_hc = ((offset.oy % hcStepY) + hcStepY) % hcStepY;
        const oY_grid = ((offset.oy % stepY) + stepY) % stepY;
        for (let cx = longH + oX - stepX; cx <= l + stepX; cx += stepX) {
            if (cx - longH < 0 || cx + longH > l)
                continue;
            if (gridStyle === 'honeycomb') {
                let row = 0;
                for (let cy = fpA + oY_hc - hcStepY; cy <= h + hcStepY; cy += hcStepY, row++) {
                    if (cy - fpA < 0 || cy + fpA > h)
                        continue;
                    const hcOff = row % 2 === 0 ? 0 : stepZ / 2;
                    for (let cz = hzXZ + oZ - stepZ + hcOff; cz <= w + stepZ; cz += stepZ) {
                        if (rectFootprintOk(cx, cz, hxXZ, hzXZ, poly))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
            else {
                for (let cy = fpA + oY_grid - stepY; cy <= h + stepY; cy += stepY) {
                    if (cy - fpA < 0 || cy + fpA > h)
                        continue;
                    for (let cz = hzXZ + oZ - stepZ; cz <= w + stepZ; cz += stepZ) {
                        if (rectFootprintOk(cx, cz, hxXZ, hzXZ, poly))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
        }
    }
    else {
        // extDir='y': long=Z. Cross-section is a circle (radius fpA) in the X-Y plane.
        // Honeycomb in X-Y: rows along X, offset every other row in X by stepX/2,
        // row pitch in Y = stepX * √3/2.
        const hxXZ = fpA;
        const hzXZ = longH;
        const stepZ = stepLong;
        const stepX = stepFpA; // X centre-to-centre
        const hcStepY = stepX * (Math.sqrt(3) / 2); // honeycomb row pitch in Y
        const stepY = stepFpB; // grid row pitch in Y
        const oX = ((offset.ox % stepX) + stepX) % stepX;
        const oZ = ((offset.oz % stepZ) + stepZ) % stepZ;
        const oY_hc = ((offset.oy % hcStepY) + hcStepY) % hcStepY;
        const oY_grid = ((offset.oy % stepY) + stepY) % stepY;
        for (let cz = longH + oZ - stepZ; cz <= w + stepZ; cz += stepZ) {
            if (cz - longH < 0 || cz + longH > w)
                continue;
            if (gridStyle === 'honeycomb') {
                let row = 0;
                for (let cy = fpB + oY_hc - hcStepY; cy <= h + hcStepY; cy += hcStepY, row++) {
                    if (cy - fpB < 0 || cy + fpB > h)
                        continue;
                    const hcOff = row % 2 === 0 ? 0 : stepX / 2;
                    for (let cx = fpA + oX - stepX + hcOff; cx <= l + stepX; cx += stepX) {
                        if (rectFootprintOk(cx, cz, hxXZ, hzXZ, poly))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
            else {
                for (let cy = fpB + oY_grid - stepY; cy <= h + stepY; cy += stepY) {
                    if (cy - fpB < 0 || cy + fpB > h)
                        continue;
                    for (let cx = hxXZ + oX - stepX; cx <= l + stepX; cx += stepX) {
                        if (rectFootprintOk(cx, cz, hxXZ, hzXZ, poly))
                            positions.push({ x: cx, y: cy, z: cz });
                    }
                }
            }
        }
    }
    return positions;
}
function getOffsetPeriods(cell, extDir, gridStyle, cellRotation = 0) {
    const { stepX, stepY, stepZ } = getWorldStepSizes(cell, extDir, cellRotation, gridStyle);
    return { ox: stepX, oy: stepY, oz: stepZ };
}
function runAllCombinations(sp, cell, gridStyle, gridOffset = { ox: 0, oy: 0, oz: 0 }) {
    const results = [];
    const extrusionDirs = ['z', 'x', 'y'];
    const gridStyles = cell.type === 'round'
        ? gridStyle === 'honeycomb' ? ['honeycomb'] : ['grid', 'honeycomb']
        : ['grid'];
    const cellRotations = cell.type === 'prismatic' ? [0, 90] : [0];
    const isManual = gridOffset.ox !== 0 || gridOffset.oy !== 0 || gridOffset.oz !== 0;
    for (const extDir of extrusionDirs) {
        for (const cellRotation of cellRotations) {
            for (const gs of gridStyles) {
                let bestPositions = [];
                let bestOffset = { ...gridOffset };
                if (isManual) {
                    bestPositions = pack3D(sp, cell, extDir, gs, gridOffset, cellRotation);
                    bestOffset = { ...gridOffset };
                }
                else {
                    // Auto-sweep 6³ = 216 offset combinations to find the best placement
                    const periods = getOffsetPeriods(cell, extDir, gs, cellRotation);
                    const S = sp.type === 'rectangle' ? 6 : 8;
                    for (let si = 0; si < S; si++) {
                        for (let sj = 0; sj < S; sj++) {
                            for (let sk = 0; sk < S; sk++) {
                                const off = {
                                    ox: (si / S) * periods.ox,
                                    oy: (sj / S) * periods.oy,
                                    oz: (sk / S) * periods.oz,
                                };
                                const pos = pack3D(sp, cell, extDir, gs, off, cellRotation);
                                if (pos.length > bestPositions.length) {
                                    bestPositions = pos;
                                    bestOffset = off;
                                }
                            }
                        }
                    }
                }
                if (bestPositions.length === 0)
                    continue;
                results.push({
                    total: bestPositions.length,
                    extrusionDir: extDir,
                    gridStyle: gs,
                    cellRotation,
                    positions: bestPositions,
                    polygon: getShapePolygon(sp),
                    sp: { ...sp },
                    cell: { ...cell },
                    gridOffset: bestOffset,
                    source: 'space',
                });
            }
        }
    }
    results.sort((a, b) => b.total - a.total);
    return results;
}
// ─────────────────────────────────────────────────────────────────────────────
// THREE.JS SETUP
// ─────────────────────────────────────────────────────────────────────────────
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(devicePixelRatio);
renderer.shadowMap.enabled = true;
renderer.setClearColor(0xe8eef6, 1);
const scene = new THREE.Scene();
const camera = new THREE.OrthographicCamera(-500, 500, 500, -500, -10000, 10000);
camera.position.set(600, 500, 700);
camera.lookAt(0, 0, 0);
// Lights
scene.add(new THREE.AmbientLight(0xffffff, 2.0));
const dl = new THREE.DirectionalLight(0xffffff, 1.4);
dl.position.set(200, 400, 300);
scene.add(dl);
const dl2 = new THREE.DirectionalLight(0xaaccff, 0.5);
dl2.position.set(-300, 100, -200);
scene.add(dl2);
scene.add(new THREE.AxesHelper(80));
// Resize
function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    renderer.setSize(w, h, false);
    const ortho = camera;
    const aspect = w / h;
    const half = ortho.right; // current half-size
    ortho.left = -half * aspect;
    ortho.right = half * aspect;
    ortho.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(canvas);
resize();
// ─────────────────────────────────────────────────────────────────────────────
// ORBIT CONTROLS
// ─────────────────────────────────────────────────────────────────────────────
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = false; // damping causes continuous re-renders and flicker
controls.mouseButtons = {
    LEFT: THREE.MOUSE.ROTATE,
    MIDDLE: THREE.MOUSE.DOLLY,
    RIGHT: THREE.MOUSE.PAN,
};
controls.minDistance = 10;
controls.maxDistance = 8000;
let pointerDown = null;
canvas.addEventListener('pointerdown', event => {
    pointerDown = { x: event.clientX, y: event.clientY };
});
canvas.addEventListener('pointerup', event => {
    if (!pointerDown)
        return;
    const moved = Math.hypot(event.clientX - pointerDown.x, event.clientY - pointerDown.y);
    pointerDown = null;
    if (moved > 5)
        return;
    pickScene(event.clientX, event.clientY);
});
function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}
animate();
// ─────────────────────────────────────────────────────────────────────────────
// SCENE MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────
let visMode = 'pack';
let packViewMode = 'electrical';
let explodeAmount = 70;
let definitionMode = 'space';
let electricalMode = 'target';
let modelUiHidden = false;
let resultsPanelVisible = false;
let currentResult = null;
let sceneObjects = [];
let bboxObject = null;
let currentRenderResult = null;
let selectedLayerKey = null;
let selectedBusbarGroup = null;
let selectedComponentName = null;
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
// Grid offset in mm (3D, applied to the active result)
let gridOffset = { ox: 0, oy: 0, oz: 0 };
function clearScene() {
    sceneObjects.forEach(o => scene.remove(o));
    sceneObjects = [];
}
function addObj(obj) {
    scene.add(obj);
    sceneObjects.push(obj);
}
function objectPickKind(obj) {
    let cur = obj;
    while (cur) {
        if (cur.userData.pickKind)
            return cur.userData.pickKind;
        cur = cur.parent;
    }
    return undefined;
}
function objectPickData(obj) {
    let cur = obj;
    while (cur) {
        if (cur.userData.pickKind)
            return cur;
        cur = cur.parent;
    }
    return obj;
}
function refreshSelection() {
    if (!currentResult)
        return;
    visualizeResult(currentResult, true);
}
function updateSelectionPanel(title = 'Modell-Information', lines = ['Klicken Sie eine Zellebene, Busbar oder Baugruppe an.']) {
    const panel = document.getElementById('componentInfoPanel');
    if (!panel)
        return;
    panel.innerHTML = `
    <div class="component-info-title">${title}</div>
    ${lines.map(line => `<div class="component-info-line">${line}</div>`).join('')}
  `;
}
function syncModelUiToggle() {
    const btn = document.getElementById('btnModelUi');
    if (btn) {
        btn.classList.toggle('active', modelUiHidden);
        btn.textContent = modelUiHidden ? 'UI ein' : 'UI aus';
        btn.title = modelUiHidden ? 'Modell-UI einblenden' : 'Modell-UI ausblenden';
    }
    const panel = document.getElementById('componentInfoPanel');
    if (panel)
        panel.style.display = modelUiHidden ? 'none' : '';
    const hint = document.querySelector('.controls-hint');
    if (hint)
        hint.style.display = modelUiHidden ? 'none' : '';
    const resultsPanel = document.getElementById('resultsPanel');
    if (resultsPanel)
        resultsPanel.style.display = resultsPanelVisible && !modelUiHidden ? '' : 'none';
}
function setResultsPanelVisible(visible) {
    resultsPanelVisible = visible;
    const resultsPanel = document.getElementById('resultsPanel');
    if (resultsPanel)
        resultsPanel.style.display = visible && !modelUiHidden ? '' : 'none';
}
function setModelUiHidden(hidden) {
    modelUiHidden = hidden;
    if (hidden) {
        selectedLayerKey = null;
        selectedBusbarGroup = null;
        selectedComponentName = null;
    }
    syncModelUiToggle();
    if (currentResult)
        visualizeResult(currentResult, true);
}
function pickScene(clientX, clientY) {
    if (modelUiHidden)
        return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hit = raycaster
        .intersectObjects(sceneObjects, true)
        .find(intersection => objectPickKind(intersection.object));
    if (!hit || !currentRenderResult) {
        selectedLayerKey = null;
        selectedBusbarGroup = null;
        selectedComponentName = null;
        updateSelectionPanel();
        refreshSelection();
        return;
    }
    const picked = objectPickData(hit.object);
    if (picked.userData.pickKind === 'cell') {
        const points = picked.userData.instancePoints;
        const p = hit.instanceId !== undefined ? points?.[hit.instanceId] : undefined;
        if (!p)
            return;
        selectedLayerKey = Math.round(layerCoordValue(currentRenderResult, p) * 10) / 10;
        selectedBusbarGroup = null;
        selectedComponentName = null;
        const layerCells = currentRenderResult.positions.filter(pos => Math.round(layerCoordValue(currentRenderResult, pos) * 10) / 10 === selectedLayerKey).length;
        updateSelectionPanel('Zellebene ausgewählt', [
            `Ebene: ${selectedLayerKey}`,
            `Zellen in dieser Ebene: ${layerCells}`,
            'Funktion: elektrochemische Speicherebene im Pack.',
        ]);
        refreshSelection();
        return;
    }
    if (picked.userData.pickKind === 'busbar') {
        selectedBusbarGroup = Number(picked.userData.busbarGroup);
        selectedLayerKey = null;
        selectedComponentName = null;
        const rawRole = String(picked.userData.busbarRole ?? '');
        const role = rawRole === 'series'
            ? 'Serienbrücke'
            : rawRole === 'Pluspol'
                ? 'Pluspol'
                : rawRole === 'Minuspol'
                    ? 'Minuspol'
                    : 'Parallelverbinder';
        const result = currentRenderResult;
        const electrical = getElectricalSummaryData();
        const topology = result ? createElectricalTopology(result, electrical.series, electrical.parallel) : null;
        const stackCount = topology?.groups[selectedBusbarGroup]?.stacks.length ?? 0;
        const visiblePolarity = visibleTopPolarityForGroup(selectedBusbarGroup);
        updateSelectionPanel(`Busbar-Gruppe G${selectedBusbarGroup + 1}`, [
            `Art: ${role}`,
            `Zellen in dieser Parallelgruppe: ${stackCount}`,
            `Sichtbare obere Polung dieser Seriengruppe: ${polarityLabel(visiblePolarity)}`,
            `Auslegung: ${electrical.series}s${electrical.parallel}p`,
            topology ? `Parallelgruppe liegt innerhalb einer Ebene: ${topology.parallel}p` : '',
            'Hinweis: Benachbarte Seriengruppen werden in der Darstellung abwechselnd gepolt, damit die Serienbruecken klar sichtbar sind.',
        ].filter(Boolean));
        refreshSelection();
        return;
    }
    if (picked.userData.pickKind === 'component') {
        selectedLayerKey = null;
        selectedBusbarGroup = null;
        selectedComponentName = String(picked.userData.componentName ?? '');
        updateSelectionPanel(selectedComponentName || 'Baugruppe', [
            `Funktion: ${picked.userData.componentRole ?? 'mechanische Pack-Komponente'}`,
            `Menge: ${picked.userData.componentQty ?? 'modellabhaengig'}`,
        ]);
        refreshSelection();
    }
}
function updateBoundingBox(_sp) {
    if (bboxObject) {
        scene.remove(bboxObject);
        bboxObject = null;
    }
    // Bounding box removed — housing shape mesh already shows the volume
}
// ─────────────────────────────────────────────────────────────────────────────
// SHAPE MESH
// ─────────────────────────────────────────────────────────────────────────────
// The housing shape is ALWAYS built from the original sp (l × w footprint, h tall),
// centered at world origin (X: -l/2..l/2, Y: 0..h, Z: -w/2..w/2).
// Only cells change orientation per extrusionDir — the housing never moves.
function buildShapeMesh(result) {
    const { sp } = result;
    const { l, w, h } = sp;
    // Always use the original footprint polygon (l × w) extruded to height h
    const origPolygon = getShapePolygon(sp);
    const pts = origPolygon.map(p => new THREE.Vector2(p.x - l / 2, p.y - w / 2));
    const shape = new THREE.Shape(pts);
    // Extrude upward (along local Z of Shape = world Y after rotation below)
    const geo = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false });
    const mat = new THREE.MeshStandardMaterial({
        color: 0xadc8e0,
        transparent: true,
        opacity: visMode === 'skeleton' ? 0.04 : (visMode === 'pack' || visMode === 'explode') ? 0.10 : 0.22,
        side: THREE.DoubleSide,
        wireframe: visMode === 'wire',
        depthWrite: false, // housing is transparent — don't block cell depth writes
        polygonOffset: true,
        polygonOffsetFactor: 1, // push housing faces slightly back to avoid z-fighting
        polygonOffsetUnits: 1,
    });
    const mesh = new THREE.Mesh(geo, mat);
    const wf = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0x5588aa, opacity: 0.55, transparent: true }));
    const grp = new THREE.Group();
    grp.add(mesh, wf);
    // ExtrudeGeometry extrudes along local +Z. Rotate so it extrudes along world +Y.
    grp.rotation.x = -Math.PI / 2;
    return grp;
}
// Builds a visible grid overlay: lines along all three axes through the cell grid.
// Shows the repeating cell pattern as thin lines so the user can see what
// the offset sliders are doing.
function buildGridLines(result) {
    const { cell, gridOffset, extrusionDir, sp } = result;
    const { l, w, h } = sp;
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    // Step sizes per world axis — depend on extrusion direction
    let stepX, stepY, stepZ;
    if (cell.type === 'round') {
        const d = cell.diam;
        if (extrusionDir === 'z') {
            stepX = d + gap;
            stepZ = d + gap;
            stepY = cell.height + LAYER_GAP;
        }
        else if (extrusionDir === 'x') {
            stepY = d + gap;
            stepZ = d + gap;
            stepX = cell.height + LAYER_GAP;
        }
        else {
            stepX = d + gap;
            stepY = d + gap;
            stepZ = cell.height + LAYER_GAP;
        }
    }
    else {
        const pc = cell;
        if (extrusionDir === 'z') {
            stepX = pc.width + gap;
            stepZ = pc.depth + gap;
            stepY = pc.height + LAYER_GAP;
        }
        else if (extrusionDir === 'x') {
            stepY = pc.width + gap;
            stepZ = pc.depth + gap;
            stepX = pc.height + LAYER_GAP;
        }
        else {
            stepX = pc.width + gap;
            stepY = pc.depth + gap;
            stepZ = pc.height + LAYER_GAP;
        }
    }
    const worldSteps = getWorldStepSizes(cell, extrusionDir, result.cellRotation, result.gridStyle);
    stepX = worldSteps.stepX;
    stepY = worldSteps.stepY;
    stepZ = worldSteps.stepZ;
    const ox = ((gridOffset.ox % stepX) + stepX) % stepX;
    const oy = ((gridOffset.oy % stepY) + stepY) % stepY;
    const oz = ((gridOffset.oz % stepZ) + stepZ) % stepZ;
    const verts = [];
    // Housing world bounds: X ∈ [0..l], Y ∈ [0..h], Z ∈ [0..w]
    // Housing mesh is centered: X-l/2, Y as-is, Z → -(Z - w/2)
    // Grid lines in mesh-centred coords: X ∈ [-l/2..l/2], Y ∈ [0..h], Z ∈ [-w/2..w/2]
    // Lines along Y (vertical), varying X & Z
    for (let gx = ox - stepX; gx <= l + stepX; gx += stepX) {
        const wx = gx - l / 2;
        if (wx < -l / 2 || wx > l / 2)
            continue;
        for (let gz = oz - stepZ; gz <= w + stepZ; gz += stepZ) {
            const wz = -(gz - w / 2);
            if (wz < -w / 2 || wz > w / 2)
                continue;
            verts.push(wx, 0, wz, wx, h, wz);
        }
    }
    // Lines along X (horizontal in XZ-plane), varying Y & Z
    for (let gy = oy - stepY; gy <= h + stepY; gy += stepY) {
        if (gy < 0 || gy > h)
            continue;
        for (let gz = oz - stepZ; gz <= w + stepZ; gz += stepZ) {
            const wz = -(gz - w / 2);
            if (wz < -w / 2 || wz > w / 2)
                continue;
            verts.push(-l / 2, gy, wz, l / 2, gy, wz);
        }
    }
    if (verts.length === 0)
        return new THREE.Group();
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(verts), 3));
    const mat = new THREE.LineBasicMaterial({ color: 0xee8800, opacity: 0.55, transparent: true });
    const lines = new THREE.LineSegments(geo, mat);
    lines.frustumCulled = false;
    return lines;
}
// ─────────────────────────────────────────────────────────────────────────────
// DIMENSION LABELS
// ─────────────────────────────────────────────────────────────────────────────
function makeTextSprite(text, color = '#1a2430') {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 96;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 512, 96);
    ctx.font = 'bold 34px "JetBrains Mono", "Courier New", monospace';
    ctx.fillStyle = 'rgba(255,255,255,0.82)';
    ctx.strokeStyle = 'rgba(85,136,170,0.35)';
    ctx.lineWidth = 3;
    ctx.roundRect(10, 18, 492, 60, 10);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 256, 48);
    const tex = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false, depthWrite: false, transparent: true });
    const sprite = new THREE.Sprite(mat);
    sprite.renderOrder = 1000;
    return sprite;
}
function makeDimLine(a, b, color) {
    const geo = new THREE.BufferGeometry().setFromPoints([a, b]);
    const mat = new THREE.LineBasicMaterial({ color, depthTest: false, depthWrite: false, transparent: true, opacity: 0.9 });
    const line = new THREE.Line(geo, mat);
    line.renderOrder = 999;
    return line;
}
// Builds dimension annotations for the housing.
// Housing mesh world coords: X ∈ [-l/2..l/2], Y ∈ [0..h], Z ∈ [-w/2..w/2]
// Polygon space → world: wx = px - l/2,  wz = -(pz - w/2)
function buildDimensionLines(sp, liftHorizontalDims = false) {
    const { type, l, w, h, cut_l, cut_w, stem_w, bar_h, top_mm } = sp;
    const grp = new THREE.Group();
    const col = 0x0055aa;
    const col2 = 0x007755; // secondary dims (cutouts etc.)
    const ref = Math.max(l, w, h);
    const off = ref * 0.07 + 6; // perpendicular offset for dim line
    const sScale = ref * 0.16; // sprite scale
    const baseY = liftHorizontalDims ? h + Math.max(ref * 0.035, 8) : 0;
    grp.renderOrder = 998;
    // Convert polygon-space (px ∈ [0..l], pz ∈ [0..w]) to world XZ at given Y
    function pw(px, pz, y = baseY) {
        return new THREE.Vector3(px - l / 2, y, -(pz - w / 2));
    }
    function addDim(p1, p2, extDir, label, color = col) {
        const o = extDir.clone().normalize().multiplyScalar(off);
        const a = p1.clone().add(o);
        const b = p2.clone().add(o);
        grp.add(makeDimLine(a, b, color));
        grp.add(makeDimLine(p1.clone(), a.clone(), color));
        grp.add(makeDimLine(p2.clone(), b.clone(), color));
        const mid = a.clone().lerp(b, 0.5).add(extDir.clone().normalize().multiplyScalar(sScale * 0.38));
        const sprite = makeTextSprite(label);
        sprite.position.copy(mid);
        sprite.scale.set(sScale * 1.9, sScale * 0.36, 1);
        grp.add(sprite);
    }
    // Polygon space → world coordinate mapping:
    //   pw(px=0,  pz)  → worldX = -l/2  (left)
    //   pw(px=l,  pz)  → worldX = +l/2  (right)
    //   pw(px, pz=0)   → worldZ = +w/2  (front in world)
    //   pw(px, pz=w)   → worldZ = -w/2  (back in world)
    // "Away from bounding box" directions:
    const outFront = new THREE.Vector3(0, 0, 1); // pz=0 edge  → worldZ+
    const outBack = new THREE.Vector3(0, 0, -1); // pz=w edge  → worldZ-
    const outRight = new THREE.Vector3(1, 0, 0); // px=l edge  → worldX+
    const outLeft = new THREE.Vector3(-1, 0, 0); // px=0 edge  → worldX-
    // ── Always: L (X), W (Z), H (Y) ──────────────────────────────────────────
    // L: front edge (pz=0), offset outFront
    addDim(pw(0, 0), pw(l, 0), outFront, `Laenge ${fmtMm(l)} mm`);
    // W: right edge (px=l), offset outRight
    addDim(pw(l, 0), pw(l, w), outRight, `Breite ${fmtMm(w)} mm`);
    // H: right-front vertical edge (px=l, pz=0), offset outRight
    addDim(pw(l, 0, 0), pw(l, 0, h), outRight, `Hoehe ${fmtMm(h)} mm`);
    // ── Shape-specific secondary dims ────────────────────────────────────────
    if (type === 'l_shape') {
        // Notch is at top-right in polygon space: px ∈ [l-cut_l..l], pz ∈ [w-cut_w..w]
        // cut_l: along the inner horizontal step (pz = w-cut_w), offset outBack (away from notch)
        addDim(pw(l - cut_l, w - cut_w), pw(l, w - cut_w), outBack, `Ausschnitt L ${fmtMm(cut_l)} mm`, col2);
        // cut_w: along the inner vertical step (px = l-cut_l), offset outLeft (into open space)
        addDim(pw(l - cut_l, w - cut_w), pw(l - cut_l, w), outLeft, `Ausschnitt B ${fmtMm(cut_w)} mm`, col2);
    }
    else if (type === 'u_shape') {
        // U gap opens at pz=w. cut_l is the leg width, cut_w is the bridge/back width.
        addDim(pw(cut_l, cut_w), pw(l - cut_l, cut_w), outBack, `Luecke B ${fmtMm(l - cut_l * 2)} mm`, col2);
        addDim(pw(cut_l, cut_w), pw(cut_l, w), outLeft, `Luecke T ${fmtMm(w - cut_w)} mm`, col2);
    }
    else if (type === 't_shape') {
        const cx = (l - stem_w) / 2;
        // stem_w: along the bar/stem boundary (pz=bar_h), offset outBack
        addDim(pw(cx, bar_h), pw(cx + stem_w, bar_h), outBack, `Stab B ${fmtMm(stem_w)} mm`, col2);
        // bar_h: right edge of bar (px=l), offset outRight
        addDim(pw(l, 0), pw(l, bar_h), outRight, `Balken T ${fmtMm(bar_h)} mm`, col2);
    }
    else if (type === 'triangle') {
        // Hypotenuse floating label
        const hyp = Math.round(Math.sqrt(l * l + w * w));
        const mid = pw(l / 2, w / 2);
        mid.x += off * 0.8;
        mid.z -= off * 0.4;
        const sprite = makeTextSprite(`Schraege ${hyp} mm`, '#007755');
        sprite.position.copy(mid);
        sprite.scale.set(sScale * 1.9, sScale * 0.36, 1);
        grp.add(sprite);
    }
    else if (type === 'trapeze') {
        const edgeOff = (l - top_mm) / 2;
        // top edge (pz=w = worldZ back), offset outBack
        addDim(pw(edgeOff, w), pw(l - edgeOff, w), outBack, `Oben ${fmtMm(top_mm)} mm`, col2);
    }
    return grp;
}
// ─────────────────────────────────────────────────────────────────────────────
// VISUALIZE RESULT
// ─────────────────────────────────────────────────────────────────────────────
const CELL_COLORS = [0x0077cc, 0x00aa77, 0xdd6600, 0x9933cc];
const PACK_CELL_COLORS = [0x006fba, 0x0d8fa3, 0x2e8a68, 0x4c7fd1];
function makeCellGeo(cell, extDir, cellRotation = 0) {
    // Geometry is always built with the long axis along Y (Three.js CylinderGeometry default).
    // Rotation to the correct world axis is applied via instanceQuat below.
    const h = cell.height;
    if (cell.type === 'round') {
        return new THREE.CylinderGeometry(cell.diam / 2, cell.diam / 2, h, 16);
    }
    // prismatic: width × depth cross-section, height is long axis
    // extDir=z → stands along Y: X=width, Z=depth
    // extDir=x → lies along X (rotated later): X=width, Z=depth
    // extDir=y → lies along Z (rotated later): X=width, Z=depth
    void extDir;
    const cross = getCrossDimensions(cell, cellRotation);
    return new THREE.BoxGeometry(cross.width, h, cross.depth);
}
function worldToScenePoint(p, sp) {
    return new THREE.Vector3(p.x - sp.l / 2, p.y, -(p.z - sp.w / 2));
}
function longAxisVector(extDir) {
    if (extDir === 'x')
        return new THREE.Vector3(1, 0, 0);
    if (extDir === 'y')
        return new THREE.Vector3(0, 0, -1);
    return new THREE.Vector3(0, 1, 0);
}
function setInstance(mesh, idx, position, quat, scale = new THREE.Vector3(1, 1, 1)) {
    const m = new THREE.Matrix4();
    m.compose(position, quat, scale);
    mesh.setMatrixAt(idx, m);
}
function addTerminalMarker(group, text, position, color, scale) {
    if (modelUiHidden)
        return;
    const sprite = makeTextSprite(text, color);
    sprite.position.copy(position);
    sprite.scale.set(scale, scale * 0.35, 1);
    group.add(sprite);
}
function addPolarityDot(group, position, color, size, groupIdx, polarity) {
    const dot = new THREE.Mesh(new THREE.SphereGeometry(size, 16, 10), new THREE.MeshStandardMaterial({
        color,
        roughness: 0.26,
        metalness: 0.42,
        emissive: selectedBusbarGroup === groupIdx ? color : 0x000000,
        emissiveIntensity: selectedBusbarGroup === groupIdx ? 0.18 : 0,
    }));
    dot.position.copy(position);
    dot.userData.pickKind = 'busbar';
    dot.userData.busbarGroup = groupIdx;
    dot.userData.busbarRole = polarity === 'plus' ? 'Pluspol' : 'Minuspol';
    dot.renderOrder = 30;
    group.add(dot);
    return dot;
}
function addNickelStrip(group, a, b, width, thickness, mat) {
    const mid = a.clone().lerp(b, 0.5);
    const len = a.distanceTo(b);
    if (len <= 0)
        return null;
    const strip = new THREE.Mesh(new THREE.BoxGeometry(len, thickness, width), mat);
    strip.position.copy(mid);
    const dir = b.clone().sub(a).normalize();
    strip.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir);
    group.add(strip);
    return strip;
}
function perpendicularBusbarDirection(axis) {
    const axisN = axis.clone().normalize();
    const reference = Math.abs(axisN.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
    const sideDir = new THREE.Vector3().crossVectors(axisN, reference);
    if (sideDir.lengthSq() < 0.001)
        sideDir.set(0, 0, 1);
    return sideDir.normalize();
}
function addLayerParallelRails(group, stacks, pointForCell, axis, railWidth, tapWidth, mat, groupIdx, markBusbar, railOffset) {
    const axisN = axis.clone().normalize();
    const sideDir = perpendicularBusbarDirection(axisN);
    stacks.forEach(stack => {
        if (stack.cells.length < 2)
            return;
        const contacts = stack.cells
            .map(pointForCell)
            .sort((a, b) => a.dot(axisN) - b.dot(axisN));
        const railPts = contacts.map(p => p.clone().add(sideDir.clone().multiplyScalar(railOffset)));
        contacts.forEach((p, i) => {
            markBusbar(addNickelStrip(group, p, railPts[i], tapWidth, 1.8, mat), groupIdx, 'parallel');
        });
        for (let i = 1; i < railPts.length; i++) {
            markBusbar(addNickelStrip(group, railPts[i - 1], railPts[i], railWidth, 2.0, mat), groupIdx, 'parallel');
        }
    });
}
function visibleTopPolarityForGroup(groupIdx) {
    return groupIdx % 2 === 0 ? 'plus' : 'minus';
}
function polarityColor(polarity) {
    return polarity === 'plus' ? 0xd54438 : 0x26323d;
}
function polarityLabel(polarity) {
    return polarity === 'plus' ? '+' : '-';
}
function oppositePolarity(polarity) {
    return polarity === 'plus' ? 'minus' : 'plus';
}
function cellSceneHalfExtents(cell, result, instanceQuat) {
    const cross = getCrossDimensions(cell, result.cellRotation);
    const localHalf = cell.type === 'round'
        ? new THREE.Vector3(cell.diam / 2, cell.height / 2, cell.diam / 2)
        : new THREE.Vector3(cross.width / 2, cell.height / 2, cross.depth / 2);
    const basisX = new THREE.Vector3(1, 0, 0).applyQuaternion(instanceQuat);
    const basisY = new THREE.Vector3(0, 1, 0).applyQuaternion(instanceQuat);
    const basisZ = new THREE.Vector3(0, 0, 1).applyQuaternion(instanceQuat);
    return new THREE.Vector3(Math.abs(basisX.x) * localHalf.x + Math.abs(basisY.x) * localHalf.y + Math.abs(basisZ.x) * localHalf.z, Math.abs(basisX.y) * localHalf.x + Math.abs(basisY.y) * localHalf.y + Math.abs(basisZ.y) * localHalf.z, Math.abs(basisX.z) * localHalf.x + Math.abs(basisY.z) * localHalf.y + Math.abs(basisZ.z) * localHalf.z);
}
function addPackEnclosure(group, result, instanceQuat, explodeUnit) {
    const { cell, sp, positions } = result;
    if (!positions.length)
        return;
    const half = cellSceneHalfExtents(cell, result, instanceQuat);
    const scenePts = positions.map(p => worldToScenePoint(p, sp));
    const minX = Math.min(...scenePts.map(p => p.x - half.x));
    const maxX = Math.max(...scenePts.map(p => p.x + half.x));
    const minY = Math.min(...scenePts.map(p => p.y - half.y));
    const maxY = Math.max(...scenePts.map(p => p.y + half.y));
    const minZ = Math.min(...scenePts.map(p => p.z - half.z));
    const maxZ = Math.max(...scenePts.map(p => p.z + half.z));
    const cellRef = cell.type === 'round'
        ? cell.diam
        : Math.min(getCrossDimensions(cell, result.cellRotation).width, getCrossDimensions(cell, result.cellRotation).depth);
    const clearance = Math.max(cellRef * 0.36, 7);
    const wallT = Math.max(cellRef * 0.16, 3);
    const floorT = Math.max(wallT * 1.15, 4);
    const lidT = Math.max(wallT * 0.85, 3);
    const innerMinX = minX - clearance;
    const innerMaxX = maxX + clearance;
    const innerMinZ = minZ - clearance;
    const innerMaxZ = maxZ + clearance;
    const innerBottomY = minY - Math.max(clearance * 0.2, 2);
    const innerTopY = maxY + Math.max(clearance * 0.55, 5);
    const innerX = Math.max(innerMaxX - innerMinX, cellRef);
    const innerZ = Math.max(innerMaxZ - innerMinZ, cellRef);
    const innerY = Math.max(innerTopY - innerBottomY, cellRef);
    const centerX = (innerMinX + innerMaxX) / 2;
    const centerY = (innerBottomY + innerTopY) / 2;
    const centerZ = (innerMinZ + innerMaxZ) / 2;
    const isExploded = visMode === 'explode';
    const sideSpread = isExploded ? explodeUnit * 0.55 : 0;
    const lidLift = isExploded ? explodeUnit * 1.18 : 0;
    const floorDrop = isExploded ? explodeUnit * 0.35 : 0;
    const shellMat = new THREE.MeshStandardMaterial({
        color: 0x6f8393,
        roughness: 0.52,
        metalness: 0.18,
        transparent: true,
        opacity: 0.28,
        depthWrite: false,
    });
    const lidMat = new THREE.MeshStandardMaterial({
        color: 0x95a7b4,
        roughness: 0.46,
        metalness: 0.16,
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
    });
    const selectedMat = new THREE.MeshStandardMaterial({
        color: 0xffd36b,
        roughness: 0.34,
        metalness: 0.28,
        emissive: 0x3a2500,
    });
    function addShellBox(name, role, center, size, mat) {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(size.x, size.y, size.z), selectedComponentName === name ? selectedMat : mat);
        mesh.position.copy(center);
        mesh.renderOrder = 1;
        mesh.userData.pickKind = 'component';
        mesh.userData.componentName = name;
        mesh.userData.componentRole = role;
        mesh.userData.componentQty = 1;
        group.add(mesh);
    }
    addShellBox('Gehaeuseboden', 'Unterer Pack-Traeger, auf dem Zellhalter und Zellgruppen sitzen.', new THREE.Vector3(centerX, innerBottomY - floorT / 2 - floorDrop, centerZ), new THREE.Vector3(innerX + wallT * 2, floorT, innerZ + wallT * 2), shellMat);
    addShellBox('Gehaeusedeckel', 'Abnehmbarer oberer Schutzdeckel; in der Explosionsdarstellung nach oben versetzt.', new THREE.Vector3(centerX, innerTopY + lidT / 2 + lidLift, centerZ), new THREE.Vector3(innerX + wallT * 2, lidT, innerZ + wallT * 2), lidMat);
    addShellBox('Gehaeuse-Seitenwand links', 'Seitlicher Schutz und mechanische Fuehrung des Batteriepack-Gehaueses.', new THREE.Vector3(innerMinX - wallT / 2 - sideSpread, centerY, centerZ), new THREE.Vector3(wallT, innerY, innerZ + wallT * 2), shellMat);
    addShellBox('Gehaeuse-Seitenwand rechts', 'Seitlicher Schutz und mechanische Fuehrung des Batteriepack-Gehaueses.', new THREE.Vector3(innerMaxX + wallT / 2 + sideSpread, centerY, centerZ), new THREE.Vector3(wallT, innerY, innerZ + wallT * 2), shellMat);
    addShellBox('Gehaeuse-Seitenwand vorne', 'Stirnseitige Gehaeusewand mit Platz fuer Anschluss- und Servicebereiche.', new THREE.Vector3(centerX, centerY, innerMinZ - wallT / 2 - sideSpread), new THREE.Vector3(innerX + wallT * 2, innerY, wallT), shellMat);
    addShellBox('Gehaeuse-Seitenwand hinten', 'Stirnseitige Gehaeusewand mit Platz fuer Anschluss- und Servicebereiche.', new THREE.Vector3(centerX, centerY, innerMaxZ + wallT / 2 + sideSpread), new THREE.Vector3(innerX + wallT * 2, innerY, wallT), shellMat);
}
function pointKey(p) {
    return `${Math.round(p.x * 10) / 10}|${Math.round(p.y * 10) / 10}|${Math.round(p.z * 10) / 10}`;
}
function columnName(index) {
    let n = index + 1;
    let name = '';
    while (n > 0) {
        const rem = (n - 1) % 26;
        name = String.fromCharCode(65 + rem) + name;
        n = Math.floor((n - 1) / 26);
    }
    return name;
}
function uniqueSorted(values) {
    return [...new Set(values.map(v => Math.round(v * 10) / 10))].sort((a, b) => a - b);
}
function getCellAddressMap(result) {
    const { positions, extrusionDir } = result;
    const xs = uniqueSorted(positions.map(p => p.x));
    const zs = uniqueSorted(positions.map(p => p.z));
    const layerValue = (p) => extrusionDir === 'z' ? p.y : extrusionDir === 'x' ? p.x : p.z;
    const layers = uniqueSorted(positions.map(layerValue));
    const xIdx = new Map(xs.map((v, i) => [v, i]));
    const zIdx = new Map(zs.map((v, i) => [v, i]));
    const layerIdx = new Map(layers.map((v, i) => [v, i + 1]));
    const map = new Map();
    positions.forEach(p => {
        const x = Math.round(p.x * 10) / 10;
        const z = Math.round(p.z * 10) / 10;
        const layer = Math.round(layerValue(p) * 10) / 10;
        const lengthLetter = columnName(xIdx.get(x) ?? 0);
        const widthNumber = (zIdx.get(z) ?? 0) + 1;
        const layerNumber = layerIdx.get(layer) ?? 1;
        map.set(pointKey(p), `${lengthLetter}${widthNumber}-E${layerNumber}`);
    });
    return map;
}
function getElectricalSeriesGroups(result, series, parallel) {
    return getElectricalStackGroups(result, series, parallel)
        .map(group => group.flatMap(stack => stack.cells));
}
function layerCoordValue(result, p) {
    return result.extrusionDir === 'z' ? p.y : result.extrusionDir === 'x' ? p.x : p.z;
}
function layerKeyValue(result, p) {
    return Math.round(layerCoordValue(result, p) * 10) / 10;
}
function footprintKey(result, p) {
    const rx = Math.round(p.x * 10) / 10;
    const ry = Math.round(p.y * 10) / 10;
    const rz = Math.round(p.z * 10) / 10;
    const layer = layerKeyValue(result, p);
    if (result.extrusionDir === 'z')
        return `${layer}|${rx}|${rz}`;
    if (result.extrusionDir === 'x')
        return `${layer}|${ry}|${rz}`;
    return `${layer}|${rx}|${ry}`;
}
function sortedElectricalStacks(result) {
    const layers = new Map();
    const seenFootprints = new Set();
    result.positions.forEach(p => {
        const footprint = footprintKey(result, p);
        if (seenFootprints.has(footprint))
            return;
        seenFootprints.add(footprint);
        const key = layerKeyValue(result, p);
        if (!layers.has(key))
            layers.set(key, []);
        layers.get(key).push(p);
    });
    const rowCoordFn = (p) => result.extrusionDir === 'y' ? p.x : p.z;
    const colCoordFn = (p) => result.extrusionDir === 'y' ? p.y : p.x;
    const ordered = [];
    [...layers.keys()].sort((a, b) => a - b).forEach(layerKey => {
        const layerCells = layers.get(layerKey) ?? [];
        const rows = new Map();
        layerCells.forEach(p => {
            const rowKey = Math.round(rowCoordFn(p) * 10) / 10;
            if (!rows.has(rowKey))
                rows.set(rowKey, []);
            rows.get(rowKey).push(p);
        });
        [...rows.keys()].sort((a, b) => a - b).forEach((rowKey, rowIdx) => {
            const row = rows.get(rowKey);
            row.sort((a, b) => rowIdx % 2 === 0
                ? colCoordFn(a) - colCoordFn(b)
                : colCoordFn(b) - colCoordFn(a));
            row.forEach(cellPoint => ordered.push({ cells: [cellPoint], top: cellPoint }));
        });
    });
    return ordered;
}
function electricalStackHeight(result) {
    void result;
    return 1;
}
function electricalStacksByLayer(result) {
    const layers = new Map();
    sortedElectricalStacks(result).forEach(stack => {
        const key = layerKeyValue(result, stack.top);
        if (!layers.has(key))
            layers.set(key, []);
        layers.get(key).push(stack);
    });
    return [...layers.keys()].sort((a, b) => a - b).map(key => layers.get(key) ?? []);
}
function maxSeriesGroupsForParallel(result, parallel) {
    const pCount = Math.max(1, Math.floor(parallel));
    return electricalStacksByLayer(result).reduce((sum, layer) => sum + Math.floor(layer.length / pCount), 0);
}
function maxParallelCellsInOneLayer(result) {
    const layers = electricalStacksByLayer(result);
    if (!layers.length)
        return Math.max(1, result.positions.length);
    return Math.max(1, ...layers.map(layer => layer.length));
}
function getElectricalStackGroups(result, series, parallel) {
    const layers = electricalStacksByLayer(result);
    const stacksInSeries = Math.max(1, series);
    const stacksPerParallelGroup = Math.max(1, parallel);
    const groups = [];
    for (const layer of layers) {
        for (let i = 0; i + stacksPerParallelGroup <= layer.length && groups.length < stacksInSeries; i += stacksPerParallelGroup) {
            groups.push(layer.slice(i, i + stacksPerParallelGroup));
        }
        if (groups.length >= stacksInSeries)
            break;
    }
    return groups;
}
function createElectricalTopology(result, series, parallel) {
    const stacks = sortedElectricalStacks(result);
    const pCount = Math.max(1, parallel);
    const parallelPerStack = electricalStackHeight(result);
    const stacksPerParallelGroup = pCount;
    const groups = getElectricalStackGroups(result, series, parallel).map((group, idx) => ({
        index: idx,
        seriesLabel: `${idx + 1}s`,
        stacks: group,
    }));
    const requiredStacks = groups.reduce((sum, group) => sum + group.stacks.length, 0);
    return {
        groups,
        stackHeight: parallelPerStack,
        parallelPerStack,
        stacksPerParallelGroup,
        stackCount: stacks.length,
        requiredStacks,
        series,
        parallel: pCount,
    };
}
function stackAddress(stack, addressMap) {
    const topAddress = addressMap.get(pointKey(stack.top)) ?? '?';
    return stack.cells.length > 1 ? `${topAddress} (${stack.cells.length}p)` : topAddress;
}
function electricalGroupAddressLines(result, series, parallel) {
    const addressMap = getCellAddressMap(result);
    const groups = getElectricalStackGroups(result, series, parallel);
    const previewLimit = 8;
    const addressPreviewLimit = 12;
    const formatAddresses = (stacks) => {
        const addresses = stacks.map(stack => stackAddress(stack, addressMap));
        if (addresses.length <= addressPreviewLimit)
            return addresses.join(', ');
        return `${addresses.slice(0, addressPreviewLimit).join(', ')} ... +${addresses.length - addressPreviewLimit}`;
    };
    const lines = [
        '',
        'Adressierte Verschaltung:',
        'Adresse = Laenge(Buchstabe) + Breite(Zahl) + Ebene, z.B. A1-E1',
        `Parallelgruppen werden innerhalb derselben Ebene aus benachbarten Zellen gebildet; Serienbruecken verbinden benachbarte Parallelgruppen.`,
    ];
    groups.slice(0, previewLimit).forEach((stacks, idx) => {
        const groupParallel = stacks.reduce((sum, stack) => sum + stack.cells.length, 0);
        lines.push(`Seriengruppe ${idx + 1} (${idx + 1}s, ${groupParallel}p): ${formatAddresses(stacks)}`);
    });
    if (groups.length > previewLimit) {
        const lastIdx = groups.length - 1;
        lines.push(`... ${groups.length - previewLimit - 1} weitere Seriengruppen`);
        const groupParallel = groups[lastIdx].reduce((sum, stack) => sum + stack.cells.length, 0);
        lines.push(`Seriengruppe ${groups.length} (${groups.length}s, ${groupParallel}p): ${formatAddresses(groups[lastIdx])}`);
    }
    return lines;
}
function addElectricalBusbars(group, result, electrical, axis, longHalf, extraOffset = new THREE.Vector3()) {
    const { cell, sp } = result;
    const requiredCells = Math.min(result.positions.length, electrical.requiredCells);
    if (requiredCells < 2)
        return;
    if (cell.type === 'prismatic') {
        const cross = getCrossDimensions(cell, result.cellRotation);
        const sideDir = result.extrusionDir === 'x'
            ? new THREE.Vector3(0, 1, 0)
            : new THREE.Vector3(1, 0, 0);
        const cellRef = Math.min(cross.width, cross.depth);
        const topLift = longHalf + Math.max(cellRef * 0.08, 2.5);
        const terminalOffset = Math.max(cross.width * 0.32, cellRef * 0.8);
        const busbarWidth = Math.max(cellRef * 0.18, 5);
        const bridgeWidth = Math.max(cellRef * 0.14, 4);
        const terminalMat = new THREE.MeshStandardMaterial({ color: 0xd9e1e6, roughness: 0.24, metalness: 0.86 });
        const seriesMat = new THREE.MeshStandardMaterial({ color: 0xb87324, roughness: 0.22, metalness: 0.88 });
        const selectedMat = new THREE.MeshStandardMaterial({ color: 0xffd36b, roughness: 0.18, metalness: 0.78, emissive: 0x442800 });
        const topology = createElectricalTopology(result, electrical.series, electrical.parallel);
        const groups = topology.groups.map(g => g.stacks);
        const terminalPointForCell = (cellPoint, polarity) => {
            const base = worldToScenePoint(cellPoint, sp).add(axis.clone().multiplyScalar(topLift)).add(extraOffset);
            return base.add(sideDir.clone().multiplyScalar(polarity === 'pos' ? terminalOffset : -terminalOffset));
        };
        const mark = (mesh, groupIdx, role) => {
            if (!mesh)
                return;
            mesh.userData.pickKind = 'busbar';
            mesh.userData.busbarGroup = groupIdx;
            mesh.userData.busbarRole = role;
        };
        const addSegment = (a, b, width, mat, groupIdx, role) => {
            mark(addNickelStrip(group, a, b, width, 2.6, mat), groupIdx, role);
        };
        const addOrthogonalSegment = (a, b, width, mat, groupIdx, role) => {
            const dz = Math.abs(a.z - b.z);
            const dx = Math.abs(a.x - b.x);
            if (dx < cellRef * 0.4 || dz < cellRef * 0.4) {
                addSegment(a, b, width, mat, groupIdx, role);
                return;
            }
            const corner = new THREE.Vector3(b.x, a.y, a.z);
            addSegment(a, corner, width, mat, groupIdx, role);
            addSegment(corner, b, width, mat, groupIdx, role);
        };
        const anchors = [];
        groups.forEach((stacks, groupIdx) => {
            const mat = selectedBusbarGroup === groupIdx ? selectedMat : terminalMat;
            addLayerParallelRails(group, stacks, p => terminalPointForCell(p, 'neg'), axis, Math.max(bridgeWidth * 0.72, 3), Math.max(bridgeWidth * 0.45, 2.2), mat, groupIdx, mark, Math.max(busbarWidth * 0.85, 6));
            addLayerParallelRails(group, stacks, p => terminalPointForCell(p, 'pos'), axis, Math.max(bridgeWidth * 0.72, 3), Math.max(bridgeWidth * 0.45, 2.2), mat, groupIdx, mark, Math.max(busbarWidth * 0.85, 6));
            const negPts = stacks.map(stack => terminalPointForCell(stack.top, 'neg'));
            const posPts = stacks.map(stack => terminalPointForCell(stack.top, 'pos'));
            const sortPts = (pts) => pts.sort((a, b) => (a.z - b.z) || (a.x - b.x) || (a.y - b.y));
            sortPts(negPts);
            sortPts(posPts);
            negPts.forEach(p => addPolarityDot(group, p.clone().add(axis.clone().multiplyScalar(1.4)), 0x26323d, Math.max(cellRef * 0.13, 3), groupIdx, 'minus'));
            posPts.forEach(p => addPolarityDot(group, p.clone().add(axis.clone().multiplyScalar(1.4)), 0xd54438, Math.max(cellRef * 0.13, 3), groupIdx, 'plus'));
            if (negPts.length > 1) {
                for (let i = 1; i < negPts.length; i++)
                    addSegment(negPts[i - 1], negPts[i], busbarWidth, mat, groupIdx, 'parallel');
                for (let i = 1; i < posPts.length; i++)
                    addSegment(posPts[i - 1], posPts[i], busbarWidth, mat, groupIdx, 'parallel');
            }
            anchors[groupIdx] = { neg: negPts[0], pos: posPts[posPts.length - 1] };
        });
        for (let i = 1; i < anchors.length; i++) {
            const mat = selectedBusbarGroup === i - 1 || selectedBusbarGroup === i ? selectedMat : seriesMat;
            addOrthogonalSegment(anchors[i - 1].pos, anchors[i].neg, bridgeWidth, mat, i, 'series');
        }
        if (anchors[0])
            addTerminalMarker(group, '-', anchors[0].neg.clone().add(axis.clone().multiplyScalar(Math.max(cellRef * 0.7, 12))), '#1a2430', Math.max(cellRef * 1.5, 22));
        if (anchors[anchors.length - 1])
            addTerminalMarker(group, '+', anchors[anchors.length - 1].pos.clone().add(axis.clone().multiplyScalar(Math.max(cellRef * 0.7, 12))), '#cc2233', Math.max(cellRef * 1.5, 22));
        return;
    }
    const cellRef = cell.diam;
    const axisN = axis.clone().normalize();
    const stripThickness = Math.max(cellRef * 0.06, 1.2);
    const contactLift = longHalf + Math.max(cellRef * 0.14, 2.6);
    const topPoint = (p) => worldToScenePoint(p, sp)
        .add(axisN.clone().multiplyScalar(contactLift))
        .add(extraOffset);
    const bottomLift = -longHalf - Math.max(cellRef * 0.12, 2.4);
    const bottomPoint = (p) => worldToScenePoint(p, sp)
        .add(axisN.clone().multiplyScalar(bottomLift))
        .add(extraOffset);
    const nickelMat = new THREE.MeshStandardMaterial({ color: 0xe5edf2, roughness: 0.18, metalness: 0.9, emissive: 0x1b2730, emissiveIntensity: 0.05 });
    const seriesMat = new THREE.MeshStandardMaterial({ color: 0xb8c1c8, roughness: 0.22, metalness: 0.86 });
    const bottomBusbarMat = new THREE.MeshStandardMaterial({ color: 0x68727a, roughness: 0.3, metalness: 0.62 });
    const selectedMat = new THREE.MeshStandardMaterial({ color: 0xffd36b, roughness: 0.18, metalness: 0.76, emissive: 0x443400 });
    const padMat = new THREE.MeshStandardMaterial({ color: 0xdce5eb, roughness: 0.2, metalness: 0.82 });
    const padRadius = Math.max(cellRef * 0.32, 3.8);
    const padThickness = Math.max(cellRef * 0.045, 1.0);
    const parallelWidth = Math.max(cellRef * 0.28, 5.2);
    const seriesWidth = Math.max(cellRef * 0.18, 3.6);
    const topology = createElectricalTopology(result, electrical.series, electrical.parallel);
    const seriesGroups = topology.groups.map(g => g.stacks);
    const topStacks = seriesGroups.flat();
    function markBusbar(mesh, groupIdx, role) {
        if (!mesh)
            return;
        mesh.userData.pickKind = 'busbar';
        mesh.userData.busbarGroup = groupIdx;
        mesh.userData.busbarRole = role;
    }
    function addTopStrip(a, b, width, mat, groupIdx, role) {
        const delta = b.clone().sub(a);
        const planarDelta = delta.clone().sub(axisN.clone().multiplyScalar(delta.dot(axisN)));
        const len = planarDelta.length();
        if (len <= 0.001)
            return;
        const dir = planarDelta.normalize();
        const side = new THREE.Vector3().crossVectors(dir, axisN).normalize();
        const mid = a.clone().add(b).multiplyScalar(0.5);
        const strip = new THREE.Mesh(new THREE.BoxGeometry(len, stripThickness, width), mat);
        const rotation = new THREE.Matrix4().makeBasis(dir, axisN, side);
        strip.position.copy(mid);
        strip.quaternion.setFromRotationMatrix(rotation);
        strip.renderOrder = role === 'series' ? 37 : 36;
        strip.castShadow = true;
        group.add(strip);
        markBusbar(strip, groupIdx, role);
    }
    function addSharedSeriesBusbar(fromPts, toPts, mat, groupIdx, side) {
        const count = Math.min(fromPts.length, toPts.length);
        if (count < 1)
            return;
        const outward = axisN.clone().multiplyScalar(side === 'top'
            ? Math.max(stripThickness * 0.8, 1.4)
            : -Math.max(stripThickness * 0.8, 1.4));
        const sortPts = (pts) => [...pts]
            .sort((a, b) => a.x - b.x || a.z - b.z || a.y - b.y)
            .slice(0, count)
            .map(p => p.clone().add(outward));
        const from = sortPts(fromPts);
        const to = sortPts(toPts);
        const path = [];
        for (let i = 0; i < count; i++) {
            path.push(from[i], to[i]);
        }
        for (let i = 1; i < path.length; i++) {
            addTopStrip(path[i - 1], path[i], seriesWidth, mat, groupIdx, 'series');
        }
    }
    function addParallelGroupFrame(stacks, pts, groupIdx) {
        if (modelUiHidden)
            return;
        if (!pts.length)
            return;
        const planeA = perpendicularBusbarDirection(axisN);
        const planeB = new THREE.Vector3().crossVectors(axisN, planeA).normalize();
        const center = pts.reduce((sum, p) => sum.add(p), new THREE.Vector3()).multiplyScalar(1 / pts.length);
        const coords = pts.map(p => ({ a: p.dot(planeA), b: p.dot(planeB), n: p.dot(axisN) }));
        const expand = Math.max(cellRef * 0.54, 8);
        const minA = Math.min(...coords.map(c => c.a)) - expand;
        const maxA = Math.max(...coords.map(c => c.a)) + expand;
        const minB = Math.min(...coords.map(c => c.b)) - expand;
        const maxB = Math.max(...coords.map(c => c.b)) + expand;
        const topN = Math.max(...coords.map(c => c.n)) + Math.max(stripThickness * 1.2, 2.2);
        const point = (a, b) => planeA.clone().multiplyScalar(a)
            .add(planeB.clone().multiplyScalar(b))
            .add(axisN.clone().multiplyScalar(topN));
        const frameGeo = new THREE.BufferGeometry().setFromPoints([
            point(minA, minB),
            point(maxA, minB),
            point(maxA, maxB),
            point(minA, maxB),
            point(minA, minB),
        ]);
        const frameMat = new THREE.LineBasicMaterial({
            color: selectedBusbarGroup === groupIdx ? 0xffd36b : 0x4bd4ff,
            depthTest: false,
            depthWrite: false,
            transparent: true,
            opacity: 0.8,
        });
        const frame = new THREE.Line(frameGeo, frameMat);
        frame.renderOrder = 80;
        frame.userData.pickKind = 'busbar';
        frame.userData.busbarGroup = groupIdx;
        frame.userData.busbarRole = 'parallel';
        group.add(frame);
        if (seriesGroups.length <= 24) {
            const polarity = visibleTopPolarityForGroup(groupIdx);
            const label = makeTextSprite(`S${groupIdx + 1} ${stacks.length}p ${polarityLabel(polarity)}`, selectedBusbarGroup === groupIdx ? '#6b4300' : '#005f86');
            label.position.copy(center.clone().add(axisN.clone().multiplyScalar(Math.max(cellRef * 0.9, 14))));
            label.scale.set(Math.max(cellRef * 2.6, 34), Math.max(cellRef * 0.58, 8), 1);
            label.userData.pickKind = 'busbar';
            label.userData.busbarGroup = groupIdx;
            label.userData.busbarRole = 'parallel';
            group.add(label);
        }
    }
    if (topStacks.length) {
        const padGeo = new THREE.CylinderGeometry(padRadius, padRadius, padThickness, 28);
        const padQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), axisN);
        const padMesh = new THREE.InstancedMesh(padGeo, padMat, topStacks.length);
        padMesh.userData.pickKind = 'component';
        padMesh.userData.componentName = 'Nickel-Kontaktpads';
        padMesh.userData.componentRole = 'Flache Kontaktpads auf der obersten Rundzellen-Ebene fuer die sichtbare Verschaltung.';
        padMesh.userData.componentQty = topStacks.length;
        topStacks.forEach((stack, idx) => {
            setInstance(padMesh, idx, topPoint(stack.top).clone().add(axisN.clone().multiplyScalar(padThickness * 0.15)), padQuat);
        });
        padMesh.instanceMatrix.needsUpdate = true;
        padMesh.renderOrder = 35;
        group.add(padMesh);
    }
    function addParallelGroupBusbars(stacks, groupIdx) {
        const pts = stacks.map(stack => topPoint(stack.top).clone().add(axisN.clone().multiplyScalar(stripThickness * 0.35)));
        const bottomPts = stacks.map(stack => bottomPoint(stack.top).clone().sub(axisN.clone().multiplyScalar(stripThickness * 0.35)));
        if (!pts.length)
            return { start: undefined, end: undefined, bottomStart: undefined, bottomEnd: undefined, pts: [], bottomPts: [] };
        const mat = selectedBusbarGroup === groupIdx ? selectedMat : nickelMat;
        const visiblePolarity = visibleTopPolarityForGroup(groupIdx);
        const visibleBottomPolarity = oppositePolarity(visiblePolarity);
        addParallelGroupFrame(stacks, pts, groupIdx);
        pts.forEach(p => {
            addPolarityDot(group, p.clone().add(axisN.clone().multiplyScalar(Math.max(stripThickness * 1.1, 2.1))), polarityColor(visiblePolarity), Math.max(cellRef * 0.095, 2.0), groupIdx, visiblePolarity);
        });
        bottomPts.forEach(p => {
            addPolarityDot(group, p.clone().sub(axisN.clone().multiplyScalar(Math.max(stripThickness * 1.1, 2.1))), polarityColor(visibleBottomPolarity), Math.max(cellRef * 0.095, 2.0), groupIdx, visibleBottomPolarity);
        });
        for (let i = 1; i < pts.length; i++) {
            addTopStrip(pts[i - 1], pts[i], parallelWidth, mat, groupIdx, 'parallel');
        }
        for (let i = 1; i < bottomPts.length; i++) {
            addTopStrip(bottomPts[i - 1], bottomPts[i], parallelWidth * 0.9, bottomBusbarMat, groupIdx, 'parallel');
        }
        return {
            start: pts[0],
            end: pts[pts.length - 1],
            bottomStart: bottomPts[0],
            bottomEnd: bottomPts[bottomPts.length - 1],
            pts,
            bottomPts,
        };
    }
    const groupAnchors = seriesGroups.map((stacks, groupIdx) => addParallelGroupBusbars(stacks, groupIdx));
    for (let s = 1; s < groupAnchors.length; s++) {
        const from = groupAnchors[s - 1].end;
        const to = groupAnchors[s].start;
        if (!from || !to)
            continue;
        const mat = selectedBusbarGroup === s - 1 || selectedBusbarGroup === s ? selectedMat : seriesMat;
        if (s % 2 === 1) {
            addSharedSeriesBusbar(groupAnchors[s - 1].pts, groupAnchors[s].pts, mat, s, 'top');
        }
        else {
            addSharedSeriesBusbar(groupAnchors[s - 1].bottomPts, groupAnchors[s].bottomPts, bottomBusbarMat, s, 'bottom');
        }
    }
    const first = groupAnchors[0]?.start;
    const last = groupAnchors[groupAnchors.length - 1]?.end;
    const terminalOffset = axisN.clone().multiplyScalar(stripThickness * 1.25);
    if (first) {
        const polarity = visibleTopPolarityForGroup(0);
        addPolarityDot(group, first.clone().add(terminalOffset), polarityColor(polarity), Math.max(cellRef * 0.11, 2.2), 0, polarity);
    }
    if (last) {
        const lastIdx = Math.max(0, groupAnchors.length - 1);
        const polarity = visibleTopPolarityForGroup(lastIdx);
        addPolarityDot(group, last.clone().add(terminalOffset), polarityColor(polarity), Math.max(cellRef * 0.11, 2.2), lastIdx, polarity);
    }
}
function buildPackVisualization(result, cellGeo, instanceQuat) {
    const { cell, extrusionDir, sp, positions } = result;
    const group = new THREE.Group();
    const count = positions.length;
    const axis = longAxisVector(extrusionDir);
    const longHalf = cell.height / 2;
    const isExploded = visMode === 'explode';
    const explodeUnit = isExploded ? explodeAmount : 0;
    const electrical = getElectricalSummaryData();
    const useElectricalGroups = true;
    const electricalGroupByPoint = new Map();
    getElectricalSeriesGroups(result, electrical.series, electrical.parallel).forEach((cells, groupIdx) => {
        cells.forEach(p => electricalGroupByPoint.set(pointKey(p), groupIdx));
    });
    const visibleTopPolarityForPoint = (p) => (visibleTopPolarityForGroup(electricalGroupByPoint.get(pointKey(p)) ?? 0));
    const layerKeys = new Map();
    positions.forEach(p => {
        const key = extrusionDir === 'z' ? p.y : extrusionDir === 'x' ? p.x : p.z;
        const rounded = Math.round(key * 10) / 10;
        if (!layerKeys.has(rounded))
            layerKeys.set(rounded, layerKeys.size);
    });
    const layerCount = Math.max(1, layerKeys.size);
    function explodeOffsetForPoint(p) {
        if (!isExploded)
            return new THREE.Vector3();
        const key = extrusionDir === 'z' ? Math.round(p.y * 10) / 10
            : extrusionDir === 'x' ? Math.round(p.x * 10) / 10
                : Math.round(p.z * 10) / 10;
        const idx = layerKeys.get(key) ?? 0;
        const centered = idx - (layerCount - 1) / 2;
        return axis.clone().multiplyScalar(centered * explodeUnit * 0.72);
    }
    const busbarExplodeOffset = isExploded ? axis.clone().multiplyScalar(explodeUnit * 1.15) : new THREE.Vector3();
    const cellMaterials = PACK_CELL_COLORS.map(color => new THREE.MeshStandardMaterial({
        color,
        roughness: cell.type === 'round' ? 0.3 : 0.4,
        metalness: cell.type === 'round' ? 0.7 : 0.5,
    }));
    const groupPaletteSize = cellMaterials.length;
    const highlightMaterialIndex = cellMaterials.length;
    cellMaterials.push(new THREE.MeshStandardMaterial({
        color: 0xffd447,
        roughness: 0.22,
        metalness: 0.62,
        emissive: 0x5f3f00,
    }));
    const meshAssignments = positions.map(p => {
        const layerKey = Math.round(layerCoordValue(result, p) * 10) / 10;
        if (selectedLayerKey !== null && layerKey === selectedLayerKey)
            return highlightMaterialIndex;
        if (useElectricalGroups) {
            const groupIdx = electricalGroupByPoint.get(pointKey(p));
            return groupIdx === undefined ? 0 : groupIdx % groupPaletteSize;
        }
        const key = extrusionDir === 'z' ? Math.round(p.y * 10) / 10
            : extrusionDir === 'x' ? Math.round(p.x * 10) / 10
                : Math.round(p.z * 10) / 10;
        const layerIdx = layerKeys.get(key) ?? 0;
        return layerIdx % cellMaterials.length;
    });
    const meshCapacities = new Array(cellMaterials.length).fill(0);
    meshAssignments.forEach(meshIdx => meshCapacities[meshIdx]++);
    const cellMeshes = cellMaterials.map((mat, i) => {
        const mesh = new THREE.InstancedMesh(cellGeo, mat, Math.max(meshCapacities[i], 1));
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData.pickKind = 'cell';
        mesh.userData.instancePoints = [];
        return mesh;
    });
    const cellMeshCounts = new Array(cellMeshes.length).fill(0);
    positions.forEach((p, i) => {
        const meshIdx = meshAssignments[i];
        const instanceIdx = cellMeshCounts[meshIdx]++;
        setInstance(cellMeshes[meshIdx], instanceIdx, worldToScenePoint(p, sp).add(explodeOffsetForPoint(p)), instanceQuat);
        cellMeshes[meshIdx].userData.instancePoints[instanceIdx] = p;
    });
    cellMeshes.forEach((mesh, i) => {
        if (meshCapacities[i] === 0)
            return;
        mesh.instanceMatrix.needsUpdate = true;
        group.add(mesh);
    });
    if (cell.type === 'round') {
        const r = cell.diam / 2;
        const topPositiveCells = positions.filter(p => visibleTopPolarityForPoint(p) === 'plus');
        const topNegativeCells = positions.filter(p => visibleTopPolarityForPoint(p) === 'minus');
        const positiveCapGeo = new THREE.CylinderGeometry(r * 0.24, r * 0.32, 1.7, 28);
        const positiveButtonGeo = new THREE.CylinderGeometry(r * 0.11, r * 0.11, 1.9, 20);
        const negativeCapGeo = new THREE.CylinderGeometry(r * 0.44, r * 0.44, 0.8, 28);
        const negativeRecessGeo = new THREE.CylinderGeometry(r * 0.24, r * 0.24, 0.95, 24);
        const positiveCapMat = new THREE.MeshStandardMaterial({ color: 0xd7e0e6, roughness: 0.22, metalness: 0.82 });
        const positiveButtonMat = new THREE.MeshStandardMaterial({ color: 0xd54438, roughness: 0.28, metalness: 0.45, emissive: 0x3a0805, emissiveIntensity: 0.08 });
        const negativeCapMat = new THREE.MeshStandardMaterial({ color: 0x17212b, roughness: 0.56, metalness: 0.18 });
        const negativeRecessMat = new THREE.MeshStandardMaterial({ color: 0x05090d, roughness: 0.72, metalness: 0.08 });
        function addRoundTerminalMesh(cells, geometry, material, lift, componentName, componentRole) {
            if (!cells.length)
                return;
            const mesh = new THREE.InstancedMesh(geometry, material, cells.length);
            mesh.userData.pickKind = 'component';
            mesh.userData.componentName = componentName;
            mesh.userData.componentRole = componentRole;
            mesh.userData.componentQty = cells.length;
            cells.forEach((p, i) => {
                const pos = worldToScenePoint(p, sp).add(axis.clone().multiplyScalar(longHalf + lift)).add(explodeOffsetForPoint(p));
                setInstance(mesh, i, pos, instanceQuat);
            });
            mesh.instanceMatrix.needsUpdate = true;
            mesh.renderOrder = 28;
            group.add(mesh);
        }
        addRoundTerminalMesh(topPositiveCells, positiveCapGeo, positiveCapMat, 1.05, 'Pluspol oben', 'Diese Zellen sind in der Darstellung positiv nach oben orientiert.');
        addRoundTerminalMesh(topPositiveCells, positiveButtonGeo, positiveButtonMat, 1.95, 'Pluspol-Markierung', 'Rote erhabene Markierung fuer die nach oben zeigende Plus-Seite.');
        addRoundTerminalMesh(topNegativeCells, negativeCapGeo, negativeCapMat, 0.75, 'Minuspol oben', 'Diese Zellen sind in der Darstellung umgedreht, der Minuspol zeigt nach oben.');
        addRoundTerminalMesh(topNegativeCells, negativeRecessGeo, negativeRecessMat, 1.25, 'Minuspol-Vertiefung', 'Dunkle flache Vertiefung fuer die nach oben zeigende Minus-Seite.');
        const holderMat = new THREE.MeshStandardMaterial({ color: 0x11161a, roughness: 0.78, metalness: 0.04 });
        const holderThickness = Math.max(cell.diam * 0.11, 2);
        const ringGeo = new THREE.TorusGeometry(r * 0.58, Math.max(r * 0.07, 0.9), 8, 22);
        const ringQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), axis.clone().normalize());
        const ringMesh = new THREE.InstancedMesh(ringGeo, holderMat, count * 2);
        const tabLong = Math.max(cell.diam * 0.34, 5.5);
        const tabWide = Math.max(cell.diam * 0.11, 2);
        const tabOffset = r * 0.82;
        const tabXGeo = new THREE.BoxGeometry(tabLong, holderThickness, tabWide);
        const tabZGeo = new THREE.BoxGeometry(tabWide, holderThickness, tabLong);
        const tabXMesh = new THREE.InstancedMesh(tabXGeo, holderMat, count * 4);
        const tabZMesh = new THREE.InstancedMesh(tabZGeo, holderMat, count * 4);
        [ringMesh, tabXMesh, tabZMesh].forEach(mesh => {
            mesh.userData.pickKind = 'component';
            mesh.userData.componentName = 'Kunststoff-Zellhalter';
            mesh.userData.componentRole = 'Fixiert die Rundzellen mechanisch und haelt definierte Zellabstaende ein.';
            mesh.userData.componentQty = `${count} Zellpositionen`;
        });
        function placeHolderTab(mesh, idx, base, localOffset) {
            const pos = base.clone().add(localOffset.clone().applyQuaternion(instanceQuat));
            setInstance(mesh, idx, pos, instanceQuat);
        }
        positions.forEach((p, i) => {
            const base = worldToScenePoint(p, sp).add(explodeOffsetForPoint(p));
            const topTabs = base.clone().add(axis.clone().multiplyScalar(longHalf + holderThickness * 0.18));
            const bottomTabs = base.clone().add(axis.clone().multiplyScalar(-longHalf - holderThickness * 0.18));
            const topRing = base.clone().add(axis.clone().multiplyScalar(longHalf + holderThickness * 0.56));
            const bottomRing = base.clone().add(axis.clone().multiplyScalar(-longHalf - holderThickness * 0.56));
            setInstance(ringMesh, i * 2, topRing, ringQuat);
            setInstance(ringMesh, i * 2 + 1, bottomRing, ringQuat);
            const xIdx = i * 4;
            placeHolderTab(tabXMesh, xIdx, topTabs, new THREE.Vector3(0, 0, tabOffset));
            placeHolderTab(tabXMesh, xIdx + 1, topTabs, new THREE.Vector3(0, 0, -tabOffset));
            placeHolderTab(tabXMesh, xIdx + 2, bottomTabs, new THREE.Vector3(0, 0, tabOffset));
            placeHolderTab(tabXMesh, xIdx + 3, bottomTabs, new THREE.Vector3(0, 0, -tabOffset));
            const zIdx = i * 4;
            placeHolderTab(tabZMesh, zIdx, topTabs, new THREE.Vector3(tabOffset, 0, 0));
            placeHolderTab(tabZMesh, zIdx + 1, topTabs, new THREE.Vector3(-tabOffset, 0, 0));
            placeHolderTab(tabZMesh, zIdx + 2, bottomTabs, new THREE.Vector3(tabOffset, 0, 0));
            placeHolderTab(tabZMesh, zIdx + 3, bottomTabs, new THREE.Vector3(-tabOffset, 0, 0));
        });
        ringMesh.instanceMatrix.needsUpdate = true;
        tabXMesh.instanceMatrix.needsUpdate = true;
        tabZMesh.instanceMatrix.needsUpdate = true;
        group.add(ringMesh, tabXMesh, tabZMesh);
    }
    else {
        const cross = getCrossDimensions(cell, result.cellRotation);
        const cellWidth = cross.width;
        const cellDepth = cross.depth;
        const cellRef = Math.min(cellWidth, cellDepth);
        const terminalWidth = Math.max(cellWidth * 0.16, 10);
        const terminalDepth = Math.max(cellDepth * 0.52, 8);
        const terminalThickness = Math.max(cellRef * 0.06, 2);
        const terminalOffset = Math.max(cellWidth * 0.32, terminalWidth);
        const padGeo = new THREE.BoxGeometry(terminalWidth, terminalThickness, terminalDepth);
        const negMat = new THREE.MeshStandardMaterial({ color: 0xb9c3ca, roughness: 0.24, metalness: 0.82 });
        const posMat = new THREE.MeshStandardMaterial({ color: 0xd8e0e5, roughness: 0.22, metalness: 0.88 });
        const negPads = new THREE.InstancedMesh(padGeo, negMat, count);
        const posPads = new THREE.InstancedMesh(padGeo, posMat, count);
        const topOffset = axis.clone().multiplyScalar(longHalf + terminalThickness * 0.7);
        const localSide = new THREE.Vector3(1, 0, 0);
        positions.forEach((p, i) => {
            const base = worldToScenePoint(p, sp).add(explodeOffsetForPoint(p)).add(topOffset);
            const side = localSide.clone().multiplyScalar(terminalOffset).applyQuaternion(instanceQuat);
            setInstance(negPads, i, base.clone().sub(side), instanceQuat);
            setInstance(posPads, i, base.clone().add(side), instanceQuat);
        });
        negPads.instanceMatrix.needsUpdate = true;
        posPads.instanceMatrix.needsUpdate = true;
        group.add(negPads, posPads);
        const outlineMat = new THREE.LineBasicMaterial({ color: 0x08324a, transparent: true, opacity: 0.55 });
        const localCorners = [
            new THREE.Vector3(-cellWidth / 2, -longHalf, -cellDepth / 2),
            new THREE.Vector3(cellWidth / 2, -longHalf, -cellDepth / 2),
            new THREE.Vector3(cellWidth / 2, -longHalf, cellDepth / 2),
            new THREE.Vector3(-cellWidth / 2, -longHalf, cellDepth / 2),
            new THREE.Vector3(-cellWidth / 2, longHalf, -cellDepth / 2),
            new THREE.Vector3(cellWidth / 2, longHalf, -cellDepth / 2),
            new THREE.Vector3(cellWidth / 2, longHalf, cellDepth / 2),
            new THREE.Vector3(-cellWidth / 2, longHalf, cellDepth / 2),
        ];
        const edgePairs = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
        const verts = [];
        positions.forEach(p => {
            const base = worldToScenePoint(p, sp).add(explodeOffsetForPoint(p));
            const worldCorners = localCorners.map(c => c.clone().applyQuaternion(instanceQuat).add(base));
            edgePairs.forEach(([a, b]) => {
                const pa = worldCorners[a];
                const pb = worldCorners[b];
                verts.push(pa.x, pa.y, pa.z, pb.x, pb.y, pb.z);
            });
        });
        const edgeGeo = new THREE.BufferGeometry();
        edgeGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(verts), 3));
        const edgeLines = new THREE.LineSegments(edgeGeo, outlineMat);
        edgeLines.renderOrder = 5;
        group.add(edgeLines);
        const frameMat = new THREE.MeshStandardMaterial({ color: 0x20282e, roughness: 0.72, metalness: 0.08 });
        const layerValue = (p) => Math.round(layerCoordValue(result, p) * 10) / 10;
        const layerMap = new Map();
        positions.forEach(p => {
            const key = layerValue(p);
            if (!layerMap.has(key))
                layerMap.set(key, []);
            layerMap.get(key).push(p);
        });
        const localTopY = longHalf + terminalThickness * 0.28;
        const frameThickness = Math.max(cellRef * 0.05, 2.4);
        const railWidth = Math.max(cellDepth * 0.22, 7);
        const crossWidth = Math.max(cellDepth * 0.14, 5);
        function addPrismRail(center, sizeX, sizeZ) {
            const rail = new THREE.Mesh(new THREE.BoxGeometry(sizeX, frameThickness, sizeZ), frameMat);
            rail.position.copy(center);
            rail.quaternion.copy(instanceQuat);
            rail.renderOrder = 6;
            group.add(rail);
        }
        layerMap.forEach(layerPositions => {
            const scenePts = layerPositions.map(p => worldToScenePoint(p, sp).add(explodeOffsetForPoint(p)));
            const minX = Math.min(...scenePts.map(p => p.x)) - cellWidth / 2;
            const maxX = Math.max(...scenePts.map(p => p.x)) + cellWidth / 2;
            const minZ = Math.min(...scenePts.map(p => p.z)) - cellDepth / 2;
            const maxZ = Math.max(...scenePts.map(p => p.z)) + cellDepth / 2;
            const y = scenePts[0].y + localTopY;
            const cx = (minX + maxX) / 2;
            const cz = (minZ + maxZ) / 2;
            const sx = Math.max(maxX - minX, cellWidth);
            const sz = Math.max(maxZ - minZ, cellDepth);
            addPrismRail(new THREE.Vector3(cx, y, minZ), sx, railWidth);
            addPrismRail(new THREE.Vector3(cx, y, maxZ), sx, railWidth);
            addPrismRail(new THREE.Vector3(minX, y, cz), railWidth, sz);
            addPrismRail(new THREE.Vector3(maxX, y, cz), railWidth, sz);
            uniqueSorted(layerPositions.map(p => p.x)).forEach(x => {
                addPrismRail(new THREE.Vector3(x - sp.l / 2, y + frameThickness * 0.08, cz), crossWidth, sz);
            });
        });
        const allScenePts = positions.map(p => worldToScenePoint(p, sp));
        const minX = Math.min(...allScenePts.map(p => p.x)) - cellWidth / 2;
        const maxX = Math.max(...allScenePts.map(p => p.x)) + cellWidth / 2;
        const minZ = Math.min(...allScenePts.map(p => p.z)) - cellDepth / 2;
        const maxZ = Math.max(...allScenePts.map(p => p.z)) + cellDepth / 2;
        const minY = Math.min(...allScenePts.map(p => p.y)) - longHalf;
        const maxY = Math.max(...allScenePts.map(p => p.y)) + longHalf;
        const packX = maxX - minX;
        const packZ = maxZ - minZ;
        const packY = maxY - minY;
        const centerX = (minX + maxX) / 2;
        const centerY = (minY + maxY) / 2;
        const centerZ = (minZ + maxZ) / 2;
        const supportMat = new THREE.MeshStandardMaterial({ color: 0x9aa3a8, roughness: 0.62, metalness: 0.18, transparent: true, opacity: 0.24, depthWrite: false });
        const darkSupportMat = new THREE.MeshStandardMaterial({ color: 0x293139, roughness: 0.74, metalness: 0.08 });
        const boardMat = new THREE.MeshStandardMaterial({ color: 0x6aa36f, roughness: 0.48, metalness: 0.04 });
        const selectedComponentMat = new THREE.MeshStandardMaterial({ color: 0xffd36b, roughness: 0.34, metalness: 0.32, emissive: 0x3a2500 });
        const plateT = Math.max(cellRef * 0.10, 3);
        function addSupportBox(center, sx, sy, sz, mat, name, role, qty) {
            const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), selectedComponentName === name ? selectedComponentMat : mat);
            mesh.position.copy(center);
            mesh.renderOrder = 2;
            mesh.userData.pickKind = 'component';
            mesh.userData.componentName = name;
            mesh.userData.componentRole = role;
            mesh.userData.componentQty = qty;
            group.add(mesh);
            return mesh;
        }
        const supportSpread = isExploded ? explodeUnit * 0.55 : 0;
        addSupportBox(new THREE.Vector3(centerX, centerY, minZ - plateT * 0.7 - supportSpread), packX + plateT * 2, packY + plateT * 2, plateT, supportMat, 'Seitenwand links', 'Seitliche mechanische Abstuetzung der prismatischen Zellen.', 1);
        addSupportBox(new THREE.Vector3(centerX, centerY, maxZ + plateT * 0.7 + supportSpread), packX + plateT * 2, packY + plateT * 2, plateT, supportMat, 'Seitenwand rechts', 'Seitliche mechanische Abstuetzung der prismatischen Zellen.', 1);
        const boardY = maxY + terminalThickness * 0.25 + (isExploded ? explodeUnit * 0.95 : 0);
        addSupportBox(new THREE.Vector3(centerX, boardY, centerZ), Math.max(packX - plateT * 4, cellWidth), Math.max(terminalThickness * 0.9, 2.4), Math.max(packZ * 0.42, cellDepth * 0.8), boardMat, 'Zellmodul-Platine', 'Obere Trage-/Kontaktlage fuer Messung und Zellverbinder.', 1);
        const spineCount = Math.max(2, Math.min(6, uniqueSorted(positions.map(p => p.z)).length));
        for (let i = 0; i < spineCount; i++) {
            const t = spineCount === 1 ? 0.5 : i / (spineCount - 1);
            const z = minZ + packZ * t;
            addSupportBox(new THREE.Vector3(centerX, boardY + terminalThickness * 0.55, z), packX + plateT, Math.max(frameThickness, 2.5), Math.max(crossWidth * 0.55, 3.5), darkSupportMat, 'Quertraeger', 'Mechanische Aussteifung und Trennung der Zellreihen.', spineCount);
        }
        const separatorMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.92, depthTest: false, depthWrite: false });
        const separatorVerts = [];
        const xs = uniqueSorted(positions.map(p => p.x)).map(x => x - sp.l / 2);
        const zs = uniqueSorted(positions.map(p => p.z)).map(z => -(z - sp.w / 2));
        const topY = maxY + Math.max(terminalThickness * 0.9, 2);
        xs.forEach(x => {
            separatorVerts.push(x - cellWidth / 2, topY, minZ, x - cellWidth / 2, topY, maxZ);
            separatorVerts.push(x + cellWidth / 2, topY, minZ, x + cellWidth / 2, topY, maxZ);
        });
        zs.forEach(z => {
            separatorVerts.push(minX, topY, z - cellDepth / 2, maxX, topY, z - cellDepth / 2);
            separatorVerts.push(minX, topY, z + cellDepth / 2, maxX, topY, z + cellDepth / 2);
        });
        const separatorGeo = new THREE.BufferGeometry();
        separatorGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(separatorVerts), 3));
        const separatorLines = new THREE.LineSegments(separatorGeo, separatorMat);
        separatorLines.renderOrder = 20;
        group.add(separatorLines);
    }
    if (!modelUiHidden) {
        addPackEnclosure(group, result, instanceQuat, explodeUnit);
    }
    addElectricalBusbars(group, result, electrical, axis, longHalf, busbarExplodeOffset);
    return group;
}
function visualizeResult(result, keepCamera = false) {
    clearScene();
    currentResult = result;
    const renderResult = getDisplayResult(result);
    currentRenderResult = renderResult;
    const { cell, extrusionDir, sp, positions, gridOffset, cellRotation } = renderResult;
    const { l, w, h } = sp;
    syncModelUiToggle();
    if (!modelUiHidden) {
        updateBoundingBox(sp);
        addObj(buildShapeMesh(renderResult));
        addObj(buildDimensionLines(renderResult.sp, visMode === 'pack'));
    }
    else if (bboxObject) {
        scene.remove(bboxObject);
        bboxObject = null;
    }
    if (!modelUiHidden && visMode !== 'pack' && visMode !== 'explode') {
        addObj(buildGridLines(renderResult));
    }
    // Cell geometry: long axis along Y, rotated per extrusionDir
    const cellGeo = makeCellGeo(cell, extrusionDir, cellRotation);
    // Rotation quaternion: pack3D returns world-space positions with cell long axis along:
    //   extDir=z → world Y  (no rotation needed)
    //   extDir=x → world X  (rotate 90° around Z)
    //   extDir=y → world Z  (rotate 90° around X)
    const instanceQuat = new THREE.Quaternion();
    if (extrusionDir === 'x') {
        instanceQuat.setFromEuler(new THREE.Euler(0, 0, Math.PI / 2));
    }
    else if (extrusionDir === 'y') {
        instanceQuat.setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0));
    }
    // pack3D returns world coords: X ∈ [0..l], Y ∈ [0..h], Z ∈ [0..w]
    // Housing mesh is centred: X → X-l/2, Y stays, Z → -(Z-w/2)
    const totalCount = positions.length;
    // Assign a colour per "layer" — group cells by their stack-axis coordinate
    // so visually distinct layers get different colours.
    const stackCoords = new Map();
    for (const p of positions) {
        const key = extrusionDir === 'z' ? p.y
            : extrusionDir === 'x' ? p.x
                : p.z;
        const rounded = Math.round(key * 10) / 10;
        if (!stackCoords.has(rounded))
            stackCoords.set(rounded, stackCoords.size);
    }
    const cellColor = new THREE.Color();
    if (visMode === 'pack' || visMode === 'explode') {
        const obj = buildPackVisualization(renderResult, cellGeo, instanceQuat);
        obj.frustumCulled = false;
        obj.renderOrder = 1;
        addObj(obj);
        updateCountUI(totalCount, stackCoords.size, renderResult);
        updateElectricalSummary();
        if (modelUiHidden)
            hide('overlay');
        else
            show('overlay');
        show('visControls');
        syncModelUiToggle();
        void gridOffset;
        if (!keepCamera) {
            const size = Math.max(l, w, h);
            controls.target.set(0, h / 2, 0);
            camera.position.set(size * 1.2, h / 2 + size * 1.0, size * 1.2);
            const ortho = camera;
            const half = size * 1.4;
            const aspect = canvas.clientWidth / canvas.clientHeight;
            ortho.left = -half * aspect;
            ortho.right = half * aspect;
            ortho.top = half;
            ortho.bottom = -half;
            ortho.updateProjectionMatrix();
            controls.update();
        }
        return;
    }
    // Build one merged BufferGeometry with all cell vertices baked into world coordinates.
    const srcGeo = visMode === 'skeleton' ? new THREE.EdgesGeometry(cellGeo) : cellGeo;
    const srcPos = srcGeo.getAttribute('position');
    const srcIdx = srcGeo.index;
    const vertsPerCell = srcPos.count;
    const trisPerCell = srcIdx ? srcIdx.count : vertsPerCell;
    const allPos = new Float32Array(totalCount * vertsPerCell * 3);
    const allColors = new Float32Array(totalCount * vertsPerCell * 3);
    const allIdx = srcIdx ? new Uint32Array(totalCount * trisPerCell) : null;
    const tmpVec = new THREE.Vector3();
    let vOffset = 0;
    let iOffset = 0;
    for (const p of positions) {
        // Convert pack3D world coords → mesh-centred world coords
        const worldPos = new THREE.Vector3(p.x - l / 2, p.y, -(p.z - w / 2));
        const stackKey = extrusionDir === 'z' ? Math.round(p.y * 10) / 10
            : extrusionDir === 'x' ? Math.round(p.x * 10) / 10
                : Math.round(p.z * 10) / 10;
        const layerIdx = stackCoords.get(stackKey) ?? 0;
        cellColor.set(CELL_COLORS[layerIdx % CELL_COLORS.length]);
        const baseVert = vOffset / 3;
        for (let v = 0; v < vertsPerCell; v++) {
            tmpVec.set(srcPos.getX(v), srcPos.getY(v), srcPos.getZ(v));
            tmpVec.applyQuaternion(instanceQuat).add(worldPos);
            allPos[vOffset] = tmpVec.x;
            allPos[vOffset + 1] = tmpVec.y;
            allPos[vOffset + 2] = tmpVec.z;
            allColors[vOffset] = cellColor.r;
            allColors[vOffset + 1] = cellColor.g;
            allColors[vOffset + 2] = cellColor.b;
            vOffset += 3;
        }
        if (allIdx && srcIdx) {
            for (let i = 0; i < trisPerCell; i++) {
                allIdx[iOffset++] = baseVert + srcIdx.getX(i);
            }
        }
    }
    const mergedGeo = new THREE.BufferGeometry();
    mergedGeo.setAttribute('position', new THREE.BufferAttribute(allPos, 3));
    mergedGeo.setAttribute('color', new THREE.BufferAttribute(allColors, 3));
    if (allIdx)
        mergedGeo.setIndex(new THREE.BufferAttribute(allIdx, 1));
    let obj;
    if (visMode === 'skeleton') {
        obj = new THREE.LineSegments(mergedGeo, new THREE.LineBasicMaterial({ vertexColors: true }));
    }
    else if (visMode === 'wire') {
        obj = new THREE.Mesh(mergedGeo, new THREE.MeshStandardMaterial({ wireframe: true, vertexColors: true }));
    }
    else {
        obj = new THREE.Mesh(mergedGeo, new THREE.MeshStandardMaterial({
            metalness: cell.type === 'round' ? 0.7 : 0.5,
            roughness: cell.type === 'round' ? 0.3 : 0.4,
            vertexColors: true,
        }));
    }
    obj.frustumCulled = false;
    obj.renderOrder = 1;
    addObj(obj);
    updateCountUI(totalCount, stackCoords.size, result);
    updateElectricalSummary();
    if (modelUiHidden)
        hide('overlay');
    else
        show('overlay');
    show('visControls');
    syncModelUiToggle();
    // suppress unused
    void gridOffset;
    if (!keepCamera) {
        const size = Math.max(l, w, h);
        controls.target.set(0, h / 2, 0);
        // Isometric-style position: equal angle on all three axes
        camera.position.set(size * 1.2 + 0, h / 2 + size * 1.0, size * 1.2);
        // Fit the housing into view via orthographic frustum half-size
        const ortho = camera;
        const half = size * 1.4;
        const aspect = canvas.clientWidth / canvas.clientHeight;
        ortho.left = -half * aspect;
        ortho.right = half * aspect;
        ortho.top = half;
        ortho.bottom = -half;
        ortho.updateProjectionMatrix();
        controls.update();
    }
}
// Updates every count-related UI element from the same values.
function updateCountUI(total, layers, result) {
    const perLayer = layers > 0 ? Math.round(total / layers) : 0;
    // 3D overlay
    el('ov_total').textContent = String(total);
    el('ov_grid').textContent = String(perLayer);
    el('ov_layers').textContent = String(layers);
    el('ov_orient').textContent = orientationText(result);
    if (packViewMode === 'electrical' && currentResult && currentResult.total !== total) {
        const electrical = getElectricalSummaryData();
        const perLayerTarget = Math.round(total / Math.max(1, layers));
        el('bestCount').textContent = `${total} Zellen`;
        el('bestDesc').textContent =
            `${perLayerTarget} pro Ebene - Ziel-Pack ${electrical.series}s${electrical.parallel}p`;
        el('bestDims').textContent = packDimensionText(result);
        el('bestRaster').textContent = approximateRasterText(result);
        el('resultExplain').textContent =
            `Die 3D-Ansicht zeigt den Ziel-Pack fuer ${electrical.series}s${electrical.parallel}p als kompakte Zellgruppe. Im urspruenglichen Bauraum waeren ${currentResult.total} Zellplaetze moeglich.`;
        return;
    }
    if (result.source === 'grid' && result.layout) {
        el('bestCount').textContent = `${total} Zellen`;
        el('bestDesc').textContent = `${result.layout.cols} x ${result.layout.rows} x ${result.layout.layers} Zellraster`;
        el('bestDims').textContent = packDimensionText(result);
        el('bestRaster').textContent = approximateRasterText(result);
        el('resultExplain').textContent =
            `Das Modell zeigt exakt das vorgegebene Zellraster: ${result.layout.cols} Zellen in der Laenge, ${result.layout.rows} Zellen in der Breite und ${result.layout.layers} Ebenen. Daraus wird der benoetigte Bauraum berechnet.`;
        return;
    }
    // Header above the result list (shows the active result, not necessarily the best)
    el('bestCount').textContent = `${total} Zellen`;
    el('bestDesc').textContent = `${perLayer} pro Ebene | ${layers} Ebenen | ${orientationText(result)}`;
    el('bestDims').textContent = packDimensionText(result);
    el('bestRaster').textContent = approximateRasterText(result);
    el('resultExplain').textContent =
        `${total} Zellen passen in diesen Bauraum. Das entspricht ca. ${perLayer} Zellen pro Ebene bei ${layers} Ebenen. Die beste Anordnung nutzt ${orientationText(result)}.`;
    // Update the active row in the list in-place (no full re-render)
    const activeRow = el('resultList').querySelector('.result-row.active');
    if (activeRow) {
        const countEl = activeRow.querySelector('.count');
        const subEl = activeRow.querySelector('span[style]');
        if (countEl)
            countEl.textContent = String(total);
        if (subEl)
            subEl.textContent = `${perLayer}×${layers}`;
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// UI HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function el(id) {
    return document.getElementById(id);
}
function fmtMm(n) {
    return `${Math.round(n * 10) / 10}`;
}
function packDimensionText(result) {
    return `Packmasse: Laenge ${fmtMm(result.sp.l)} mm | Breite ${fmtMm(result.sp.w)} mm | Hoehe ${fmtMm(result.sp.h)} mm`;
}
function approximateRasterText(result) {
    const xs = new Set();
    const zs = new Set();
    const stacks = new Set();
    for (const p of result.positions) {
        xs.add(Math.round(p.x * 10) / 10);
        zs.add(Math.round(p.z * 10) / 10);
        const stack = result.extrusionDir === 'z'
            ? p.y
            : result.extrusionDir === 'x'
                ? p.x
                : p.z;
        stacks.add(Math.round(stack * 10) / 10);
    }
    return `Raster: ca. ${xs.size} Zellen entlang Laenge x ${zs.size} entlang Breite x ${stacks.size} Ebenen`;
}
function val(id) {
    return parseFloat(document.getElementById(id).value);
}
function selVal(id) {
    return document.getElementById(id).value;
}
function show(id) { el(id).style.display = ''; }
function hide(id) { el(id).style.display = 'none'; }
function createTaskTab(title, content, open = false) {
    const tab = document.createElement('details');
    tab.className = 'task-tab';
    tab.open = open;
    const label = document.createElement('summary');
    label.className = 'task-tab-label';
    label.textContent = title;
    const panel = document.createElement('div');
    panel.className = 'task-tab-panel';
    panel.appendChild(content);
    tab.append(label, panel);
    return tab;
}
void createTaskTab;
function decorateWorkflowCard(card, step, title, text) {
    card.classList.add('workflow-card');
    const originalTitle = card.querySelector('.card-title');
    if (originalTitle)
        originalTitle.remove();
    const header = document.createElement('div');
    header.className = 'workflow-card-head';
    header.innerHTML = `
    <span class="workflow-step">${step}</span>
    <div>
      <div class="workflow-title">${title}</div>
      <div class="workflow-copy">${text}</div>
    </div>
  `;
    card.prepend(header);
}
function addHelpTooltip(targetId, text) {
    const target = document.getElementById(targetId);
    const label = target?.closest('div')?.querySelector('label');
    if (!label || label.querySelector('.help-dot'))
        return;
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'help-dot';
    dot.textContent = '?';
    dot.setAttribute('aria-label', text);
    dot.dataset.tip = text;
    label.appendChild(dot);
}
function setupHelpTooltips() {
    addHelpTooltip('shapeType', 'Grundform des verfuegbaren Bauraums, in den die Zellen gepackt werden.');
    addHelpTooltip('dim_l', 'Laenge des Bauraums entlang der X-Achse in Millimetern.');
    addHelpTooltip('dim_w', 'Breite des Bauraums entlang der Y-Achse in Millimetern.');
    addHelpTooltip('dim_h', 'Hoehe des Bauraums. Sie begrenzt, wie viele Zellebenen uebereinander passen.');
    addHelpTooltip('cellType', 'Rundzellen sind zylindrisch, prismatische Zellen sind rechteckige Zellkoerper.');
    addHelpTooltip('gridType', 'Honeycomb versetzt Rundzellen zeilenweise und nutzt den Platz oft besser als ein rechteckiges Raster.');
    addHelpTooltip('paramMargin', 'Sicherheitsabstand zwischen aeusserster Zelle und Bauraumkante.');
    addHelpTooltip('paramLayerGap', 'Abstand zwischen zwei Zelllagen oder Ebenen.');
    addHelpTooltip('paramGapRound', 'Seitlicher Abstand zwischen Rundzellen.');
    addHelpTooltip('paramGapPrism', 'Seitlicher Abstand zwischen prismatischen Zellen.');
    addHelpTooltip('packVoltage', 'Nennspannung einer einzelnen Zelle. Typisch fuer Li-Ion: ca. 3.6 bis 3.7 V.');
    addHelpTooltip('packCapacity', 'Kapazität einer einzelnen Zelle in Ah.');
    addHelpTooltip('seriesCells', 'Serienschaltung erhoeht die Spannung. 13s bedeutet 13 Zellen in Reihe.');
    addHelpTooltip('parallelCells', 'Parallelschaltung erhöht Kapazität und Stromfähigkeit. 4p bedeutet 4 parallele Zellen je Serie.');
}
function addTargetTooltips() {
    addHelpTooltip('targetVoltage', 'Vom Kunden vorgegebene Zielspannung. Daraus wird zuerst die passende Serienanzahl berechnet.');
    addHelpTooltip('targetCapacity', 'Gewuenschte Mindestkapazitaet des Packs in Ah.');
    addHelpTooltip('targetPower', 'Leistungsbedarf des Verbrauchers. Daraus wird der benoetigte Packstrom berechnet.');
    addHelpTooltip('targetRuntimeMin', 'Gewuenschte Laufzeit. Zusammen mit der Leistung ergibt sich die benoetigte Energie/Kapazitaet.');
    addHelpTooltip('targetMaxDischargeCurrent', 'Maximal zulaessiger Entladestrom pro Zelle. Mehr parallele Zellen erhoehen den Packstrom.');
    addHelpTooltip('targetMaxChargeCurrent', 'Maximal zulaessiger Ladestrom pro Zelle. Wird fuer die Pack-Ladegrenze ausgewertet.');
}
function addLayoutTooltips() {
    addHelpTooltip('layoutCols', 'Optional: Anzahl der Zellen in Laengsrichtung des Ziel-Packs. 0 laesst die App automatisch aufteilen.');
    addHelpTooltip('layoutRows', 'Optional: Anzahl der Zellreihen in der Breite des Ziel-Packs. 0 laesst die App automatisch aufteilen.');
    addHelpTooltip('layoutLayers', 'Optional: Anzahl der Ebenen im Ziel-Pack. 0 laesst die App automatisch aufteilen.');
}
function createCapacityVoltagePanel() {
    const card = document.createElement('div');
    card.className = 'card task-card';
    card.innerHTML = `
    <div class="card-title">Kapazität & Spannung</div>
    <div class="row2">
      <div>
        <label>Zellspannung V</label>
        <input type="number" id="packVoltage" value="3.6" min="0" step="0.01" />
      </div>
      <div>
        <label>Zellkapazität Ah</label>
        <input type="number" id="packCapacity" value="3.0" min="0" step="0.1" />
      </div>
    </div>
    <div class="row2">
      <div>
        <label>Berechnete Serien-Zellen</label>
        <input type="number" id="seriesCells" value="13" min="1" step="1" readonly />
      </div>
      <div>
        <label>Berechnete Parallel-Zellen</label>
        <input type="number" id="parallelCells" value="4" min="1" step="1" readonly />
      </div>
    </div>
    <div class="layout-box" id="electricalTargetBox">
      <div class="subsection-title">Kundeneingabe</div>
      <div class="workflow-copy">Die Zielspannung ist die zentrale Kundenvorgabe. Danach werden Kapazitaet, Laufzeit und Strombedarf fuer die Parallelgruppen bewertet.</div>
      <div class="row2">
        <div>
          <label>Zielspannung V</label>
          <input type="number" id="targetVoltage" value="48" min="0" step="0.1" />
        </div>
        <div>
          <label>Zielkapazitaet Ah</label>
          <input type="number" id="targetCapacity" value="12" min="0" step="0.1" />
        </div>
      </div>
      <div class="row2">
        <div>
          <label>Leistungsbedarf W</label>
          <input type="number" id="targetPower" value="0" min="0" step="1" />
        </div>
        <div>
          <label>Laufzeit min</label>
          <input type="number" id="targetRuntimeMin" value="0" min="0" step="1" />
        </div>
      </div>
      <div class="row2">
        <div>
          <label>Max. Entladestrom A/Zelle</label>
          <input type="number" id="targetMaxDischargeCurrent" value="0" min="0" step="0.1" />
        </div>
        <div>
          <label>Max. Ladestrom A/Zelle</label>
          <input type="number" id="targetMaxChargeCurrent" value="0" min="0" step="0.1" />
        </div>
      </div>
    </div>
    <div class="layout-box" id="layoutBox">
      <div class="subsection-title">Pack-Aufteilung</div>
      <div class="workflow-copy" id="layoutHint">Hier gibt der Kunde die Anzahl der Batteriezellen vor: Zellen in Laenge, Zellen in Breite und Anzahl der Ebenen.</div>
      <div class="row3">
        <div>
          <label>Zellen Laenge</label>
          <input type="number" id="layoutCols" value="0" min="0" step="1" />
        </div>
        <div>
          <label>Zellen Breite</label>
          <input type="number" id="layoutRows" value="0" min="0" step="1" />
        </div>
        <div>
          <label>Ebenen</label>
          <input type="number" id="layoutLayers" value="0" min="0" step="1" />
        </div>
      </div>
    </div>
    <div class="view-switch" id="viewSwitch">
      <span>3D-Ansicht</span>
      <div class="segmented">
        <button type="button" class="seg-btn active" id="viewElectricalBtn">Ziel-Pack</button>
      </div>
    </div>
    <div class="pack-summary">
      <div><span>Packspannung</span><strong id="calcVoltage">-- V</strong></div>
      <div><span>Kapazität</span><strong id="calcCapacity">-- Ah</strong></div>
      <div><span>Energie</span><strong id="calcEnergy">-- Wh</strong></div>
      <div><span>Zellbedarf</span><strong id="calcCells">--</strong></div>
      <div class="pack-fit" id="calcFit">Noch kein Optimierungsergebnis.</div>
    </div>
    <div class="calculation-window">
      <div class="subsection-title">Rechnung</div>
      <pre id="calcFormula">Noch keine Rechnung.</pre>
    </div>
  `;
    return card;
}
function setElectricalInputs(series, parallel) {
    const sEl = document.getElementById('seriesCells');
    const pEl = document.getElementById('parallelCells');
    if (sEl)
        sEl.value = String(series);
    if (pEl)
        pEl.value = String(parallel);
}
function positiveInputValue(id) {
    const input = document.getElementById(id);
    if (!input)
        return null;
    const raw = input.value.trim().replace(',', '.');
    if (!raw)
        return null;
    const parsed = Number.parseFloat(raw);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}
function targetCapacityDemandAh(referenceVoltage) {
    const targetCapacity = positiveInputValue('targetCapacity') ?? 0;
    const targetPower = positiveInputValue('targetPower') ?? 0;
    const targetRuntimeMin = positiveInputValue('targetRuntimeMin') ?? 0;
    const runtimeCapacity = referenceVoltage > 0 && targetPower > 0 && targetRuntimeMin > 0
        ? (targetPower * (targetRuntimeMin / 60)) / referenceVoltage
        : 0;
    return Math.max(targetCapacity, runtimeCapacity);
}
function targetDischargeCurrentDemandA(referenceVoltage) {
    const targetPower = positiveInputValue('targetPower') ?? 0;
    return referenceVoltage > 0 && targetPower > 0 ? targetPower / referenceVoltage : 0;
}
function targetParallelDemand(referenceVoltage, cellCapacityAh) {
    const requiredCapacityAh = targetCapacityDemandAh(referenceVoltage);
    const currentDemandA = targetDischargeCurrentDemandA(referenceVoltage);
    const maxCellDischargeA = positiveInputValue('targetMaxDischargeCurrent') ?? 0;
    const capacityCells = requiredCapacityAh > 0 && cellCapacityAh > 0
        ? Math.ceil(requiredCapacityAh / cellCapacityAh)
        : 1;
    const currentCells = currentDemandA > 0 && maxCellDischargeA > 0
        ? Math.ceil(currentDemandA / maxCellDischargeA)
        : 1;
    const minParallelCells = Math.max(1, capacityCells, currentCells);
    return {
        requiredCapacityAh,
        currentDemandA,
        maxCellDischargeA,
        minParallelCells,
        hasDemand: requiredCapacityAh > 0 || currentCells > 1,
    };
}
function findBestTargetConfig(result, cellVoltage, cellCapacityAh) {
    const targetVoltage = positiveInputValue('targetVoltage');
    const stackCount = sortedElectricalStacks(result).length;
    const maxLayerParallel = maxParallelCellsInOneLayer(result);
    const hasVoltageTarget = targetVoltage !== null && cellVoltage > 0;
    const referenceVoltage = hasVoltageTarget ? targetVoltage : cellVoltage;
    const initialDemand = targetParallelDemand(referenceVoltage, cellCapacityAh);
    const hasParallelDemand = initialDemand.hasDemand;
    const preferredSeries = hasVoltageTarget
        ? Math.round(clamp(targetVoltage / cellVoltage, 1, Math.max(1, stackCount)))
        : Math.max(1, stackCount);
    let best = {
        series: preferredSeries,
        parallel: clamp(initialDemand.minParallelCells, 1, maxLayerParallel),
        score: Number.POSITIVE_INFINITY,
    };
    if (!hasVoltageTarget && !hasParallelDemand) {
        return best;
    }
    for (let p = 1; p <= maxLayerParallel; p++) {
        const maxSeriesGroups = maxSeriesGroupsForParallel(result, p);
        if (maxSeriesGroups < 1)
            continue;
        for (let seriesGroups = 1; seriesGroups <= maxSeriesGroups; seriesGroups++) {
            const s = seriesGroups;
            const voltage = s * cellVoltage;
            const capacity = p * cellCapacityAh;
            const demand = targetParallelDemand(hasVoltageTarget ? targetVoltage : voltage, cellCapacityAh);
            const unusedStacks = stackCount - seriesGroups * p;
            const unusedPenalty = unusedStacks / Math.max(1, stackCount) * 0.08;
            let score = unusedPenalty;
            if (hasVoltageTarget) {
                const voltageErr = Math.abs(voltage - targetVoltage) / targetVoltage;
                const seriesDistance = Math.abs(s - preferredSeries) / Math.max(1, preferredSeries);
                score += voltageErr * 4 + seriesDistance * 0.4;
            }
            if (demand.hasDemand) {
                const parallelErr = Math.abs(p - demand.minParallelCells) / Math.max(1, demand.minParallelCells);
                const parallelUnderPenalty = p < demand.minParallelCells ? 1.2 : 0;
                score += parallelErr + parallelUnderPenalty;
                if (demand.requiredCapacityAh > 0) {
                    const capacityErr = Math.abs(capacity - demand.requiredCapacityAh) / demand.requiredCapacityAh;
                    const capacityUnderPenalty = capacity < demand.requiredCapacityAh ? 0.75 : 0;
                    score += capacityErr * 0.45 + capacityUnderPenalty;
                }
            }
            else if (hasVoltageTarget) {
                score -= p / Math.max(1, maxLayerParallel) * 0.04;
            }
            if (score < best.score)
                best = { series: s, parallel: p, score };
        }
    }
    return best;
}
function resolveElectricalConfig(result) {
    const cellVoltage = val('packVoltage') || 0;
    const cellCapacityAh = val('packCapacity') || 0;
    const stacks = result ? sortedElectricalStacks(result) : [];
    const stackCount = Math.max(0, stacks.length);
    if (electricalMode === 'max_voltage' && stackCount > 0) {
        const series = stackCount;
        const parallel = 1;
        setElectricalInputs(series, parallel);
        return { series, parallel, modeText: 'Maximale Spannung' };
    }
    if (electricalMode === 'max_capacity' && stackCount > 0) {
        const parallel = result ? maxParallelCellsInOneLayer(result) : stackCount;
        const series = result ? Math.max(1, maxSeriesGroupsForParallel(result, parallel)) : 1;
        setElectricalInputs(series, parallel);
        return { series, parallel, modeText: 'Maximale Kapazitaet' };
    }
    if (electricalMode === 'target' && stackCount > 0) {
        const best = findBestTargetConfig(result, cellVoltage, cellCapacityAh);
        setElectricalInputs(best.series, best.parallel);
        return { series: best.series, parallel: best.parallel, modeText: 'Kundeneingabe' };
    }
    return { series: 1, parallel: 1, modeText: 'Elektrische Auslegung' };
}
function updateCalculationWindow(lines) {
    const formula = document.getElementById('calcFormula');
    if (formula)
        formula.textContent = lines.join('\n');
}
function maxElectricalConfigurationLines(totalCells, cellVoltage, cellCapacityAh, selectedSeries, selectedParallel, result) {
    const available = Math.max(0, Math.floor(totalCells));
    if (available < 1 || cellVoltage <= 0 || cellCapacityAh <= 0) {
        return ['', 'Kundeneingabe-Pruefung: erst nach gueltiger Zellzahl, Zellspannung und Zellkapazitaet moeglich.'];
    }
    const series = Math.max(1, selectedSeries);
    const parallel = Math.max(1, selectedParallel);
    const requiredCells = series * parallel;
    const packVoltage = series * cellVoltage;
    const packCapacityAh = parallel * cellCapacityAh;
    const packEnergyWh = packVoltage * packCapacityAh;
    const reserve = available - requiredCells;
    const fitText = reserve >= 0
        ? `passt; ${reserve} Zellplaetze bleiben als Reserve`
        : `passt nicht; es fehlen ${Math.abs(reserve)} Zellplaetze`;
    const topology = result ? createElectricalTopology(result, series, parallel) : null;
    const topologyCells = topology
        ? topology.groups.reduce((sum, group) => (sum + group.stacks.reduce((inner, stack) => inner + stack.cells.length, 0)), 0)
        : requiredCells;
    return [
        '',
        'Pruefung der Kundeneingabe:',
        `Grundregel: Parallelgruppen liegen innerhalb einer Ebene und bestehen aus benachbarten Zellen; Ebenen werden nicht automatisch parallelisiert.`,
        `Kundeneingabe: ${series}s${parallel}p -> ${packVoltage.toFixed(1)} V, ${packCapacityAh.toFixed(1)} Ah, ${Math.round(packEnergyWh)} Wh`,
        `Benoetigte Zellen: ${series} x ${parallel} = ${requiredCells} Zellen`,
        `Verfuegbarer Bauraum: ${available} Zellplaetze; Status = ${fitText}`,
        `3D-Topologie: ${topologyCells} Zellen in ${series} Seriengruppen mit je ${parallel} parallelen Zellen`,
    ];
}
function electricalVisualizationCheckLines(totalCells, series, parallel) {
    const required = series * parallel;
    const visualGroups = Math.ceil(required / Math.max(1, parallel));
    const fullGroups = Math.floor(required / Math.max(1, parallel));
    const lastGroup = required % Math.max(1, parallel);
    const groupText = lastGroup === 0
        ? `${fullGroups} Gruppen mit je ${parallel} parallelen Zellen`
        : `${fullGroups} volle Gruppen mit je ${parallel}p und 1 Restgruppe mit ${lastGroup} Zellen`;
    const status = totalCells >= required && visualGroups === series
        ? 'passt'
        : 'abweichend';
    return [
        '',
        'Verschaltungscheck fuer die 3D-Ansicht:',
        `Rechnung = ${series}s${parallel}p -> ${required} genutzte Zellen`,
        `Visualisierung muss zeigen: ${groupText}`,
        `Seriengruppen sichtbar/erzeugt = ${visualGroups}; erwartet = ${series}`,
        `Status = ${status}`,
    ];
}
function electricalVisualizationCheckLinesForResult(result, series, parallel) {
    const required = series * parallel;
    const topology = createElectricalTopology(result, series, parallel);
    const generatedCells = topology.groups.reduce((sum, group) => (sum + group.stacks.reduce((inner, stack) => inner + stack.cells.length, 0)), 0);
    const generatedStacks = topology.groups.reduce((sum, group) => sum + group.stacks.length, 0);
    const fullParallelGroups = topology.groups.filter(group => (group.stacks.reduce((sum, stack) => sum + stack.cells.length, 0) === parallel)).length;
    const expectedStackGroups = series;
    const expectedSeriesBridges = Math.max(0, topology.groups.length - 1);
    const status = result.total >= required
        && topology.groups.length === expectedStackGroups
        && generatedCells === required
        && fullParallelGroups === expectedStackGroups
        ? 'passt'
        : 'abweichend';
    return [
        '',
        'Verschaltungscheck fuer die 3D-Ansicht:',
        `Rechnung = ${series}s${parallel}p -> ${required} genutzte Zellen`,
        `Parallelgruppen = ${parallel} benachbarte Zellen innerhalb derselben Ebene; erwartet = ${expectedStackGroups} Seriengruppen`,
        `Topologie erzeugt = ${topology.groups.length} Seriengruppen, ${generatedStacks} Zellen in Parallelgruppen, ${generatedCells} Zellen gesamt`,
        `Parallelgruppen vollstaendig = ${fullParallelGroups} von ${expectedStackGroups}`,
        `Serienbruecken zwischen Gruppen = ${expectedSeriesBridges}; Busbars bleiben innerhalb der Ebene bis zum Ebenenwechsel`,
        `Busbar-Regel = kurze Verbinder innerhalb einer Parallelgruppe, danach Plus zu Minus zwischen Nachbargruppen`,
        `Status = ${status}`,
    ];
}
function targetRequirementLines(series, parallel, packVoltage, packCapacityAh, cellCapacityAh) {
    const targetVoltage = positiveInputValue('targetVoltage');
    const targetCapacity = positiveInputValue('targetCapacity');
    const targetPower = positiveInputValue('targetPower');
    const targetRuntimeMin = positiveInputValue('targetRuntimeMin');
    const maxCellDischargeA = positiveInputValue('targetMaxDischargeCurrent');
    const maxCellChargeA = positiveInputValue('targetMaxChargeCurrent');
    const hasAnyTarget = targetVoltage !== null ||
        targetCapacity !== null ||
        targetPower !== null ||
        targetRuntimeMin !== null ||
        maxCellDischargeA !== null ||
        maxCellChargeA !== null;
    if (electricalMode !== 'target' || !hasAnyTarget)
        return [];
    const referenceVoltage = targetVoltage ?? packVoltage;
    const demand = targetParallelDemand(referenceVoltage, cellCapacityAh);
    const lines = ['', 'Kundeneingabe-Auswertung:'];
    if (targetVoltage !== null) {
        lines.push(`Zielspannung = ${targetVoltage.toFixed(1)} V -> ${series}s ergibt ${packVoltage.toFixed(1)} V`);
    }
    if (targetCapacity !== null) {
        lines.push(`Zielkapazitaet = ${targetCapacity.toFixed(1)} Ah -> Pack erreicht ${packCapacityAh.toFixed(1)} Ah`);
    }
    if (targetPower !== null && packVoltage > 0) {
        const packCurrent = targetDischargeCurrentDemandA(packVoltage);
        lines.push(`Leistungsbedarf = ${targetPower.toFixed(0)} W -> Betriebsstrom ca. ${packCurrent.toFixed(1)} A`);
    }
    if (targetRuntimeMin !== null && targetPower !== null && referenceVoltage > 0) {
        const runtimeEnergy = targetPower * (targetRuntimeMin / 60);
        const runtimeCapacity = runtimeEnergy / referenceVoltage;
        lines.push(`Laufzeit = ${targetRuntimeMin.toFixed(0)} min -> Bedarf ca. ${Math.round(runtimeEnergy)} Wh bzw. ${runtimeCapacity.toFixed(1)} Ah`);
    }
    if (demand.hasDemand) {
        lines.push(`Mindest-Parallelbedarf aus Kapazitaet/Strom = ${demand.minParallelCells}p; gewaehlt = ${parallel}p`);
    }
    if (maxCellDischargeA !== null) {
        const packDischargeLimit = maxCellDischargeA * parallel;
        const packCurrent = packVoltage > 0 ? targetDischargeCurrentDemandA(packVoltage) : 0;
        const status = packCurrent > 0 && packCurrent > packDischargeLimit ? 'zu niedrig' : 'ok';
        lines.push(`Entladegrenze = ${parallel}p x ${maxCellDischargeA.toFixed(1)} A/Zelle = ${packDischargeLimit.toFixed(1)} A (${status})`);
    }
    if (maxCellChargeA !== null) {
        lines.push(`Ladegrenze = ${parallel}p x ${maxCellChargeA.toFixed(1)} A/Zelle = ${(parallel * maxCellChargeA).toFixed(1)} A`);
    }
    lines.push('Regel: Zielspannung bestimmt zuerst s; Kapazitaet, Laufzeit und Stromgrenzen bestimmen danach p.');
    return lines;
}
function updateElectricalSummary() {
    const voltage = val('packVoltage') || 0;
    const capacity = val('packCapacity') || 0;
    const availableCells = currentResult?.total ?? 0;
    const cfg = resolveElectricalConfig(currentResult);
    const series = cfg.series;
    const parallel = cfg.parallel;
    const requiredCells = series * parallel;
    const packVoltage = voltage * series;
    const requestedCapacity = capacity * parallel;
    const requestedEnergy = packVoltage * requestedCapacity;
    const theoreticalEnergy = requiredCells * voltage * capacity;
    const fitEl = el('calcFit');
    fitEl.classList.remove('ok', 'warn');
    const visualLines = currentResult
        ? [
            ...electricalVisualizationCheckLinesForResult(currentResult, series, parallel),
            ...electricalGroupAddressLines(currentResult, series, parallel),
        ]
        : electricalVisualizationCheckLines(availableCells, series, parallel);
    const formulaLines = [
        `${cfg.modeText}: ${series}s${parallel}p`,
        `Packspannung = ${series} x ${voltage} V = ${packVoltage.toFixed(1)} V`,
        `Kapazitaet = ${parallel} x ${capacity} Ah = ${requestedCapacity.toFixed(1)} Ah`,
        `Zellbedarf = ${series} x ${parallel} = ${requiredCells} Zellen`,
        `Energie = ${packVoltage.toFixed(1)} V x ${requestedCapacity.toFixed(1)} Ah = ${Math.round(requestedEnergy)} Wh`,
        `Kontrolle = ${requiredCells} x ${voltage} V x ${capacity} Ah = ${Math.round(theoreticalEnergy)} Wh`,
        ...targetRequirementLines(series, parallel, packVoltage, requestedCapacity, capacity),
        ...visualLines,
        ...maxElectricalConfigurationLines(availableCells, voltage, capacity, series, parallel, currentResult),
    ];
    if (!currentResult) {
        el('calcVoltage').textContent = `${packVoltage.toFixed(1)} V`;
        el('calcCapacity').textContent = `${requestedCapacity.toFixed(1)} Ah`;
        el('calcEnergy').textContent = `${Math.round(requestedEnergy)} Wh`;
        el('calcCells').textContent = `${requiredCells} Zellen (${series}s${parallel}p)`;
        fitEl.textContent = 'Noch kein Optimierungsergebnis.';
        updateCalculationWindow([...formulaLines, 'Noch kein Bauraum-/Rasterergebnis vorhanden.']);
        return;
    }
    if (currentResult.source === 'grid' && currentResult.layout) {
        const gridCells = currentResult.layout.capacity;
        el('calcVoltage').textContent = `${packVoltage.toFixed(1)} V`;
        el('calcCapacity').textContent = `${requestedCapacity.toFixed(1)} Ah`;
        el('calcEnergy').textContent = `${Math.round(requestedEnergy)} Wh`;
        el('calcCells').textContent = `${requiredCells} Zellen (${series}s${parallel}p)`;
        formulaLines.push(`Verfuegbar im Raster = ${gridCells} Zellplaetze`);
        formulaLines.push(`Reserve = ${gridCells} - ${requiredCells} = ${gridCells - requiredCells} Zellplaetze`);
        if (gridCells === requiredCells) {
            fitEl.classList.add('ok');
            fitEl.textContent =
                `Zellraster passt exakt: ${currentResult.layout.cols} x ${currentResult.layout.rows} x ${currentResult.layout.layers} ergibt ${gridCells} Zellen und entspricht ${series}s${parallel}p.`;
        }
        else if (gridCells > requiredCells) {
            fitEl.classList.add('warn');
            fitEl.textContent =
                `Zellraster und Elektrik unterscheiden sich: Das Raster ergibt ${gridCells} Zellplaetze, ${series}s${parallel}p benoetigt ${requiredCells} Zellen. Passe Serien-/Parallelzellen oder das Raster an, wenn beides identisch sein soll.`;
        }
        else {
            fitEl.classList.add('warn');
            fitEl.textContent =
                `Zellraster zu klein: Das Raster ergibt ${gridCells} Zellplaetze, ${series}s${parallel}p benoetigt ${requiredCells} Zellen.`;
        }
        updateCalculationWindow(formulaLines);
        return;
    }
    el('calcVoltage').textContent = `${packVoltage.toFixed(1)} V`;
    el('calcCapacity').textContent = `${requestedCapacity.toFixed(1)} Ah`;
    el('calcEnergy').textContent = `${Math.round(requestedEnergy)} Wh`;
    el('calcCells').textContent = `${requiredCells} Zellen (${series}s${parallel}p)`;
    formulaLines.push(`Verfuegbar im Bauraum = ${availableCells} Zellplaetze`);
    formulaLines.push(`Reserve = ${availableCells} - ${requiredCells} = ${availableCells - requiredCells} Zellplaetze`);
    const layoutCfg = getTargetGridConfig();
    if (layoutCfg && layoutCfg.capacity < requiredCells) {
        fitEl.classList.add('warn');
        fitEl.textContent =
            `Pack-Aufteilung zu klein: ${layoutCfg.cols} x ${layoutCfg.rows} x ${layoutCfg.layers} bietet ${layoutCfg.capacity} Plaetze, benoetigt werden ${requiredCells} Zellen.`;
        updateCalculationWindow(formulaLines);
        return;
    }
    if (availableCells >= requiredCells) {
        const reserveCells = availableCells - requiredCells;
        const usedLayers = layoutCfg ? Math.ceil(requiredCells / (layoutCfg.cols * layoutCfg.rows)) : 0;
        fitEl.classList.add('ok');
        fitEl.textContent = layoutCfg
            ? `Ziel-Pack: ${series}s${parallel}p nutzt ${requiredCells} Zellen. Die Aufteilung ${layoutCfg.cols} x ${layoutCfg.rows} dient als maximale Ebene; benoetigt werden ${usedLayers} von ${layoutCfg.layers} Ebenen.`
            : `Ziel-Pack: ${series}s${parallel}p nutzt ${requiredCells} Zellen. Im Maximal-Bauraum bleiben ${reserveCells} Zellplaetze Reserve; die 3D-Ansicht zeigt den verkleinerten Ziel-Bauraum.`;
        void reserveCells;
    }
    else {
        fitEl.classList.add('warn');
        fitEl.textContent =
            `Zu wenig Platz: ${series}s${parallel}p braucht ${requiredCells} Zellen, verfuegbar sind ${availableCells}. Es fehlen ${requiredCells - availableCells} Zellen.`;
    }
    updateCalculationWindow(formulaLines);
}
function createExportPanel() {
    const card = document.createElement('div');
    card.className = 'card task-card';
    card.innerHTML = `
    <div class="card-title">Export</div>
    <div class="export-actions">
      <button type="button" class="secondary" id="exportDatasheetBtn">Kunden-Datenblatt exportieren</button>
    </div>
  `;
    return card;
}
function downloadBlob(filename, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}
function getElectricalSummaryData() {
    const cellVoltage = val('packVoltage') || 0;
    const cellCapacityAh = val('packCapacity') || 0;
    const series = Math.max(1, Math.floor(val('seriesCells') || 1));
    const parallel = Math.max(1, Math.floor(val('parallelCells') || 1));
    const packVoltage = cellVoltage * series;
    const packCapacityAh = cellCapacityAh * parallel;
    return {
        cellVoltage,
        cellCapacityAh,
        series,
        parallel,
        requiredCells: series * parallel,
        packVoltage,
        packCapacityAh,
        packEnergyWh: packVoltage * packCapacityAh,
    };
}
function getTargetGridConfig() {
    const shapeType = selVal('shapeType');
    if (definitionMode === 'grid' && ['l_shape', 'u_shape', 't_shape', 'triangle', 'trapeze'].includes(shapeType)) {
        const layers = Math.max(0, Math.floor(val('layoutLayers') || 0));
        if (layers < 1)
            return null;
        let cols = 1;
        let rows = 1;
        let perLayer = 1;
        if (shapeType === 'l_shape') {
            const vLen = Math.max(1, Math.floor(val('dim_l') || 1));
            const vWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const hLen = Math.max(vWidth, Math.floor(val('dim_cut_l') || vWidth));
            const hWidth = Math.max(1, Math.floor(val('dim_cut_w') || 1));
            cols = Math.max(vWidth, hLen);
            rows = Math.max(vLen, hWidth);
            perLayer = vLen * vWidth + hLen * hWidth - vWidth * hWidth;
        }
        else if (shapeType === 'u_shape') {
            const legLen = Math.max(1, Math.floor(val('dim_l') || 1));
            const legWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const bridgeLen = Math.max(legWidth * 2 + 1, Math.floor(val('dim_cut_l') || legWidth * 2 + 1));
            const bridgeWidth = Math.max(1, Math.floor(val('dim_cut_w') || 1));
            cols = bridgeLen;
            rows = Math.max(legLen, bridgeWidth);
            perLayer = legLen * legWidth * 2 + bridgeLen * bridgeWidth - legWidth * bridgeWidth * 2;
        }
        else if (shapeType === 't_shape') {
            const stemLen = Math.max(1, Math.floor(val('dim_l') || 1));
            const stemWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const barLen = Math.max(stemWidth, Math.floor(val('dim_stem_w') || stemWidth));
            const barWidth = Math.max(1, Math.floor(val('dim_bar_h') || 1));
            cols = Math.max(stemWidth, barLen);
            rows = stemLen + barWidth;
            perLayer = stemLen * stemWidth + barLen * barWidth;
        }
        else {
            if (shapeType === 'triangle') {
                cols = Math.max(1, Math.floor(val('dim_l') || 1));
                rows = Math.max(1, Math.floor(val('dim_w') || 1));
                perLayer = 0;
                for (let row = 0; row < rows; row++) {
                    for (let col = 0; col < cols; col++) {
                        if ((col + 0.5) / cols + (row + 0.5) / rows <= 1)
                            perLayer++;
                    }
                }
            }
            else {
                cols = Math.max(1, Math.floor(val('dim_l') || 1));
                rows = Math.max(1, Math.floor(val('dim_w') || 1));
                const topCols = Math.max(1, Math.min(cols, Math.floor(val('dim_top_mm') || cols)));
                perLayer = 0;
                for (let row = 0; row < rows; row++) {
                    const t = rows === 1 ? 0 : row / (rows - 1);
                    const rowWidth = cols + (topCols - cols) * t;
                    const start = (cols - rowWidth) / 2;
                    const end = start + rowWidth;
                    for (let col = 0; col < cols; col++) {
                        const cx = col + 0.5;
                        if (cx >= start && cx <= end)
                            perLayer++;
                    }
                }
            }
        }
        return { cols, rows, layers, capacity: perLayer * layers };
    }
    const cols = Math.max(0, Math.floor(val('layoutCols') || 0));
    const rows = Math.max(0, Math.floor(val('layoutRows') || 0));
    const layers = Math.max(0, Math.floor(val('layoutLayers') || 0));
    if (cols < 1 || rows < 1 || layers < 1)
        return null;
    return { cols, rows, layers, capacity: cols * rows * layers };
}
function shapeFromGridConfig(cell, cfg) {
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    const cellX = cell.type === 'round' ? cell.diam : cell.width;
    const cellZ = cell.type === 'round' ? cell.diam : cell.depth;
    const stepX = cellX + gap;
    const stepZ = cellZ + gap;
    const rawType = document.getElementById('shapeType')?.value;
    const type = rawType ?? 'rectangle';
    const spanX = (count) => count * cellX + Math.max(0, count - 1) * gap;
    const spanZ = (count) => count * cellZ + Math.max(0, count - 1) * gap;
    if (type === 'l_shape') {
        const vLenCells = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
        const vWidthCells = Math.max(1, Math.floor(val('dim_w') || Math.max(1, Math.floor(cfg.cols * 0.35))));
        const hLenCells = Math.max(vWidthCells, Math.floor(val('dim_cut_l') || cfg.cols));
        const hWidthCells = Math.max(1, Math.floor(val('dim_cut_w') || Math.max(1, Math.floor(cfg.rows * 0.35))));
        const l = hLenCells * cellX + Math.max(0, hLenCells - 1) * gap + BOUNDARY_MARGIN * 2;
        const w = vLenCells * cellZ + Math.max(0, vLenCells - 1) * gap + BOUNDARY_MARGIN * 2;
        const vWidth = vWidthCells * cellX + Math.max(0, vWidthCells - 1) * gap;
        const hWidth = hWidthCells * cellZ + Math.max(0, hWidthCells - 1) * gap;
        return normalizeShapeParams({
            type,
            l,
            w,
            h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
            cut_l: Math.max(1, l - BOUNDARY_MARGIN * 2 - vWidth),
            cut_w: Math.max(1, w - BOUNDARY_MARGIN * 2 - hWidth),
            stem_w: Math.max(1, l * 0.35),
            bar_h: Math.max(1, w * 0.35),
            top_mm: Math.max(1, l * 0.65),
        });
    }
    if (type === 'u_shape') {
        const legLenCells = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
        const legWidthCells = Math.max(1, Math.floor(val('dim_w') || Math.max(1, Math.floor(cfg.cols * 0.25))));
        const bridgeLenCells = Math.max(legWidthCells * 2 + 1, Math.floor(val('dim_cut_l') || cfg.cols));
        const bridgeWidthCells = Math.max(1, Math.floor(val('dim_cut_w') || Math.max(1, Math.floor(cfg.rows * 0.25))));
        const l = spanX(bridgeLenCells) + BOUNDARY_MARGIN * 2;
        const w = spanZ(Math.max(legLenCells, bridgeWidthCells)) + BOUNDARY_MARGIN * 2;
        return normalizeShapeParams({
            type,
            l,
            w,
            h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
            cut_l: Math.max(cellX, spanX(legWidthCells)),
            cut_w: Math.max(cellZ, spanZ(bridgeWidthCells)),
            stem_w: Math.max(1, l * 0.35),
            bar_h: Math.max(1, w * 0.35),
            top_mm: Math.max(1, l * 0.65),
        });
    }
    if (type === 't_shape') {
        const stemLenCells = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
        const stemWidthCells = Math.max(1, Math.floor(val('dim_w') || Math.max(1, Math.floor(cfg.cols * 0.3))));
        const barLenCells = Math.max(stemWidthCells, Math.floor(val('dim_stem_w') || cfg.cols));
        const barWidthCells = Math.max(1, Math.floor(val('dim_bar_h') || Math.max(1, Math.floor(cfg.rows * 0.25))));
        const l = spanX(barLenCells) + BOUNDARY_MARGIN * 2;
        const w = spanZ(stemLenCells + barWidthCells) + BOUNDARY_MARGIN * 2;
        return normalizeShapeParams({
            type,
            l,
            w,
            h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
            cut_l: Math.max(1, l * 0.35),
            cut_w: Math.max(1, w * 0.35),
            stem_w: Math.max(cellX, spanX(stemWidthCells)),
            bar_h: Math.max(cellZ, spanZ(barWidthCells) + BOUNDARY_MARGIN),
            top_mm: Math.max(1, l * 0.65),
        });
    }
    if (type === 'triangle') {
        const triCols = Math.max(1, Math.floor(val('dim_l') || cfg.cols));
        const triRows = Math.max(1, Math.floor(val('dim_w') || cfg.rows));
        return normalizeShapeParams({
            type,
            l: spanX(triCols) + BOUNDARY_MARGIN * 2,
            w: spanZ(triRows) + BOUNDARY_MARGIN * 2,
            h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
            cut_l: Math.max(1, spanX(Math.max(1, Math.floor(triCols * 0.35)))),
            cut_w: Math.max(1, spanZ(Math.max(1, Math.floor(triRows * 0.35)))),
            stem_w: Math.max(1, spanX(Math.max(1, Math.floor(triCols * 0.35)))),
            bar_h: Math.max(1, spanZ(Math.max(1, Math.floor(triRows * 0.35)))),
            top_mm: Math.max(1, spanX(Math.max(1, Math.floor(triCols * 0.65)))),
        });
    }
    if (type === 'trapeze') {
        const bottomCols = Math.max(1, Math.floor(val('dim_l') || cfg.cols));
        const rows = Math.max(1, Math.floor(val('dim_w') || cfg.rows));
        const topCols = Math.max(1, Math.min(bottomCols, Math.floor(val('dim_top_mm') || Math.max(1, Math.floor(bottomCols * 0.65)))));
        return normalizeShapeParams({
            type,
            l: spanX(bottomCols) + BOUNDARY_MARGIN * 2,
            w: spanZ(rows) + BOUNDARY_MARGIN * 2,
            h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
            cut_l: Math.max(1, spanX(Math.max(1, Math.floor(bottomCols * 0.35)))),
            cut_w: Math.max(1, spanZ(Math.max(1, Math.floor(rows * 0.35)))),
            stem_w: Math.max(1, spanX(Math.max(1, Math.floor(bottomCols * 0.35)))),
            bar_h: Math.max(1, spanZ(Math.max(1, Math.floor(rows * 0.35)))),
            top_mm: spanX(topCols) + BOUNDARY_MARGIN * 2,
        });
    }
    const l = cfg.cols * cellX + Math.max(0, cfg.cols - 1) * gap + BOUNDARY_MARGIN * 2;
    const w = cfg.rows * cellZ + Math.max(0, cfg.rows - 1) * gap + BOUNDARY_MARGIN * 2;
    const gridCount = (id, fallback, max) => {
        const raw = Math.floor(val(id) || 0);
        if (raw >= 1 && raw <= max)
            return raw;
        return clamp(fallback, 1, Math.max(1, max));
    };
    const cutCols = gridCount('dim_cut_l', Math.max(1, Math.floor(cfg.cols * 0.3)), Math.max(1, cfg.cols - 1));
    const cutRows = gridCount('dim_cut_w', Math.max(1, Math.floor(cfg.rows * 0.4)), Math.max(1, cfg.rows - 1));
    const stemCols = gridCount('dim_stem_w', Math.max(1, Math.floor(cfg.cols * 0.35)), cfg.cols);
    const stemRows = gridCount('dim_bar_h', Math.max(1, Math.floor(cfg.rows * 0.55)), cfg.rows);
    const topCols = gridCount('dim_top_mm', Math.max(1, Math.floor(cfg.cols * 0.65)), cfg.cols);
    const cut_l = Math.max(cellX, cutCols * stepX - gap);
    const cut_w = Math.max(cellZ, cutRows * stepZ - gap);
    const stem_w = Math.max(cellX, stemCols * stepX - gap);
    const stemLength = Math.max(cellZ, stemRows * stepZ - gap);
    return normalizeShapeParams({
        type,
        l,
        w,
        h: cfg.layers * cell.height + Math.max(0, cfg.layers - 1) * LAYER_GAP,
        cut_l,
        cut_w,
        stem_w,
        bar_h: Math.max(cellZ, w - stemLength),
        top_mm: Math.max(cellX, topCols * stepX - gap),
    });
}
function buildGridModeResult(cell, cfg, gridStyle) {
    const sp = shapeFromGridConfig(cell, cfg);
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    const cellX = cell.type === 'round' ? cell.diam : cell.width;
    const cellZ = cell.type === 'round' ? cell.diam : cell.depth;
    const stepX = cellX + gap;
    const stepZ = cellZ + gap;
    const stepY = cell.height + LAYER_GAP;
    const positions = [];
    const shapeType = selVal('shapeType');
    const isOccupied = (col, row) => {
        if (shapeType === 'l_shape') {
            const vLen = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
            const vWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const hLen = Math.max(vWidth, Math.floor(val('dim_cut_l') || cfg.cols));
            const hWidth = Math.max(1, Math.floor(val('dim_cut_w') || 1));
            const mirror = document.getElementById('shapeMirrorSelect')?.value ?? 'right';
            const inVertical = mirror === 'left'
                ? col >= hLen - vWidth && row < vLen
                : col < vWidth && row < vLen;
            const inHorizontal = col < hLen && row < hWidth;
            return inVertical || inHorizontal;
        }
        if (shapeType === 'u_shape') {
            const legLen = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
            const legWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const bridgeLen = Math.max(legWidth * 2 + 1, Math.floor(val('dim_cut_l') || cfg.cols));
            const bridgeWidth = Math.max(1, Math.floor(val('dim_cut_w') || 1));
            const inLeftLeg = col < legWidth && row < legLen;
            const inRightLeg = col >= bridgeLen - legWidth && row < legLen;
            const inBridge = col < bridgeLen && row < bridgeWidth;
            return inLeftLeg || inRightLeg || inBridge;
        }
        if (shapeType === 't_shape') {
            const stemLen = Math.max(1, Math.floor(val('dim_l') || cfg.rows));
            const stemWidth = Math.max(1, Math.floor(val('dim_w') || 1));
            const barLen = Math.max(stemWidth, Math.floor(val('dim_stem_w') || cfg.cols));
            const barWidth = Math.max(1, Math.floor(val('dim_bar_h') || 1));
            const stemStart = Math.floor((barLen - stemWidth) / 2);
            const inBar = col < barLen && row < barWidth;
            const inStem = col >= stemStart && col < stemStart + stemWidth && row >= barWidth && row < barWidth + stemLen;
            return inBar || inStem;
        }
        if (shapeType === 'triangle') {
            const triCols = Math.max(1, Math.floor(val('dim_l') || cfg.cols));
            const triRows = Math.max(1, Math.floor(val('dim_w') || cfg.rows));
            if (row >= triRows || col >= triCols)
                return false;
            const centerX = col + 0.5;
            const centerY = row + 0.5;
            return centerX / triCols + centerY / triRows <= 1;
        }
        if (shapeType === 'trapeze') {
            const bottomCols = Math.max(1, Math.floor(val('dim_l') || cfg.cols));
            const rows = Math.max(1, Math.floor(val('dim_w') || cfg.rows));
            const topCols = Math.max(1, Math.min(bottomCols, Math.floor(val('dim_top_mm') || bottomCols)));
            if (row >= rows || col >= bottomCols)
                return false;
            const t = rows === 1 ? 0 : row / (rows - 1);
            const rowWidth = bottomCols + (topCols - bottomCols) * t;
            const start = (bottomCols - rowWidth) / 2;
            const end = start + rowWidth;
            const centerX = col + 0.5;
            return centerX >= start && centerX <= end;
        }
        return true;
    };
    for (let layer = 0; layer < cfg.layers; layer++) {
        const y = cell.height / 2 + layer * stepY;
        for (let row = 0; row < cfg.rows; row++) {
            const z = BOUNDARY_MARGIN + cellZ / 2 + row * stepZ;
            for (let col = 0; col < cfg.cols; col++) {
                if (!isOccupied(col, row))
                    continue;
                const x = BOUNDARY_MARGIN + cellX / 2 + col * stepX;
                positions.push({ x, y, z });
            }
        }
    }
    return {
        total: positions.length,
        extrusionDir: 'z',
        gridStyle,
        cellRotation: 0,
        positions,
        polygon: getShapePolygon(sp),
        sp,
        cell: { ...cell },
        gridOffset: { ox: 0, oy: 0, oz: 0 },
        source: 'grid',
        layout: { ...cfg },
    };
}
function targetGridLayout(result, target) {
    const cfg = getTargetGridConfig();
    if (!cfg)
        return null;
    const usedLayers = Math.max(1, Math.ceil(target / (cfg.cols * cfg.rows)));
    const cellsLastLayer = target - (usedLayers - 1) * cfg.cols * cfg.rows;
    const usedRowsLastLayer = cellsLastLayer > 0 ? Math.ceil(cellsLastLayer / cfg.cols) : cfg.rows;
    const usedRows = usedLayers === 1 ? usedRowsLastLayer : cfg.rows;
    const usedColsLastRow = cellsLastLayer > 0 ? ((cellsLastLayer - 1) % cfg.cols) + 1 : cfg.cols;
    const usedCols = target <= cfg.cols ? usedColsLastRow : cfg.cols;
    const gap = result.cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    const margin = BOUNDARY_MARGIN;
    const cell = result.cell;
    const cellX = cell.type === 'round' ? cell.diam : cell.width;
    const cellZ = cell.type === 'round' ? cell.diam : cell.depth;
    const stepX = cellX + gap;
    const stepZ = cellZ + gap;
    const stepY = cell.height + LAYER_GAP;
    const sp = shapeFromGridConfig(cell, { cols: usedCols, rows: usedRows, layers: usedLayers });
    const positions = [];
    const maxCells = Math.min(target, cfg.capacity);
    for (let layer = 0; layer < usedLayers; layer++) {
        const y = cell.height / 2 + layer * stepY;
        for (let row = 0; row < cfg.rows; row++) {
            const z = margin + cellZ / 2 + row * stepZ;
            for (let col = 0; col < cfg.cols; col++) {
                if (positions.length >= maxCells)
                    break;
                const x = margin + cellX / 2 + col * stepX;
                positions.push({ x, y, z });
            }
        }
    }
    return {
        sp,
        positions,
        offset: { ox: 0, oy: 0, oz: 0 },
        capacity: cfg.capacity,
    };
}
function createCompactElectricalLayout(result, target) {
    if (result.extrusionDir !== 'z')
        return null;
    const electrical = getElectricalSummaryData();
    const series = Math.max(1, electrical.series);
    const parallel = Math.max(1, electrical.parallel);
    const cell = result.cell;
    const gap = cell.type === 'round' ? CELL_GAP_ROUND : CELL_GAP_PRISM;
    const cross = getCrossDimensions(cell, result.cellRotation);
    const cellX = cross.width;
    const cellZ = cross.depth;
    const stepX = cellX + gap;
    const stepZ = result.gridStyle === 'honeycomb' && cell.type === 'round'
        ? stepX * (Math.sqrt(3) / 2)
        : cellZ + gap;
    const groupsPerRow = clamp(Math.round(Math.sqrt(target) / parallel), 1, series);
    const cols = Math.max(parallel, parallel * groupsPerRow);
    const rows = Math.max(1, Math.ceil(target / cols));
    const honeycombOffset = result.gridStyle === 'honeycomb' && cell.type === 'round' && rows > 1 ? stepX / 2 : 0;
    const margin = BOUNDARY_MARGIN;
    const positions = [];
    for (let i = 0; i < target; i++) {
        const row = Math.floor(i / cols);
        const col = i % cols;
        const rowOffset = result.gridStyle === 'honeycomb' && cell.type === 'round' && row % 2 === 1 ? stepX / 2 : 0;
        positions.push({
            x: margin + cellX / 2 + col * stepX + rowOffset,
            y: cell.height / 2,
            z: margin + cellZ / 2 + row * stepZ,
        });
    }
    const sp = normalizeShapeParams({
        type: 'rectangle',
        l: cellX + Math.max(0, cols - 1) * stepX + honeycombOffset + margin * 2,
        w: cellZ + Math.max(0, rows - 1) * stepZ + margin * 2,
        h: cell.height,
        cut_l: 1,
        cut_w: 1,
        stem_w: 1,
        bar_h: 1,
        top_mm: 1,
    });
    return {
        sp,
        positions,
        offset: { ox: 0, oy: 0, oz: 0 },
    };
}
function scaleShapeParams(sp, scale) {
    return normalizeShapeParams({
        type: sp.type,
        l: sp.l * scale,
        w: sp.w * scale,
        h: sp.h * scale,
        cut_l: sp.cut_l * scale,
        cut_w: sp.cut_w * scale,
        stem_w: sp.stem_w * scale,
        bar_h: sp.bar_h * scale,
        top_mm: sp.top_mm * scale,
    });
}
function optimizeLayoutForShape(sp, result, sweep = 6) {
    const periods = getOffsetPeriods(result.cell, result.extrusionDir, result.gridStyle, result.cellRotation);
    let bestPositions = [];
    let bestOffset = { ox: 0, oy: 0, oz: 0 };
    for (let si = 0; si < sweep; si++) {
        for (let sj = 0; sj < sweep; sj++) {
            for (let sk = 0; sk < sweep; sk++) {
                const off = {
                    ox: (si / sweep) * periods.ox,
                    oy: (sj / sweep) * periods.oy,
                    oz: (sk / sweep) * periods.oz,
                };
                const positions = pack3D(sp, result.cell, result.extrusionDir, result.gridStyle, off, result.cellRotation);
                if (positions.length > bestPositions.length) {
                    bestPositions = positions;
                    bestOffset = off;
                }
            }
        }
    }
    return { positions: bestPositions, offset: bestOffset };
}
function createScaledElectricalLayout(result, target) {
    const sweep = result.sp.type === 'rectangle' ? 5 : 6;
    let lo = 0.1;
    let hi = 1;
    let best = {
        sp: result.sp,
        positions: result.positions,
        offset: result.gridOffset,
    };
    for (let i = 0; i < 16; i++) {
        const mid = (lo + hi) / 2;
        const sp = scaleShapeParams(result.sp, mid);
        const layout = optimizeLayoutForShape(sp, result, sweep);
        if (layout.positions.length >= target) {
            best = { sp, ...layout };
            hi = mid;
        }
        else {
            lo = mid;
        }
    }
    if (best.positions.length > target) {
        best.positions = selectElectricalPositions({
            ...result,
            sp: best.sp,
            positions: best.positions,
            total: best.positions.length,
            gridOffset: best.offset,
        }, target);
    }
    return best;
}
function layerCoord(result, p) {
    if (result.extrusionDir === 'z')
        return p.y;
    if (result.extrusionDir === 'x')
        return p.x;
    return p.z;
}
function groupByRoundedCoord(points, coord) {
    const groups = new Map();
    points.forEach(p => {
        const key = Math.round(coord(p) * 10) / 10;
        if (!groups.has(key))
            groups.set(key, []);
        groups.get(key).push(p);
    });
    return [...groups.entries()]
        .sort((a, b) => a[0] - b[0])
        .map(([, group]) => group);
}
function pickEvenly(points, count) {
    if (count <= 0)
        return [];
    if (count >= points.length)
        return [...points];
    if (count === 1)
        return [points[Math.floor(points.length / 2)]];
    const picked = [];
    const used = new Set();
    for (let i = 0; i < count; i++) {
        let idx = Math.round((i * (points.length - 1)) / (count - 1));
        while (used.has(idx) && idx < points.length - 1)
            idx++;
        while (used.has(idx) && idx > 0)
            idx--;
        used.add(idx);
        picked.push(points[idx]);
    }
    return picked;
}
function pickShapeAwareLayerPositions(points, target) {
    if (target >= points.length)
        return [...points];
    const rows = groupByRoundedCoord(points, p => p.z)
        .map(row => row.sort((a, b) => a.x - b.x));
    const total = points.length;
    const allocations = rows.map((row, idx) => {
        const exact = (target * row.length) / total;
        const base = Math.min(row.length, Math.floor(exact));
        return { idx, row, count: base, remainder: exact - base };
    });
    let allocated = allocations.reduce((sum, a) => sum + a.count, 0);
    allocations
        .filter(a => a.count < a.row.length)
        .sort((a, b) => b.remainder - a.remainder || b.row.length - a.row.length)
        .forEach(a => {
        if (allocated >= target)
            return;
        a.count++;
        allocated++;
    });
    while (allocated < target) {
        const next = allocations.find(a => a.count < a.row.length);
        if (!next)
            break;
        next.count++;
        allocated++;
    }
    while (allocated > target) {
        const next = [...allocations].reverse().find(a => a.count > 0);
        if (!next)
            break;
        next.count--;
        allocated--;
    }
    return allocations
        .sort((a, b) => a.idx - b.idx)
        .flatMap(a => pickEvenly(a.row, a.count));
}
function selectElectricalPositions(result, target) {
    if (target >= result.positions.length)
        return result.positions;
    const layers = groupByRoundedCoord(result.positions, p => layerCoord(result, p));
    const selected = [];
    let remaining = target;
    for (const layer of layers) {
        if (remaining <= 0)
            break;
        const orderedLayer = layer.sort((a, b) => a.z - b.z || a.x - b.x || a.y - b.y);
        if (remaining >= orderedLayer.length) {
            selected.push(...orderedLayer);
            remaining -= orderedLayer.length;
        }
        else {
            selected.push(...pickShapeAwareLayerPositions(orderedLayer, remaining));
            remaining = 0;
        }
    }
    return selected.sort((a, b) => layerCoord(result, a) - layerCoord(result, b)
        || a.z - b.z
        || a.x - b.x
        || a.y - b.y);
}
function getDisplayResult(result) {
    if (packViewMode !== 'electrical')
        return result;
    const { requiredCells } = getElectricalSummaryData();
    const target = Math.min(requiredCells, result.positions.length);
    if (target >= result.positions.length)
        return result;
    const manualLayout = targetGridLayout(result, target);
    const compactLayout = createCompactElectricalLayout(result, target);
    const displayLayout = manualLayout ?? compactLayout ?? createScaledElectricalLayout(result, target);
    return {
        ...result,
        sp: displayLayout.sp,
        polygon: getShapePolygon(displayLayout.sp),
        positions: displayLayout.positions,
        total: displayLayout.positions.length,
        gridOffset: displayLayout.offset,
    };
}
function requireResult() {
    if (currentResult)
        return currentResult;
    window.alert('Bitte zuerst eine Optimierung starten.');
    return null;
}
function captureCanvasJpegDataUrl() {
    renderer.render(scene, camera);
    return canvas.toDataURL('image/jpeg', 0.9);
}
function dataUrlToBytes(dataUrl) {
    const base64 = dataUrl.split(',')[1] ?? '';
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++)
        bytes[i] = binary.charCodeAt(i);
    return bytes;
}
function pdfEscape(text) {
    return String(text)
        .replace(/\\/g, '\\\\')
        .replace(/\(/g, '\\(')
        .replace(/\)/g, '\\)')
        .replace(/[^\x20-\x7e]/g, '?');
}
function wrapPdfLine(text, maxChars) {
    const words = text.split(/\s+/);
    const lines = [];
    let line = '';
    words.forEach(word => {
        const next = line ? `${line} ${word}` : word;
        if (next.length > maxChars && line) {
            lines.push(line);
            line = word;
        }
        else {
            line = next;
        }
    });
    if (line)
        lines.push(line);
    return lines;
}
function pdfTextLine(text, x, y, size = 10, bold = false, color = '0.08 0.13 0.18') {
    return `${color} rg BT /${bold ? 'F2' : 'F1'} ${size} Tf ${x} ${y} Td (${pdfEscape(text)}) Tj ET\n`;
}
function pdfRect(x, y, w, h, stroke = '0.80 0.85 0.90', fill) {
    const fillCmd = fill ? `${fill} rg ${x} ${y} ${w} ${h} re f\n` : '';
    return `${fillCmd}${stroke} RG ${x} ${y} ${w} ${h} re S\n`;
}
function pdfLine(x1, y1, x2, y2, color = '0.00 0.47 0.80') {
    return `${color} RG 1 w ${x1} ${y1} m ${x2} ${y2} l S\n`;
}
function pdfImageFit(imageWidth, imageHeight, x, y, w, h) {
    const scale = Math.min(w / imageWidth, h / imageHeight);
    const drawW = imageWidth * scale;
    const drawH = imageHeight * scale;
    const drawX = x + (w - drawW) / 2;
    const drawY = y + (h - drawH) / 2;
    return `q ${drawW.toFixed(2)} 0 0 ${drawH.toFixed(2)} ${drawX.toFixed(2)} ${drawY.toFixed(2)} cm /Im1 Do Q\n`;
}
function pdfKpiBox(label, value, x, y, w) {
    return [
        pdfRect(x, y, w, 56, '0.78 0.84 0.90', '0.95 0.98 1.00'),
        pdfTextLine(label, x + 10, y + 36, 8, false),
        pdfTextLine(value, x + 10, y + 14, 16, true),
    ].join('');
}
function pdfSectionTitle(title, x, y) {
    return [
        pdfTextLine(title, x, y, 12, true),
        pdfLine(x, y - 6, x + 240, y - 6, '0.00 0.47 0.80'),
    ].join('');
}
function pdfTable(rows, x, y, w, rowH = 18) {
    let out = pdfRect(x, y - rows.length * rowH - 8, w, rows.length * rowH + 8, '0.80 0.85 0.90', '0.98 0.99 1.00');
    rows.forEach(([label, value], idx) => {
        const rowY = y - 18 - idx * rowH;
        out += pdfTextLine(label, x + 10, rowY, 8);
        out += pdfTextLine(value, x + w * 0.48, rowY, 9, true);
        if (idx < rows.length - 1)
            out += pdfLine(x + 8, rowY - 7, x + w - 8, rowY - 7, '0.88 0.91 0.94');
    });
    return out;
}
function splitCalculationSections(formula) {
    const raw = formula.split('\n').map(line => line.trim()).filter(Boolean);
    const sections = [];
    let current = null;
    let skippedAddressGroups = 0;
    const start = (title) => {
        current = { title, lines: [] };
        sections.push(current);
    };
    raw.forEach(line => {
        if (/^(Kundeneingabe|Zielwert|Manuelle)/.test(line)) {
            start('Elektrische Auslegung');
            current.lines.push(line);
            return;
        }
        if (line.startsWith('Verschaltungscheck')) {
            start('Pruefung der 3D-Ansicht');
            return;
        }
        if (line.startsWith('Adressierte Verschaltung')) {
            start('Adressierte Verschaltung');
            skippedAddressGroups = 0;
            return;
        }
        if (line.startsWith('Pruefung der Kundeneingabe')) {
            start('Pruefung der Kundeneingabe');
            current.lines.push(line);
            return;
        }
        if (!current)
            start('Berechnung');
        const active = current;
        if (active.title === 'Adressierte Verschaltung' && line.startsWith('Seriengruppe')) {
            const groupNo = Number(line.match(/Seriengruppe\s+(\d+)/)?.[1] ?? 0);
            if (groupNo > 4 && !line.startsWith('Seriengruppe 1') && !line.includes('...')) {
                skippedAddressGroups += 1;
                return;
            }
        }
        active.lines.push(line);
    });
    const addressSection = sections.find(section => section.title === 'Adressierte Verschaltung');
    if (addressSection && skippedAddressGroups > 0) {
        addressSection.lines.push(`Weitere ${skippedAddressGroups} Seriengruppen werden im Modell identisch nach Serienfolge verschaltet.`);
    }
    return sections.filter(section => section.lines.length > 0);
}
function pdfCalcCard(title, lines, x, y, w) {
    const wrapped = lines.flatMap(line => wrapPdfLine(line, 92));
    const lineH = 11;
    const h = 30 + wrapped.length * lineH;
    let out = pdfRect(x, y - h, w, h, '0.80 0.85 0.90', '0.98 0.99 1.00');
    out += pdfTextLine(title, x + 10, y - 18, 10, true, '0.00 0.47 0.80');
    out += pdfLine(x + 10, y - 25, x + w - 10, y - 25, '0.82 0.88 0.94');
    wrapped.forEach((line, idx) => {
        const valueLine = line.includes('=') || line.includes('->') || line.includes(':');
        out += pdfTextLine(line, x + 10, y - 40 - idx * lineH, 7.6, valueLine);
    });
    return { content: out, nextY: y - h - 14 };
}
function buildCustomerPdf(imageBytes, imageWidth, imageHeight, pages) {
    const encoder = new TextEncoder();
    const objects = [];
    const addObject = (parts) => {
        objects.push(parts);
        return objects.length;
    };
    const fontRegular = addObject(['<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']);
    const fontBold = addObject(['<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>']);
    const imageObj = addObject([
        `<< /Type /XObject /Subtype /Image /Width ${imageWidth} /Height ${imageHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${imageBytes.length} >>\nstream\n`,
        imageBytes,
        '\nendstream',
    ]);
    const pageIds = [];
    pages.forEach(content => {
        const stream = content;
        const contentObj = addObject([`<< /Length ${encoder.encode(stream).length} >>\nstream\n${stream}endstream`]);
        const pageObj = addObject([
            `<< /Type /Page /Parent 0 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${fontRegular} 0 R /F2 ${fontBold} 0 R >> /XObject << /Im1 ${imageObj} 0 R >> >> /Contents ${contentObj} 0 R >>`,
        ]);
        pageIds.push(pageObj);
    });
    const pagesObj = addObject([`<< /Type /Pages /Kids [${pageIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pageIds.length} >>`]);
    const catalogObj = addObject([`<< /Type /Catalog /Pages ${pagesObj} 0 R >>`]);
    pageIds.forEach(id => {
        objects[id - 1][0] = String(objects[id - 1][0]).replace('/Parent 0 0 R', `/Parent ${pagesObj} 0 R`);
    });
    const parts = [];
    const offsets = [];
    let offset = 0;
    const pushString = (s) => {
        const bytes = encoder.encode(s);
        parts.push(bytes);
        offset += bytes.length;
    };
    const pushBytes = (bytes) => {
        parts.push(bytes);
        offset += bytes.length;
    };
    pushString('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    objects.forEach((obj, i) => {
        offsets[i + 1] = offset;
        pushString(`${i + 1} 0 obj\n`);
        obj.forEach(part => typeof part === 'string' ? pushString(part) : pushBytes(part));
        pushString('\nendobj\n');
    });
    const xrefOffset = offset;
    pushString(`xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`);
    for (let i = 1; i <= objects.length; i++) {
        pushString(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
    }
    pushString(`trailer\n<< /Size ${objects.length + 1} /Root ${catalogObj} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
    return new Blob(parts.map(part => part.slice().buffer), { type: 'application/pdf' });
}
async function exportCustomerDatasheet() {
    const result = requireResult();
    if (!result)
        return;
    const imageDataUrl = captureCanvasJpegDataUrl();
    const imageBytes = dataUrlToBytes(imageDataUrl);
    const imageMeta = await new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve({ width: img.width, height: img.height });
        img.src = imageDataUrl;
    });
    const electrical = getElectricalSummaryData();
    const layerKeys = new Set(result.positions.map(p => result.extrusionDir === 'z' ? Math.round(p.y * 10) / 10 :
        result.extrusionDir === 'x' ? Math.round(p.x * 10) / 10 :
            Math.round(p.z * 10) / 10));
    const layers = layerKeys.size || 1;
    const perLayer = Math.round(result.total / layers);
    const reserve = result.total - electrical.requiredCells;
    const cellName = result.cell.type === 'round'
        ? `Rundzelle Ø ${result.cell.diam} x ${result.cell.height} mm`
        : `Prismatisch ${result.cell.width} x ${result.cell.depth} x ${result.cell.height} mm, Rotation ${ROT_LABELS[result.cellRotation]}`;
    const pdfCellName = result.cell.type === 'round'
        ? `Rundzelle D ${result.cell.diam} x ${result.cell.height} mm`
        : `Prismatisch ${result.cell.width} x ${result.cell.depth} x ${result.cell.height} mm, Rotation ${ROT_LABELS[result.cellRotation]}`;
    const formula = document.getElementById('calcFormula')?.textContent ?? '';
    const displayResult = getDisplayResult(result);
    const stackCount = sortedElectricalStacks(displayResult).length;
    const note = reserve >= 0
        ? `Die Konfiguration passt: ${electrical.requiredCells} von ${result.total} Zellplaetzen werden genutzt; ${reserve} Zellplaetze bleiben frei.`
        : `Die Konfiguration benoetigt ${Math.abs(reserve)} Zellen mehr, als in den Bauraum passen.`;
    const architectureNote = result.cell.type === 'prismatic'
        ? 'Prismatische Zellmodule mit sichtbaren Einzelzellen, oberer Kontakt-/Traglage, Seitenwaenden und Busbars fuer Parallel- und Serienverbinder.'
        : 'Rundzellen-Pack mit Zellhaltern, ebenenweisen Parallelgruppen aus benachbarten Zellen und kurzen Serienbruecken zwischen Nachbargruppen.';
    {
        const pages = [];
        const unusedLegacyFirstPage = [
            pdfRect(32, 782, 531, 34, '0.00 0.47 0.80', '0.00 0.47 0.80'),
            pdfTextLine('BATTERY PACK OPTIMIZER', 44, 802, 14, true),
            pdfTextLine('Kunden-Datenblatt der aktuellen Konfiguration', 44, 788, 8),
            pdfTextLine(`Erstellt: ${new Date().toLocaleString('de-DE')}`, 410, 792, 8),
            pdfRect(286, 612, 270, 166, '0.78 0.84 0.90', '0.96 0.98 1.00'),
            pdfTextLine('3D-Ansicht', 298, 760, 10, true),
            pdfKpiBox('Zellen gesamt', String(result.total), 42, 704, 115),
            pdfKpiBox('Packspannung', `${electrical.packVoltage.toFixed(1)} V`, 167, 704, 115),
            pdfKpiBox('Kapazitaet', `${electrical.packCapacityAh.toFixed(1)} Ah`, 42, 636, 115),
            pdfKpiBox('Energie', `${Math.round(electrical.packEnergyWh)} Wh`, 167, 636, 115),
            pdfSectionTitle('Mechanische Auslegung', 42, 590),
            pdfTable([
                ['Zelltyp', cellName.replace('ÃƒËœ', 'D').replace('Ã˜', 'D')],
                ['Packmasse', `L ${result.sp.l} mm x B ${result.sp.w} mm x H ${result.sp.h} mm`],
                ['Anordnung', `${DIR_LABELS[result.extrusionDir]}, ${GS_LABELS[result.gridStyle]}`],
                ['Raster', `ca. ${perLayer} Zellen pro Ebene x ${layers} Ebenen`],
                ['Verschaltbare Zellen', `${stackCount}, Parallelgruppen innerhalb einer Ebene`],
            ], 42, 570, 240),
            pdfSectionTitle('Elektrische Auslegung', 315, 590),
            pdfTable([
                ['Verschaltung', `${electrical.series}s${electrical.parallel}p`],
                ['Zellspannung', `${electrical.cellVoltage} V`],
                ['Zellkapazitaet', `${electrical.cellCapacityAh} Ah`],
                ['Benoetigte Zellen', String(electrical.requiredCells)],
                ['Reserve', String(reserve)],
            ], 315, 570, 220),
            pdfSectionTitle('Bewertung', 42, 430),
            pdfRect(42, 360, 493, 54, reserve >= 0 ? '0.00 0.62 0.50' : '0.85 0.42 0.00', reserve >= 0 ? '0.91 0.98 0.95' : '1.00 0.95 0.88'),
            ...wrapPdfLine(note, 92).map((line, idx) => pdfTextLine(line, 54, 394 - idx * 14, 9, idx === 0)),
            pdfSectionTitle('Optimierungsparameter', 42, 320),
            pdfTable([
                ['Randabstand', `${BOUNDARY_MARGIN} mm`],
                ['Zell-Gap Rund', `${CELL_GAP_ROUND} mm`],
                ['Zell-Gap Prismatisch', `${CELL_GAP_PRISM} mm`],
                ['Ebenen-Gap', `${LAYER_GAP} mm`],
            ], 42, 300, 240),
            pdfSectionTitle('Hinweis', 315, 320),
            pdfRect(315, 222, 220, 82, '0.80 0.85 0.90', '0.98 0.99 1.00'),
            ...wrapPdfLine('Bei Rundzellen werden Parallelgruppen innerhalb derselben Ebene aus benachbarten Zellen gebildet; Serienbruecken verbinden benachbarte Gruppen.', 42)
                .map((line, idx) => pdfTextLine(line, 327, 282 - idx * 13, 8)),
        ].join('');
        void unusedLegacyFirstPage;
        const firstPage = [
            pdfRect(32, 784, 531, 36, '0.00 0.47 0.80', '0.00 0.47 0.80'),
            pdfTextLine('BATTERY PACK OPTIMIZER', 44, 805, 14, true, '1 1 1'),
            pdfTextLine('Kunden-Datenblatt der aktuellen Konfiguration', 44, 790, 8, false, '1 1 1'),
            pdfTextLine(`Erstellt: ${new Date().toLocaleString('de-DE')}`, 410, 793, 8, false, '1 1 1'),
            pdfSectionTitle('3D-Ansicht der Auslegung', 42, 758),
            pdfRect(42, 474, 493, 264, '0.78 0.84 0.90', '0.96 0.98 1.00'),
            pdfImageFit(imageMeta.width, imageMeta.height, 54, 486, 469, 240),
            pdfKpiBox('Zellen gesamt', String(result.total), 42, 392, 115),
            pdfKpiBox('Packspannung', `${electrical.packVoltage.toFixed(1)} V`, 168, 392, 115),
            pdfKpiBox('Kapazitaet', `${electrical.packCapacityAh.toFixed(1)} Ah`, 294, 392, 115),
            pdfKpiBox('Energie', `${Math.round(electrical.packEnergyWh)} Wh`, 420, 392, 115),
            pdfSectionTitle('Mechanische Auslegung', 42, 356),
            pdfTable([
                ['Zelltyp', pdfCellName],
                ['Packmasse', `L ${result.sp.l} mm x B ${result.sp.w} mm x H ${result.sp.h} mm`],
                ['Anordnung', `${DIR_LABELS[result.extrusionDir]}, ${GS_LABELS[result.gridStyle]}`],
                ['Raster', `ca. ${perLayer} Zellen pro Ebene x ${layers} Ebenen`],
                ['Verschaltbare Zellen', `${stackCount}, Parallelgruppen innerhalb einer Ebene`],
                ['Aufbau', result.cell.type === 'prismatic' ? 'Prismatisches Modulsystem' : 'Rundzellen-Halterstruktur'],
            ], 42, 336, 240),
            pdfSectionTitle('Elektrische Auslegung', 315, 356),
            pdfTable([
                ['Verschaltung', `${electrical.series}s${electrical.parallel}p`],
                ['Zellspannung', `${electrical.cellVoltage} V`],
                ['Zellkapazitaet', `${electrical.cellCapacityAh} Ah`],
                ['Benoetigte Zellen', String(electrical.requiredCells)],
                ['Reserve', String(reserve)],
            ], 315, 336, 220),
            pdfSectionTitle('Bewertung', 42, 194),
            pdfRect(42, 128, 493, 50, reserve >= 0 ? '0.00 0.62 0.50' : '0.85 0.42 0.00', reserve >= 0 ? '0.91 0.98 0.95' : '1.00 0.95 0.88'),
            ...wrapPdfLine(note, 92).map((line, idx) => pdfTextLine(line, 54, 160 - idx * 13, 8, idx === 0)),
            pdfSectionTitle('Optimierungsparameter', 42, 104),
            pdfTable([
                ['Randabstand', `${BOUNDARY_MARGIN} mm`],
                ['Zell-Gap Rund', `${CELL_GAP_ROUND} mm`],
                ['Zell-Gap Prismatisch', `${CELL_GAP_PRISM} mm`],
                ['Ebenen-Gap', `${LAYER_GAP} mm`],
            ], 42, 84, 240, 14),
            pdfSectionTitle('Hinweis', 315, 104),
            pdfRect(315, 34, 220, 54, '0.80 0.85 0.90', '0.98 0.99 1.00'),
            ...wrapPdfLine(architectureNote, 42)
                .map((line, idx) => pdfTextLine(line, 327, 70 - idx * 11, 7)),
            pdfTextLine('Seite 1', 510, 18, 7),
        ].join('');
        pages.push(firstPage);
        const calcSections = splitCalculationSections(formula);
        let pageNo = 2;
        let y = 790;
        let content = pdfTextLine('Rechenanhang', 42, y, 16, true) + pdfLine(42, y - 8, 540, y - 8);
        y -= 34;
        calcSections.forEach(section => {
            const wrappedCount = section.lines.flatMap(line => wrapPdfLine(line, 92)).length;
            const estimatedHeight = 30 + wrappedCount * 11 + 14;
            if (y - estimatedHeight < 42) {
                content += pdfTextLine(`Seite ${pageNo}`, 510, 18, 7);
                pages.push(content);
                pageNo += 1;
                y = 790;
                content = pdfTextLine('Rechenanhang', 42, y, 16, true) + pdfLine(42, y - 8, 540, y - 8);
                y -= 34;
            }
            const card = pdfCalcCard(section.title, section.lines, 42, y, 493);
            content += card.content;
            y = card.nextY;
        });
        content += pdfTextLine(`Seite ${pageNo}`, 510, 18, 7);
        pages.push(content);
        const pdf = buildCustomerPdf(imageBytes, imageMeta.width, imageMeta.height, pages);
        downloadBlob('battery-pack-kundendatenblatt.pdf', pdf);
        return;
    }
    /*
      const reportLines = [
        'Battery Pack Kunden-Datenblatt',
        `Erstellt am ${new Date().toLocaleString('de-DE')}`,
        '',
        'Zusammenfassung',
        `Zellen gesamt: ${result.total}`,
        `Packspannung: ${electrical.packVoltage.toFixed(1)} V`,
        `Kapazitaet: ${electrical.packCapacityAh.toFixed(1)} Ah`,
        `Energie: ${Math.round(electrical.packEnergyWh)} Wh`,
        `Verschaltung: ${electrical.series}s${electrical.parallel}p`,
        '',
        'Mechanische Auslegung',
        `Zelltyp: ${cellName.replace('Ã˜', 'D')}`,
        `Packmasse: Laenge ${result.sp.l} mm | Breite ${result.sp.w} mm | Hoehe ${result.sp.h} mm`,
        `Anordnung: ${DIR_LABELS[result.extrusionDir]}, ${GS_LABELS[result.gridStyle]}`,
        `Raster: ca. ${perLayer} Zellen pro Ebene x ${layers} Ebenen`,
        `Verschaltbare Zellen: ${stackCount}, Parallelgruppen innerhalb einer Ebene`,
        '',
        'Elektrische Auslegung',
        `Zellspannung: ${electrical.cellVoltage} V`,
        `Zellkapazitaet: ${electrical.cellCapacityAh} Ah`,
        `Benoetigte Zellen: ${electrical.requiredCells}`,
        `Reserve: ${reserve}`,
        note,
        '',
        'Optimierungsparameter',
        `Randabstand: ${BOUNDARY_MARGIN} mm`,
        `Zell-Gap Rund: ${CELL_GAP_ROUND} mm`,
        `Zell-Gap Prismatisch: ${CELL_GAP_PRISM} mm`,
        `Ebenen-Gap: ${LAYER_GAP} mm`,
        '',
        'Rechnung',
        ...formula.split('\n'),
      ].flatMap(line => wrapPdfLine(line, 92))
    
      const pages: string[] = []
      let y = 790
      let content = ''
      reportLines.forEach((line, idx) => {
        const isTitle = idx === 0
        const isSection = ['Zusammenfassung', 'Mechanische Auslegung', 'Elektrische Auslegung', 'Optimierungsparameter', 'Rechnung'].includes(line)
        if (y < 45) {
          pages.push(content)
          content = ''
          y = 790
        }
        content += pdfTextLine(line, 42, y, isTitle ? 18 : isSection ? 12 : 9, isTitle || isSection)
        y -= isTitle ? 26 : line === '' ? 10 : 14
      })
      pages.push(content)
    
      const pdf = buildCustomerPdf(imageBytes, imageMeta.width, imageMeta.height, pages)
      downloadBlob('battery-pack-kundendatenblatt.pdf', pdf)
    */
}
/*
  const html = `<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8" />
  <title>Battery Pack Datenblatt</title>
  <style>
    body { margin: 0; background: #eef2f6; color: #1a2430; font-family: Arial, sans-serif; }
    .sheet { max-width: 980px; margin: 24px auto; background: #fff; border: 1px solid #cfd8e3; padding: 32px; }
    header { border-bottom: 2px solid #0077cc; display: flex; justify-content: space-between; gap: 24px; padding-bottom: 16px; }
    h1 { color: #0077cc; font-size: 24px; margin: 0; }
    h2 { color: #0077cc; font-size: 15px; margin: 28px 0 10px; text-transform: uppercase; }
    .muted { color: #64748b; font-size: 12px; }
    .hero { display: grid; grid-template-columns: 1.2fr .8fr; gap: 24px; margin-top: 24px; }
    img { border: 1px solid #cfd8e3; max-width: 100%; }
    table { border-collapse: collapse; width: 100%; }
    td, th { border-bottom: 1px solid #e2e8f0; padding: 8px 6px; text-align: left; }
    th { color: #64748b; font-size: 12px; text-transform: uppercase; }
    .kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-top: 20px; }
    .kpi { background: #f4f8fb; border: 1px solid #cfd8e3; padding: 12px; }
    .kpi span { color: #64748b; display: block; font-size: 12px; }
    .kpi strong { color: #0077cc; display: block; font-size: 20px; margin-top: 4px; }
    .note { background: ${reserve >= 0 ? '#e8f7f2' : '#fff4e8'}; border: 1px solid ${reserve >= 0 ? '#00aa88' : '#d97000'}; padding: 12px; margin-top: 16px; }
    @media print { body { background: #fff; } .sheet { border: 0; margin: 0; } }
  </style>
</head>
<body>
  <main class="sheet">
    <header>
      <div>
        <h1>Battery Pack Datenblatt</h1>
        <div class="muted">Erstellt am ${new Date().toLocaleString('de-DE')}</div>
      </div>
      <div class="muted">Battery Pack Optimizer<br/>3D Zellverteilung</div>
    </header>

    <section class="hero">
      <img src="${image}" alt="3D Ansicht des Battery Packs" />
      <div>
        <h2>Auslegung</h2>
        <table>
          <tr><td>Zelltyp</td><td>${escapeHtml(cellName)}</td></tr>
          <tr><td>Bauraum</td><td>${result.sp.l} x ${result.sp.w} x ${result.sp.h} mm</td></tr>
          <tr><td>Anordnung</td><td>${escapeHtml(DIR_LABELS[result.extrusionDir])}, ${escapeHtml(GS_LABELS[result.gridStyle])}</td></tr>
          <tr><td>Ebenen</td><td>${layers}</td></tr>
          <tr><td>Zellen pro Ebene</td><td>ca. ${perLayer}</td></tr>
        </table>
      </div>
    </section>

    <section class="kpis">
      <div class="kpi"><span>Zellen gesamt</span><strong>${result.total}</strong></div>
      <div class="kpi"><span>Packspannung</span><strong>${electrical.packVoltage.toFixed(1)} V</strong></div>
      <div class="kpi"><span>Kapazität</span><strong>${electrical.packCapacityAh.toFixed(1)} Ah</strong></div>
      <div class="kpi"><span>Energie</span><strong>${Math.round(electrical.packEnergyWh)} Wh</strong></div>
    </section>

    <section>
      <h2>Elektrische Konfiguration</h2>
      <table>
        <tr><th>Parameter</th><th>Wert</th></tr>
        <tr><td>Verschaltung</td><td>${electrical.series}s${electrical.parallel}p</td></tr>
        <tr><td>Zellspannung</td><td>${electrical.cellVoltage} V</td></tr>
        <tr><td>Zellkapazität</td><td>${electrical.cellCapacityAh} Ah</td></tr>
        <tr><td>Benötigte Zellen</td><td>${electrical.requiredCells}</td></tr>
        <tr><td>Reserve im Bauraum</td><td>${reserve}</td></tr>
      </table>
      <div class="note">${reserve >= 0
        ? `Die gewählte elektrische Konfiguration passt in den optimierten Bauraum. ${electrical.requiredCells} von ${result.total} Zellplätzen werden belegt; ${reserve} Zellplätze bleiben frei.`
        : `Die gewählte elektrische Konfiguration benötigt ${Math.abs(reserve)} Zellen mehr, als in den Bauraum passen.`}
      </div>
    </section>

    <section>
      <h2>Optimierungsparameter</h2>
      <table>
        <tr><td>Randabstand</td><td>${BOUNDARY_MARGIN} mm</td></tr>
        <tr><td>Zell-Gap Rund</td><td>${CELL_GAP_ROUND} mm</td></tr>
        <tr><td>Zell-Gap Prismatisch</td><td>${CELL_GAP_PRISM} mm</td></tr>
        <tr><td>Ebenen-Gap</td><td>${LAYER_GAP} mm</td></tr>
      </table>
    </section>
  </main>
</body>
</html>`

  downloadBlob('battery-pack-datenblatt.html', new Blob([html], { type: 'text/html' }))
}
*/
function setupTaskbarLegacy() {
    const header = document.querySelector('header');
    const sidebarInner = document.querySelector('.sidebar-inner');
    const cards = Array.from(document.querySelectorAll('.sidebar-inner > .card'));
    const [shapeCard, cellCard, spacingCard] = cards;
    const runButton = document.getElementById('runBtn');
    if (!header || !sidebarInner || !shapeCard || !cellCard || !spacingCard || !runButton)
        return;
    const taskbar = document.createElement('nav');
    taskbar.className = 'taskbar';
    taskbar.setAttribute('aria-label', 'Pack-Einstellungen');
    shapeCard.classList.add('shape-card');
    cellCard.classList.add('task-card');
    spacingCard.classList.add('task-card');
    const actions = document.createElement('div');
    actions.className = 'taskbar-actions';
    actions.appendChild(runButton);
    taskbar.append(createTaskTab('Bauraum', shapeCard, true), createTaskTab('Zelltyp', cellCard), createTaskTab('Abstände', spacingCard), createTaskTab('Kapazität & Spannung', createCapacityVoltagePanel()), createTaskTab('Export', createExportPanel()), actions);
    taskbar.querySelectorAll('.task-tab').forEach(tab => {
        tab.addEventListener('toggle', () => {
            if (!tab.open)
                return;
            taskbar.querySelectorAll('.task-tab').forEach(other => {
                if (other !== tab)
                    other.open = false;
            });
        });
    });
    header.insertAdjacentElement('afterend', taskbar);
}
// ─────────────────────────────────────────────────────────────────────────────
// UI STATE
// ─────────────────────────────────────────────────────────────────────────────
function onShapeChange() {
    const t = selVal('shapeType');
    const composedShape = t === 'l_shape' || t === 'u_shape' || t === 't_shape' || t === 'triangle' || t === 'trapeze';
    const showShapeDetails = definitionMode === 'space' || composedShape;
    el('shapeDims').style.display = showShapeDetails ? '' : 'none';
    el('extra_cut').style.display = (t === 'l_shape' || t === 'u_shape') ? '' : 'none';
    el('extra_t').style.display = t === 't_shape' ? '' : 'none';
    el('extra_trap').style.display = t === 'trapeze' ? '' : 'none';
    const hintByShape = {
        rectangle: 'Aussenlaenge, Aussenbreite und Hoehe des rechteckigen Bauraums.',
        l_shape: 'Die L-Form wird aus einem vertikalen Stab und einem horizontalen Teil aufgebaut.',
        u_shape: 'Die U-Form wird ueber Schenkellaenge, Schenkelbreite, Gesamtbreite und Rueckenbreite definiert. Die Innenluecke ergibt sich daraus automatisch.',
        t_shape: 'Die T-Form wird aus einem vertikalen Stab und einem horizontalen Querbalken aufgebaut.',
        triangle: 'Rechtwinkliges Dreieck: Laenge und Breite sind die beiden Katheten. Die Zellen je Reihe folgen der schraegen Kante.',
        trapeze: 'Trapez: Untere Laenge, obere Laenge und Tiefe definieren die abgestuften Zellreihen.',
    };
    const labelL = {
        rectangle: 'Laenge mm',
        l_shape: definitionMode === 'grid' ? 'Vertikaler Stab Laenge Zellen' : 'Vertikaler Stab Laenge mm',
        u_shape: definitionMode === 'grid' ? 'Schenkel Laenge Zellen' : 'Schenkel Laenge mm',
        t_shape: definitionMode === 'grid' ? 'Stab Laenge Zellen' : 'Stab Laenge mm',
        triangle: definitionMode === 'grid' ? 'Kathete Laenge Zellen' : 'Kathete Laenge mm',
        trapeze: definitionMode === 'grid' ? 'Untere Laenge Zellen' : 'Untere Laenge mm',
    };
    const labelW = {
        rectangle: 'Breite mm',
        l_shape: definitionMode === 'grid' ? 'Vertikaler Stab Breite Zellen' : 'Vertikaler Stab Breite mm',
        u_shape: definitionMode === 'grid' ? 'Schenkel Breite Zellen' : 'Schenkel Breite mm',
        t_shape: definitionMode === 'grid' ? 'Stab Breite Zellen' : 'Stab Breite mm',
        triangle: definitionMode === 'grid' ? 'Kathete Breite Zellen' : 'Kathete Breite mm',
        trapeze: definitionMode === 'grid' ? 'Tiefe Zellen' : 'Tiefe mm',
    };
    const shapeHint = document.getElementById('shapeHint');
    if (shapeHint) {
        shapeHint.textContent = definitionMode === 'grid'
            ? 'Die Form bestimmt die erzeugte Grundgeometrie. Die Groesse wird aus dem Zellraster berechnet.'
            : hintByShape[t];
    }
    const lLabel = document.getElementById('label_dim_l');
    const wLabel = document.getElementById('label_dim_w');
    const hLabel = document.getElementById('label_dim_h');
    if (lLabel)
        lLabel.textContent = labelL[t];
    if (wLabel)
        wLabel.textContent = labelW[t];
    if (hLabel)
        hLabel.textContent = 'Hoehe mm';
    const hField = document.getElementById('dim_h')?.closest('div');
    if (hField)
        hField.style.display = definitionMode === 'grid' ? 'none' : '';
    const cutLLabel = document.getElementById('label_cut_l');
    const cutWLabel = document.getElementById('label_cut_w');
    if (cutLLabel) {
        cutLLabel.textContent = t === 'u_shape'
            ? (definitionMode === 'grid' ? 'Gesamtbreite U Zellen' : 'Gesamtbreite U mm')
            : t === 'l_shape'
                ? (definitionMode === 'grid' ? 'Horizontaler Teil Laenge Zellen' : 'Horizontaler Teil Laenge mm')
                : definitionMode === 'grid'
                    ? 'Ausschnitt Laenge Zellen'
                    : 'Ausschnitt Laenge mm';
    }
    if (cutWLabel) {
        cutWLabel.textContent = t === 'u_shape'
            ? (definitionMode === 'grid' ? 'Ruecken Breite Zellen' : 'Ruecken Breite mm')
            : t === 'l_shape'
                ? (definitionMode === 'grid' ? 'Horizontaler Teil Breite Zellen' : 'Horizontaler Teil Breite mm')
                : definitionMode === 'grid'
                    ? 'Ausschnitt Breite Zellen'
                    : 'Ausschnitt Breite mm';
    }
    const stemLabel = document.getElementById('label_stem_w');
    const barLabel = document.getElementById('label_bar_h');
    if (stemLabel)
        stemLabel.textContent = definitionMode === 'grid' ? 'Horizontaler Balken Laenge Zellen' : 'Horizontaler Balken Laenge mm';
    if (barLabel)
        barLabel.textContent = definitionMode === 'grid' ? 'Horizontaler Balken Breite Zellen' : 'Horizontaler Balken Breite mm';
    const topLabel = document.getElementById('label_top_mm');
    if (topLabel)
        topLabel.textContent = definitionMode === 'grid' ? 'Obere Laenge Zellen' : 'Obere Laenge mm';
    const layoutColsField = document.getElementById('layoutCols')?.closest('div');
    const layoutRowsField = document.getElementById('layoutRows')?.closest('div');
    const composedGrid = definitionMode === 'grid' && composedShape;
    if (layoutColsField)
        layoutColsField.style.display = composedGrid ? 'none' : '';
    if (layoutRowsField)
        layoutRowsField.style.display = composedGrid ? 'none' : '';
    const layoutBox = document.getElementById('layoutBox');
    const lShapeLayerBox = document.getElementById('lShapeLayerBox');
    const lShapeLayerSlot = document.getElementById('lShapeLayerSlot');
    const layoutRowsContainer = document.getElementById('layoutRows')?.closest('div');
    const layerField = document.getElementById('layoutLayers')?.closest('div');
    if (composedGrid) {
        if (layoutBox)
            layoutBox.style.display = 'none';
        if (lShapeLayerBox)
            lShapeLayerBox.style.display = '';
        if (lShapeLayerSlot && layerField && layerField.parentElement !== lShapeLayerSlot)
            lShapeLayerSlot.appendChild(layerField);
    }
    else {
        if (layoutBox)
            layoutBox.style.display = definitionMode === 'grid' ? '' : 'none';
        if (lShapeLayerBox)
            lShapeLayerBox.style.display = 'none';
        if (layoutRowsContainer?.parentElement && layerField && layerField.parentElement?.id === 'lShapeLayerSlot') {
            layoutRowsContainer.insertAdjacentElement('afterend', layerField);
        }
    }
    const layoutHint = document.getElementById('layoutHint');
    if (layoutHint) {
        layoutHint.textContent = composedGrid
            ? 'Die Zellanzahl der Form ergibt sich aus den Teilstuecken. Hier wird nur noch die Anzahl der Ebenen festgelegt.'
            : 'Hier gibt der Kunde die Anzahl der Batteriezellen vor: Zellen in Laenge, Zellen in Breite und Anzahl der Ebenen.';
    }
}
function setInputValue(id, value) {
    const input = document.getElementById(id);
    if (!input)
        return;
    input.value = String(Math.max(1, Math.round(value * 10) / 10));
}
function applyShapeDetailDefaults() {
    const t = selVal('shapeType');
    if (definitionMode === 'grid') {
        const cols = Math.max(1, Math.floor(val('layoutCols') || 10));
        const rows = Math.max(1, Math.floor(val('layoutRows') || 10));
        if (t === 'l_shape') {
            setInputValue('dim_l', rows);
            setInputValue('dim_w', Math.max(1, Math.floor(cols * 0.35)));
            setInputValue('dim_cut_l', cols);
            setInputValue('dim_cut_w', Math.max(1, Math.floor(rows * 0.35)));
        }
        else if (t === 'u_shape') {
            setInputValue('dim_l', rows);
            setInputValue('dim_w', Math.max(1, Math.floor(cols * 0.25)));
            setInputValue('dim_cut_l', cols);
            setInputValue('dim_cut_w', Math.max(1, Math.floor(rows * 0.3)));
        }
        else if (t === 't_shape') {
            setInputValue('dim_l', Math.max(1, Math.floor(rows * 0.65)));
            setInputValue('dim_w', Math.max(1, Math.floor(cols * 0.3)));
            setInputValue('dim_stem_w', cols);
            setInputValue('dim_bar_h', Math.max(1, Math.floor(rows * 0.3)));
        }
        else if (t === 'triangle') {
            setInputValue('dim_l', cols);
            setInputValue('dim_w', rows);
        }
        else if (t === 'trapeze') {
            setInputValue('dim_l', cols);
            setInputValue('dim_w', rows);
            setInputValue('dim_top_mm', Math.max(1, Math.floor(cols * 0.65)));
        }
        return;
    }
    const l = Math.max(10, val('dim_l') || 400);
    const w = Math.max(10, val('dim_w') || 300);
    if (t === 'triangle') {
        const looksLikeGridValue = l < 50 && w < 50;
        if (looksLikeGridValue) {
            setInputValue('dim_l', 400);
            setInputValue('dim_w', 300);
        }
    }
    else if (t === 'l_shape') {
        setInputValue('dim_w', l * 0.35);
        setInputValue('dim_cut_l', l);
        setInputValue('dim_cut_w', w * 0.35);
    }
    else if (t === 'u_shape') {
        setInputValue('dim_w', l * 0.25);
        setInputValue('dim_cut_l', l);
        setInputValue('dim_cut_w', w * 0.3);
    }
    else if (t === 't_shape') {
        setInputValue('dim_l', w * 0.65);
        setInputValue('dim_w', l * 0.3);
        setInputValue('dim_stem_w', l);
        setInputValue('dim_bar_h', w * 0.3);
    }
    else if (t === 'trapeze') {
        setInputValue('dim_top_mm', l * 0.65);
    }
}
function onShapeTypeChange() {
    applyShapeDetailDefaults();
    onShapeChange();
}
function onCellTypeChange() {
    const t = selVal('cellType');
    el('round_dims').style.display = t === 'round' ? '' : 'none';
    el('prism_dims').style.display = t === 'prismatic' ? '' : 'none';
    el('grid_opts_round').style.display = t === 'round' ? '' : 'none';
}
function setPreset(key) {
    document.querySelectorAll('.preset-btn').forEach(b => b.classList.toggle('active', b.dataset.preset === key));
    if (key === 'custom')
        return;
    const p = CELL_PRESETS[key];
    if (!p)
        return;
    document.getElementById('cellType').value = p.type;
    onCellTypeChange();
    if (p.type === 'round') {
        ;
        document.getElementById('cell_diam').value = String(p.diam);
        document.getElementById('cell_h_round').value = String(p.height);
    }
    else {
        ;
        document.getElementById('cell_w').value = String(p.width);
        document.getElementById('cell_d').value = String(p.depth);
        document.getElementById('cell_h_prism').value = String(p.height);
    }
}
function getShapeParams() {
    const type = selVal('shapeType');
    if (type === 'triangle') {
        const sp = normalizeShapeParams({
            type,
            l: val('dim_l'),
            w: val('dim_w'),
            h: val('dim_h'),
            cut_l: val('dim_cut_l'),
            cut_w: val('dim_cut_w'),
            stem_w: val('dim_stem_w'),
            bar_h: val('dim_bar_h'),
            top_mm: val('dim_top_mm'),
        });
        syncShapeInputs(sp);
        return sp;
    }
    if (type === 'l_shape') {
        const verticalLength = Math.max(10, val('dim_l') || 10);
        const verticalWidth = Math.max(1, val('dim_w') || 1);
        const horizontalLength = Math.max(verticalWidth, val('dim_cut_l') || verticalWidth);
        const horizontalWidth = Math.max(1, val('dim_cut_w') || 1);
        const sp = normalizeShapeParams({
            type,
            l: horizontalLength,
            w: verticalLength,
            h: val('dim_h'),
            cut_l: Math.max(1, horizontalLength - verticalWidth),
            cut_w: Math.max(1, verticalLength - horizontalWidth),
            stem_w: val('dim_stem_w'),
            bar_h: val('dim_bar_h'),
            top_mm: val('dim_top_mm'),
        });
        syncShapeInputs(sp);
        return sp;
    }
    if (type === 'u_shape') {
        const legLength = Math.max(10, val('dim_l') || 10);
        const totalWidth = Math.max(3, val('dim_cut_l') || 3);
        const legWidth = clamp(Math.max(1, val('dim_w') || 1), 1, Math.max(1, (totalWidth - 1) / 2));
        const backWidth = Math.max(1, Math.min(legLength - 1, val('dim_cut_w') || 1));
        const sp = normalizeShapeParams({
            type,
            l: totalWidth,
            w: legLength,
            h: val('dim_h'),
            cut_l: legWidth,
            cut_w: backWidth,
            stem_w: val('dim_stem_w'),
            bar_h: val('dim_bar_h'),
            top_mm: val('dim_top_mm'),
        });
        syncShapeInputs(sp);
        return sp;
    }
    if (type === 't_shape') {
        const stemLength = Math.max(10, val('dim_l') || 10);
        const stemWidth = Math.max(1, val('dim_w') || 1);
        const barLength = Math.max(stemWidth, val('dim_stem_w') || stemWidth);
        const barWidth = Math.max(1, val('dim_bar_h') || 1);
        const sp = normalizeShapeParams({
            type,
            l: barLength,
            w: stemLength + barWidth,
            h: val('dim_h'),
            cut_l: val('dim_cut_l'),
            cut_w: val('dim_cut_w'),
            stem_w: stemWidth,
            bar_h: barWidth,
            top_mm: val('dim_top_mm'),
        });
        syncShapeInputs(sp);
        return sp;
    }
    const width = val('dim_w');
    const sp = normalizeShapeParams({
        type,
        l: val('dim_l'),
        w: width,
        h: val('dim_h'),
        cut_l: val('dim_cut_l'),
        cut_w: val('dim_cut_w'),
        stem_w: val('dim_stem_w'),
        bar_h: val('dim_bar_h'),
        top_mm: val('dim_top_mm'),
    });
    syncShapeInputs(sp);
    return sp;
}
function getCellParams() {
    const t = selVal('cellType');
    if (t === 'round') {
        return { type: 'round', diam: val('cell_diam'), height: val('cell_h_round') };
    }
    return { type: 'prismatic', width: val('cell_w'), depth: val('cell_d'), height: val('cell_h_prism') };
}
// ─────────────────────────────────────────────────────────────────────────────
// RESULTS UI
// ─────────────────────────────────────────────────────────────────────────────
let allResults = [];
let activeResultIdx = 0;
// Renders the result list and wires click handlers. Does NOT touch the 3D scene.
function renderResultList(results, activeIdx = 0) {
    if (results.length === 0) {
        el('bestCount').textContent = '0';
        el('bestDesc').textContent = 'Keine Zellen passen in den Bauraum.';
        el('bestDims').textContent = 'Packmasse: -';
        el('bestRaster').textContent = 'Raster: -';
        el('resultExplain').textContent = 'Passe Bauraum, Zelltyp oder Abstaende an und starte die Optimierung erneut.';
        el('resultList').innerHTML = '';
        return;
    }
    el('resultList').innerHTML = results.slice(0, 20).map((r, i) => `
    <div class="result-row${i === activeIdx ? ' active' : ''}" data-idx="${i}">
      <div>
        <span class="count">${r.total}</span>
      </div>
      <div class="desc">${orientationText(r)}</div>
    </div>
  `).join('');
    el('resultList').querySelectorAll('.result-row').forEach(row => {
        row.addEventListener('click', () => {
            const idx = parseInt(row.dataset.idx ?? '0');
            selectResult(idx);
        });
    });
}
function showResults(results) {
    setResultsPanelVisible(true);
    activeResultIdx = 0;
    renderResultList(results, 0);
    if (results.length > 0)
        selectResult(0);
}
function selectResult(idx) {
    activeResultIdx = idx;
    el('resultList').querySelectorAll('.result-row').forEach((r, i) => r.classList.toggle('active', i === idx));
    const r = allResults[idx];
    // Sync global offset + sliders to this result's stored optimal offset
    gridOffset = { ...r.gridOffset };
    syncOffsetSliders(r);
    visualizeResult(r);
}
function syncOffsetSliders(r) {
    const { stepX, stepY, stepZ } = getWorldStepSizes(r.cell, r.extrusionDir, r.cellRotation, r.gridStyle);
    el('gridOffX').max = String(stepX);
    el('gridOffY').max = String(stepY);
    el('gridOffZ').max = String(stepZ);
    el('gridOffX').value = String(r.gridOffset.ox);
    el('gridOffY').value = String(r.gridOffset.oy);
    el('gridOffZ').value = String(r.gridOffset.oz);
    el('gridOffXVal').textContent = r.gridOffset.ox.toFixed(1);
    el('gridOffYVal').textContent = r.gridOffset.oy.toFixed(1);
    el('gridOffZVal').textContent = r.gridOffset.oz.toFixed(1);
}
// Re-packs only the active result with the current offset/params and re-renders it.
// All other results in allResults stay untouched.
function liveRefresh() {
    if (allResults.length === 0)
        return;
    getPackingParams();
    const ref = allResults[activeResultIdx];
    if (ref.source === 'grid' && ref.layout) {
        const rebuilt = buildGridModeResult(ref.cell, ref.layout, ref.gridStyle);
        allResults[activeResultIdx] = rebuilt;
        visualizeResult(rebuilt, true);
        return;
    }
    const newPositions = pack3D(ref.sp, ref.cell, ref.extrusionDir, ref.gridStyle, gridOffset, ref.cellRotation);
    // Update only the active entry in-place
    allResults[activeResultIdx] = {
        ...ref,
        positions: newPositions,
        total: newPositions.length,
        gridOffset: { ...gridOffset },
    };
    // Re-render list row count for the active result only
    const activeRow = el('resultList').querySelector(`.result-row[data-idx="${activeResultIdx}"]`);
    if (activeRow) {
        const countEl = activeRow.querySelector('.count');
        if (countEl)
            countEl.textContent = String(newPositions.length);
    }
    visualizeResult(allResults[activeResultIdx], true);
}
// ─────────────────────────────────────────────────────────────────────────────
// OPTIMIZER RUNNER
// ─────────────────────────────────────────────────────────────────────────────
function runOptimizer() {
    getPackingParams();
    const cell = getCellParams();
    const gridStyle = selVal('gridType');
    let sp;
    let gridModeResult = null;
    if (definitionMode === 'grid') {
        const cfg = getTargetGridConfig();
        if (!cfg) {
            window.alert('Bitte fuer Zellraster vorgeben Laenge, Breite und Ebenen groesser 0 eintragen.');
            return;
        }
        gridModeResult = buildGridModeResult(cell, cfg, gridStyle);
        sp = gridModeResult.sp;
        onShapeChange();
    }
    else {
        sp = getShapeParams();
    }
    setPackViewMode(electricalMode === 'target' ? 'electrical' : 'max');
    el('runBtn').disabled = true;
    show('progress');
    el('prog_text').textContent = 'Berechnung läuft…';
    el('prog_sub').textContent = 'Prüfe alle Kombinationen…';
    setResultsPanelVisible(false);
    // Defer to next tick so the browser can repaint first
    setTimeout(() => {
        try {
            gridOffset = { ox: 0, oy: 0, oz: 0 };
            allResults = gridModeResult
                ? [gridModeResult]
                : runAllCombinations(sp, cell, gridStyle, gridOffset);
            showResults(allResults);
            if (allResults.length > 0)
                resetOffsetSliders(allResults[0]);
        }
        catch (e) {
            el('prog_text').textContent = 'Fehler: ' + e.message;
        }
        ;
        el('runBtn').disabled = false;
        hide('progress');
    }, 20);
}
// ─────────────────────────────────────────────────────────────────────────────
// VIS MODE
// ─────────────────────────────────────────────────────────────────────────────
function setVis(mode) {
    visMode = mode;
    ['Solid', 'Wire', 'Skeleton', 'Pack', 'Explode'].forEach(m => el('btn' + m).classList.toggle('active', m.toLowerCase() === mode));
    const explodeControl = document.getElementById('explodeControl');
    if (explodeControl)
        explodeControl.style.display = mode === 'explode' ? '' : 'none';
    if (currentResult)
        visualizeResult(currentResult, true);
}
function setPackViewMode(mode) {
    packViewMode = mode;
    const electricalBtn = document.getElementById('viewElectricalBtn');
    if (electricalBtn)
        electricalBtn.classList.toggle('active', mode === 'electrical');
    if (currentResult)
        visualizeResult(currentResult, false);
    updateElectricalSummary();
}
function setDefinitionMode(mode) {
    definitionMode = mode;
    el('modeSpaceBtn').classList.toggle('active', mode === 'space');
    el('modeGridBtn').classList.toggle('active', mode === 'grid');
    const hint = el('modeHint');
    hint.textContent = mode === 'space'
        ? 'Moeglichkeit 1: Optimiert die Batteriestacks innerhalb des angegebenen Bauraums.'
        : 'Moeglichkeit 2: Sie geben die Anzahl der Batteriezellen in Laenge, Breite und Ebenen vor. Daraus wird der benoetigte Bauraum berechnet.';
    const viewSwitch = document.getElementById('viewSwitch');
    if (viewSwitch)
        viewSwitch.style.display = mode === 'space' ? 'none' : '';
    const shapeCard = document.querySelector('.shape-card');
    if (shapeCard)
        shapeCard.classList.remove('muted-card');
    const layoutBox = document.getElementById('layoutBox');
    const layoutColsField = document.getElementById('layoutCols')?.closest('div');
    const layoutRowsField = document.getElementById('layoutRows')?.closest('div');
    const shapeType = selVal('shapeType');
    const composedGrid = mode === 'grid' && ['l_shape', 'u_shape', 't_shape'].includes(shapeType);
    if (layoutBox)
        layoutBox.style.display = mode === 'grid' && !composedGrid ? '' : 'none';
    if (layoutColsField)
        layoutColsField.style.display = composedGrid ? 'none' : '';
    if (layoutRowsField)
        layoutRowsField.style.display = composedGrid ? 'none' : '';
    const layoutHint = document.getElementById('layoutHint');
    if (layoutHint) {
        layoutHint.textContent = composedGrid
            ? 'Die Zellanzahl der Form ergibt sich aus den Teilstuecken. Hier wird nur noch die Anzahl der Ebenen festgelegt.'
            : 'Hier gibt der Kunde die Anzahl der Batteriezellen vor: Zellen in Laenge, Zellen in Breite und Anzahl der Ebenen.';
    }
    if (mode === 'space') {
        ;
        el('layoutCols').value = '0';
        el('layoutRows').value = '0';
        el('layoutLayers').value = '0';
    }
    applyShapeDetailDefaults();
    onShapeChange();
    updateElectricalSummary();
}
// ─────────────────────────────────────────────────────────────────────────────
// GRID OFFSET
// ─────────────────────────────────────────────────────────────────────────────
function resetOffsetSliders(result) {
    syncOffsetSliders(result);
    if (result.source === 'grid')
        hide('offsetCard');
    else
        show('offsetCard');
}
function onOffsetChange() {
    if (!currentResult)
        return;
    gridOffset = {
        ox: parseFloat(el('gridOffX').value),
        oy: parseFloat(el('gridOffY').value),
        oz: parseFloat(el('gridOffZ').value),
    };
    el('gridOffXVal').textContent = gridOffset.ox.toFixed(1);
    el('gridOffYVal').textContent = gridOffset.oy.toFixed(1);
    el('gridOffZVal').textContent = gridOffset.oz.toFixed(1);
    liveRefresh();
}
// ─────────────────────────────────────────────────────────────────────────────
// WIRE UP EVENT LISTENERS
// ─────────────────────────────────────────────────────────────────────────────
setupTaskbar();
setupHelpTooltips();
addTargetTooltips();
addLayoutTooltips();
setDefinitionMode('space');
document.getElementById('shapeType').addEventListener('change', onShapeTypeChange);
document.getElementById('shapeMirrorSelect').addEventListener('change', () => {
    if (currentResult)
        visualizeResult(currentResult, false);
});
document.getElementById('cellType').addEventListener('change', onCellTypeChange);
document.getElementById('runBtn').addEventListener('click', runOptimizer);
document.getElementById('btnSolid').addEventListener('click', () => setVis('solid'));
document.getElementById('btnWire').addEventListener('click', () => setVis('wire'));
document.getElementById('btnSkeleton').addEventListener('click', () => setVis('skeleton'));
document.getElementById('btnPack').addEventListener('click', () => setVis('pack'));
document.getElementById('btnExplode').addEventListener('click', () => setVis('explode'));
document.getElementById('btnModelUi').addEventListener('click', () => setModelUiHidden(!modelUiHidden));
document.getElementById('explodeAmount').addEventListener('input', () => {
    explodeAmount = parseFloat(document.getElementById('explodeAmount').value);
    if (currentResult && visMode === 'explode')
        visualizeResult(currentResult, true);
});
document.getElementById('exportDatasheetBtn').addEventListener('click', exportCustomerDatasheet);
document.getElementById('viewElectricalBtn').addEventListener('click', () => setPackViewMode('electrical'));
document.getElementById('modeSpaceBtn').addEventListener('click', () => setDefinitionMode('space'));
document.getElementById('modeGridBtn').addEventListener('click', () => setDefinitionMode('grid'));
document.getElementById('gridOffX').addEventListener('input', onOffsetChange);
document.getElementById('gridOffY').addEventListener('input', onOffsetChange);
document.getElementById('gridOffZ').addEventListener('input', onOffsetChange);
['paramMargin', 'paramGapRound', 'paramGapPrism', 'paramLayerGap'].forEach(id => {
    document.getElementById(id).addEventListener('input', () => { if (allResults.length)
        liveRefresh(); });
});
[
    'packVoltage',
    'packCapacity',
    'seriesCells',
    'parallelCells',
    'targetVoltage',
    'targetCapacity',
    'targetPower',
    'targetRuntimeMin',
    'targetMaxDischargeCurrent',
    'targetMaxChargeCurrent',
    'layoutCols',
    'layoutRows',
    'layoutLayers',
].forEach(id => {
    document.getElementById(id).addEventListener('input', () => {
        updateElectricalSummary();
        if (packViewMode === 'electrical' && currentResult)
            visualizeResult(currentResult, false);
    });
});
document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => setPreset(btn.dataset.preset ?? ''));
});
// ─────────────────────────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────────────────────────
onShapeChange();
setPreset('18650');
updateElectricalSummary();
requestAnimationFrame(() => runOptimizer());
